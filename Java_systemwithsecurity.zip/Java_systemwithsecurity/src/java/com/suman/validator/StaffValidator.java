
package com.suman.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
//import org.springframework.validation.ObjectError;


import com.suman.domain.Staff;


public class StaffValidator implements Validator {

    @Override
        public boolean supports(Class clazz) {
		return Staff.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "username.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "password.required");
                
         	}

        public void validateRegistration(Object target, Errors errors) {


		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "username", "username.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "password.required");
                

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstname", "firstname.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastname","lastname.required" );
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "sex","sex.required" );
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dateofbirth", "dateofbirth.required");


                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "emailid", "emailid.required");


                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "mobile", "mobile.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nationality", "nationality.required");
                
                
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "residentialaddress", "residentialaddress.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "residentialcity", "residentialcity.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "residentialstate1", "residentialstate1.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "residentialpin", "residentialpin.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "residentialcountry", "residentialcountry.required");


                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "permanentaddress", "permanentaddress.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "permanentcity", "permanentcity.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "permanentstate1", "permanentstate1.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "permanentpin", "permanentpin.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "permanentcountry", "permanentcountry.required");

                //ValidationUtils.rejectIfEmptyOrWhitespace(errors, "designation", "designation.required");


         	}

//
//         public void validateLeaveApplication(Object target, Errors errors){
//
//             ValidationUtils.rejectIfEmptyOrWhitespace(errors, "typeOfLeave", "typeOfLeave.required");
//             ValidationUtils.rejectIfEmptyOrWhitespace(errors, "duration", "duration.required");
//             ValidationUtils.rejectIfEmptyOrWhitespace(errors, "reason", "reason.required");
//
//
//         }



       //@Override
        public void loginFail(Object target, Errors errors){

           errors.rejectValue("password", "passwordwrong.required");
        }



}
