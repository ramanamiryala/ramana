package com.suman.validator;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.validation.ObjectError;

import com.suman.domain.Catalogue;

public class CatalogueValidator implements Validator {


    @Override
        public boolean supports(Class clazz) {
		return Catalogue.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "typeofrecord", "typeofrecord.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "recordIdentifier", "recordIdentifier.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "title", "title.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "author", "author.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "publishers", "publishers.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "ISDNNo", "ISDNNo.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "pages", "pages.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "subjectCategory", "subjectCategory.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "keywords", "keywords.required");

         	}


}
