

package com.suman.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
//import com.suman.web.StudentController;
import com.suman.domain.Student;


public class StudentValidator implements Validator {

    @Override
        public boolean supports(Class clazz) {
		return Student.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {


		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "name.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "password.required");
         	}

        //@Override
	public void validateRegistration(Object target, Errors errors) {


		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "name.required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "password.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "year1","year1.required" );
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "rno","rno.required" );
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "studentAddress", "studentAddress.required");
                ValidationUtils.rejectIfEmptyOrWhitespace(errors, "parentAddress", "parentAddress.required");
         	}

       //@Override
        public void loginFail(Object target, Errors errors){

           errors.rejectValue("password", "passwordwrong.required");
        }


}
