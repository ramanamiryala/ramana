package com.suman.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
//import org.springframework.validation.ObjectError;
import com.suman.domain.LeaveApplication;


public class LeaveApplicationValidator implements Validator {
    @Override
        public boolean supports(Class clazz) {
		return LeaveApplication.class.isAssignableFrom(clazz);
	}
    @Override
	public void validate(Object target, Errors errors) {
             ValidationUtils.rejectIfEmptyOrWhitespace(errors, "typeOfLeave", "typeOfLeave.required");
             //ValidationUtils.rejectIfEmptyOrWhitespace(errors, "duration", "duration.required");
             ValidationUtils.rejectIfEmptyOrWhitespace(errors, "reason", "reason.required");



         	}



}
