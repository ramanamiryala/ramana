package com.suman.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
//import org.springframework.validation.ObjectError;

import com.suman.domain.LibraryRuleSet;

public class LibraryRuleSetValidator implements Validator {

    @Override
    public boolean supports(Class clazz) {
        return LibraryRuleSet.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(Object target, Errors errors) {

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "stdMaxItems", "stdMaxItems.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "stdMaxBorrowDays", "stdMaxBorrowDays.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "stdLatePayementRate", "stdLatePayementRate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "stdResrevationPeriod", "stdResrevationPeriod.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "stdMaxRenewals", "stdMaxRenewals.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "stdMaxDaysRenewAppl", "stdMaxDaysRenewAppl.required");

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "staffMaxItems", "staffMaxItems.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "staffMaxBorrowDays", "staffMaxBorrowDays.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "staffLatePayementRate", "staffLatePayementRate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "staffResrevationPeriod", "staffResrevationPeriod.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "staffMaxRenewals", "staffMaxRenewals.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "staffMaxDaysRenewAppl", "staffMaxDaysRenewAppl.required");

    }

    

}
