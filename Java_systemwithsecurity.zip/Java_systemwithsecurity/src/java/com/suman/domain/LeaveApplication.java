
package com.suman.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="LEAVEAPPLICATION")

public class LeaveApplication {


    private String username;
    private String reportingAuthority;
    private String duration;
    private String days;
    private String reason;
    private String typeOfLeave;
    private String status;
    private String remarks;
    private String appliedDate;
    private String statusDate;
    private String statusTime;    
    private int id;


    @Column(name="USERNAME", length=30, nullable=true)
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Column(name="REPORTINGAUTHORIYH", length=30, nullable=true)
    public String getReportingAuthority() {
        return reportingAuthority;
    }

    public void setReportingAuthority(String reportingAuthority) {
        this.reportingAuthority = reportingAuthority;
    }

    @Column(name="DURATION",nullable=true)
    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    @Column(name="DAYS", length=30, nullable=true)
    public String getDays() {
        return days;
    }

    public void setDays(String days) {
        this.days = days;
    }

    @Column(name="REASON", length=100, nullable=true)
    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    @Column(name="TYPEOFLEAVE", length=20, nullable=true)
    public String getTypeOfLeave() {
        return typeOfLeave;
    }

    public void setTypeOfLeave(String typeOfLeave) {
        this.typeOfLeave = typeOfLeave;
    }

    @Column(name="STATUS", length=50, nullable=true)
    public String getStatus() {
        return status;
    }


    public void setStatus(String status) {
        this.status = status;
    }

    @Column(name="REMARKS", length=50, nullable=true)
    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Column(name="APPLIEDDATE",  nullable=true)
    public String getAppliedDate() {
        return appliedDate;
    }

    public void setAppliedDate(String appliedDate) {
        this.appliedDate = appliedDate;
    }

    @Column(name="STATUSDATE",  nullable=true)
    public String getStatusDate() {
        return statusDate;
    }

    public void setStatusDate(String statusDate) {
        this.statusDate = statusDate;
    }


    @Column(name="STATUSTIME",  nullable=true)
    public String getStatusTime() {
        return statusTime;
    }

    public void setStatusTime(String statusTime) {
        this.statusTime = statusTime;
    }


     //GeneratedValue
    @Id
    @GeneratedValue
    @Column(name="ID")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    
    
}
