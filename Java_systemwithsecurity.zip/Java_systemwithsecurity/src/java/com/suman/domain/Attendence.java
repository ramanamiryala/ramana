package com.suman.domain;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ATTENDENCE")

public class Attendence {

    private String rno;
        private String month;
        private String mathematics;
        private String physics;
        private String chemistry;
        private int id;

        @Id
        @GeneratedValue
        @Column(name ="at_id")
        public int getId() {
		return id;
	}
        public void setId(int id) {
		this.id = id;
        }

        @Column(name="at_Rno")
        public String getRno() {
		return rno;
	}
        public void setRno(String rno) {
		this.rno = rno;
        }
        @Column(name ="at_Month")
        public String getMonth() {
		return month;
	}
        public void setMonth(String month) {
		this.month = month;
        }

        @Column(name="at_Mathematics")
        public String getMathematics() {
		return mathematics;
	}
        public void setMathematics(String mathematics) {
		this.mathematics = mathematics;

        }
        @Column(name="at_Physics")
        public String getPhysics() {
		return physics;
	}
        public void setPhysics(String physics) {
		this.physics = physics;

        }
        @Column(name="at_Chemistry")
        public String getChemistry() {
		return chemistry;
	}
        public void setChemistry(String chemistry) {
		this.chemistry = chemistry;

        }


}
