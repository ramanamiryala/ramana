
package com.suman.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="LEAVESUMMARY")


public class LeaveSummary {


    private String username;
    private String reportingAuthority;


    //CL
    private int clAppliedNo;
    private int clRejectedNo;
    private int clAccepted;
    private int clUsed;
    private int clUnused;
    private int cltotal;


    //SL
    private int slAppliedNo;
    private int slRejectedNo;
    private int slAccepted;
    private int slUsed;
    private int slUnused;
    private int sltotal;


    //CCL
    private int cclAppliedNo;
    private int cclRejectedNo;
    private int cclAccepted;
    private int cclUsed;
    private int cclUnused;
    private int ccltotal;


    //SPCL
    private int spclAppliedNo;
    private int spclRejectedNo;
    private int spclAccepted;
    private int spclUsed;
    private int spclUnused;
    private int spcltotal;


    //EL
    private int elAppliedNo;
    private int elRejectedNo;
    private int elAccepted;
    private int elUsed;
    private int elUnused;
    private int eltotal;

    //GeneratedValue
    private int id;



   



    @Column(name="USERNAME", length=30, nullable=true)
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Column(name="REPORTINGAUTHORITY", length=30, nullable=true)
    public String getReportingAuthority() {
        return reportingAuthority;
    }

    public void setReportingAuthority(String reportingAuthority) {
        this.reportingAuthority = reportingAuthority;
    }


    //-----------------CL--------------------

    @Column(name="CLAPPLIEDNO",  nullable=true)
    public int getClAppliedNo() {
        return clAppliedNo;
    }

    public void setClAppliedNo(int clAppliedNo) {
        this.clAppliedNo = clAppliedNo;
    }


    @Column(name="CLACCEPTED",  nullable=true)
    public int getClAccepted() {
        return clAccepted;
    }

    public void setClAccepted(int clAccepted) {
        this.clAccepted = clAccepted;
    }

    @Column(name="CLREJECTEDNO",  nullable=true)
    public int getClRejectedNo() {
        return clRejectedNo;
    }

    public void setClRejectedNo(int clRejectedNo) {
        this.clRejectedNo = clRejectedNo;
    }

    @Column(name="CLUSED",  nullable=true)
    public int getClUsed() {
        return clUsed;
    }

    public void setClUsed(int clUsed) {
        this.clUsed = clUsed;
    }

    @Column(name="CLUNUSED",  nullable=true)
    public int getClUnused() {
        return clUnused;
    }

    public void setClUnused(int clUnused) {
        this.clUnused = clUnused;
    }

    @Column(name="CLTOTAL",  nullable=true)
    public int getCltotal() {
        return cltotal;
    }

    public void setCltotal(int cltotal) {
        this.cltotal = cltotal;
    }



    //-------------------SL----------------------


    @Column(name="SLACCEPTED",  nullable=true)
    public int getSlAccepted() {
        return slAccepted;
    }

    public void setSlAccepted(int slAccepted) {
        this.slAccepted = slAccepted;
    }

    @Column(name="SLAPPLIEDNO",  nullable=true)
    public int getSlAppliedNo() {
        return slAppliedNo;
    }

    public void setSlAppliedNo(int slAppliedNo) {
        this.slAppliedNo = slAppliedNo;
    }


    @Column(name="SLREJECTEDNO",  nullable=true)
    public int getSlRejectedNo() {
        return slRejectedNo;
    }

    public void setSlRejectedNo(int slRejectedNo) {
        this.slRejectedNo = slRejectedNo;
    }


    @Column(name="SLUNUSED",  nullable=true)
    public int getSlUnused() {
        return slUnused;
    }

    public void setSlUnused(int slUnused) {
        this.slUnused = slUnused;
    }


    @Column(name="SLUSED",  nullable=true)
    public int getSlUsed() {
        return slUsed;
    }

    public void setSlUsed(int slUsed) {
        this.slUsed = slUsed;
    }

    @Column(name="SLTOTAL",  nullable=true)
    public int getSltotal() {
        return sltotal;
    }

    public void setSltotal(int sltotal) {
        this.sltotal = sltotal;
    }






    //-----------------CCL---------------

    @Column(name="CCLACCEPTED",  nullable=true)
    public int getCclAccepted() {
        return cclAccepted;
    }

    public void setCclAccepted(int cclAccepted) {
        this.cclAccepted = cclAccepted;
    }

    @Column(name="CCLAPPLIEDNO",  nullable=true)
    public int getCclAppliedNo() {
        return cclAppliedNo;
    }

    public void setCclAppliedNo(int cclAppliedNo) {
        this.cclAppliedNo = cclAppliedNo;
    }


    @Column(name="CCLREJECTEDNO",  nullable=true)
    public int getCclRejectedNo() {
        return cclRejectedNo;
    }

    public void setCclRejectedNo(int cclRejectedNo) {
        this.cclRejectedNo = cclRejectedNo;
    }


    @Column(name="CCLUNUSED",  nullable=true)
    public int getCclUnused() {
        return cclUnused;
    }

    public void setCclUnused(int cclUnused) {
        this.cclUnused = cclUnused;
    }


    @Column(name="CCLUSED",  nullable=true)
    public int getCclUsed() {
        return cclUsed;
    }

    public void setCclUsed(int cclUsed) {
        this.cclUsed = cclUsed;
    }

    @Column(name="CCLTOTAL",  nullable=true)
    public int getCcltotal() {
        return ccltotal;
    }

    public void setCcltotal(int ccltotal) {
        this.ccltotal = ccltotal;
    }




    //----------------------SPCL----------------


    @Column(name="SPCLACCEPTED",  nullable=true)
    public int getSpclAccepted() {
        return spclAccepted;
    }

    public void setSpclAccepted(int spclAccepted) {
        this.spclAccepted = spclAccepted;
    }


    @Column(name="SPCLAPPLIEDNO",  nullable=true)
    public int getSpclAppliedNo() {
        return spclAppliedNo;
    }

    public void setSpclAppliedNo(int spclAppliedNo) {
        this.spclAppliedNo = spclAppliedNo;
    }


    @Column(name="SCLREJECTEDNO",  nullable=true)
    public int getSpclRejectedNo() {
        return spclRejectedNo;
    }

    public void setSpclRejectedNo(int spclRejectedNo) {
        this.spclRejectedNo = spclRejectedNo;
    }


    @Column(name="SPCLUNUSED",  nullable=true)
    public int getSpclUnused() {
        return spclUnused;
    }

    public void setSpclUnused(int spclUnused) {
        this.spclUnused = spclUnused;
    }


    @Column(name="SPCLUSED",  nullable=true)
    public int getSpclUsed() {
        return spclUsed;
    }

    public void setSpclUsed(int spclUsed) {
        this.spclUsed = spclUsed;
    }

    @Column(name="SPCLTOTAL",  nullable=true)
    public int getSpcltotal() {
        return spcltotal;
    }

    public void setSpcltotal(int spcltotal) {
        this.spcltotal = spcltotal;
    }





    //---------------EL------------------

    @Column(name="ELACCEPTED",  nullable=true)
    public int getElAccepted() {
        return elAccepted;
    }

    public void setElAccepted(int elAccepted) {
        this.elAccepted = elAccepted;
    }


    @Column(name="ELAPPLIEDNO",  nullable=true)
    public int getElAppliedNo() {
        return elAppliedNo;
    }

    public void setElAppliedNo(int elAppliedNo) {
        this.elAppliedNo = elAppliedNo;
    }


    @Column(name="ELREJECTEDNO",  nullable=true)
    public int getElRejectedNo() {
        return elRejectedNo;
    }

    public void setElRejectedNo(int elRejectedNo) {
        this.elRejectedNo = elRejectedNo;
    }

    @Column(name="ELUNUSED",  nullable=true)
    public int getElUnused() {
        return elUnused;
    }


    public void setElUnused(int elUnused) {
        this.elUnused = elUnused;
    }


    @Column(name="ELUSED",  nullable=true)
    public int getElUsed() {
        return elUsed;
    }

    public void setElUsed(int elUsed) {
        this.elUsed = elUsed;
    }

    @Column(name="ELTOTAL",  nullable=true)
    public int getEltotal() {
        return eltotal;
    }

    public void setEltotal(int eltotal) {
        this.eltotal = eltotal;
    }



  


      //GeneratedValue
    @Id
    @GeneratedValue
    @Column(name="ID")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



   

}
