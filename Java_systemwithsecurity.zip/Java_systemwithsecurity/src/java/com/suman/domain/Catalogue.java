package com.suman.domain;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CATALOGUE")
public class Catalogue {
    private String typeofrecord ;
    private String recordIdentifier ; //(like 677.11 N)
    private String title;
    private String author;
    private String yearofPublication;
    private String publishers;    //(with address)
    private String ISDNNo;
    private String pages ;
    private String subjectCategory ;
    private String keywords ;         //(Comma separated)

    private int id;


    @Column(name="TypeofRecord",  nullable=true)
    public String getTypeofrecord() {
        return typeofrecord;
    }

    public void setTypeofrecord(String typeofrecord) {
        this.typeofrecord = typeofrecord;
    }

    @Column(name="RecordIdentifier",  nullable=true)
    public String getRecordIdentifier() {
        return recordIdentifier;
    }

    public void setRecordIdentifier(String recordIdentifier) {
        this.recordIdentifier = recordIdentifier;
    }

    @Column(name="Title",  nullable=true)
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @Column(name="Author",  nullable=true)
    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    @Column(name="YearofPublication",  nullable=true)
    public String getYearofPublication() {
        return yearofPublication;
    }

    public void setYearofPublication(String yearofPublication) {
        this.yearofPublication = yearofPublication;
    }

    @Column(name="Publishers",  nullable=true)
    public String getPublishers() {
        return publishers;
    }

    public void setPublishers(String publishers) {
        this.publishers = publishers;
    }

    @Column(name="ISDNNo",  nullable=true)
    public String getISDNNo() {
        return ISDNNo;
    }

    public void setISDNNo(String ISDNNo) {
        this.ISDNNo = ISDNNo;
    }

    @Column(name="Pages",  nullable=true)
    public String getPages() {
        return pages;
    }

    public void setPages(String pages) {
        this.pages = pages;
    }

    @Column(name="SubjectCategory",  nullable=true)
    public String getSubjectCategory() {
        return subjectCategory;
    }

    public void setSubjectCategory(String subjectCategory) {
        this.subjectCategory = subjectCategory;
    }

    @Column(name="Keywords",  nullable=true)
    public String getKeywords() {
        return keywords;
    }

    public void setKeywords(String keywords) {
        this.keywords = keywords;
    }

    @Id
    @GeneratedValue
    @Column(name="ID")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}
