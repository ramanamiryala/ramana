
package com.suman.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="STAFF")


public class Staff implements Serializable {


    private String profilePhotoFileName;

    private String username;
    private String password;
    private String department;
    private String currentDesignation;
    private String joiningDate;

    private long userprimkey;
    private long raUserprimkey;

    

    // Persaonal Information:
    private String firstname;
    private String lastname;
    private String  sex;
    private String dateofbirth;
    private String emailid;
    private String mobile;
    private String nationality;

    // Residential Address Details:
    private String residentialaddress;
    private String residentialoptional1;
    private String residentialoptional2;
    private String residentialcity;
    private String residentialstate1;
    private String residentialpin;
    private String residentialcountry;
    private String residentialphone;

    // Permanent Address Details:
    private String permanentaddress;
    private String permanentoptional1;
    private String permanentoptional2;
    private String permanentcity;
    private String permanentstate1;
    private String permanentpin;
    private String permanentcountry;
    private String permanentphone;


    // First Education Details:
    private String coursename;
    private String specialization;
    private String institute1;
    private String university;
    private String academicYear1;

    // Second Education Details
    private String coursename2;
    private String specialization2;
    private String institute2;
    private String university2;
    private String academicYear2;

    // Third Education Details:
    private String coursename3;
    private String specialization3;
    private String institute3;
    private String university3;
    private String academicYear3;

    // First Work Experience Details:
    private String previousempolyer;
    private String duration1;
    private String designation;
    private String organization;


    // Second Work Experience Details:
    private String previousempolyer2;
    private String duration2;
    private String designation2;
    private String organization2;

    private int id;




    // User ID and Password Details:

    @Column(name="UserName", length=30, nullable=true)
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    @Column(name="Userprimkey", nullable=true)
    public long getUserprimkey() {
        return userprimkey;
    }

    public void setUserprimkey(long userprimkey) {
        this.userprimkey = userprimkey;
    }

    @Column(name="Password", length=30, nullable=true)
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Column(name="RAUserprimkey", length=30, nullable=true)
    public long getRaUserprimkey() {
        return raUserprimkey;
    }

    public void setRaUserprimkey(long raUserprimkey) {
        this.raUserprimkey = raUserprimkey;
    }

    

    @Column(name="Department", nullable=true)
    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    @Column(name="CurrentDesignation", nullable=true)
    public String getCurrentDesignation() {
        return currentDesignation;
    }

    public void setCurrentDesignation(String currentDesignation) {
        this.currentDesignation = currentDesignation;
    }

    @Column(name="JoiningDate", nullable=true)
    public String getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(String joiningDate) {
        this.joiningDate = joiningDate;
    }






   // Personal Information:

    @Column(name="FirstName", length=50, nullable=true)
    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }


    @Column(name="LastName", length=50, nullable=true)
    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }


    @Column(name="Sex", length=10, nullable=true)
    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }



    @Column(name="DateOfBirth", length=80, nullable=true)
    public String getDateofbirth() {
        return dateofbirth;
    }

    public void setDateofbirth(String dateofbirth) {
        this.dateofbirth = dateofbirth;
    }



    @Column(name="EmailId", length=30, nullable=true)
    public String getEmailid() {
        return emailid;
    }

    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }


    @Column(name="Mobile", length=10, nullable=true)
    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }


    @Column(name="Nationality", length=30, nullable=true)
    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    
    
    
    // Residential Address Details:
    
    @Column(name="ResidentialAddress", length=200, nullable=true)
    public String getResidentialaddress() {
        return residentialaddress;
    }

    public void setResidentialaddress(String residentialaddress) {
        this.residentialaddress = residentialaddress;
    }


    @Column(name="ResidentialOptional1", length=100, nullable=true)
    public String getResidentialoptional1() {
        return residentialoptional1;
    }

    public void setResidentialoptional1(String residentialoptional1) {
        this.residentialoptional1 = residentialoptional1;
    }


    @Column(name="ResidentialOptional2", length=100, nullable=true)
    public String getResidentialoptional2() {
        return residentialoptional2;
    }

    public void setResidentialoptional2(String residentialoptional2) {
        this.residentialoptional2 = residentialoptional2;
    }


    @Column(name="ResidentialCity", length=50, nullable=true)
    public String getResidentialcity() {
        return residentialcity;
    }

    public void setResidentialcity(String residentialcity) {
        this.residentialcity = residentialcity;
    }

    @Column(name="ResidentialState", length=30, nullable=true)
    public String getResidentialstate1() {
        return residentialstate1;
    }

    public void setResidentialstate1(String residentialstate1) {
        this.residentialstate1 =residentialstate1;
    }



    @Column(name="ResidentialPin", length=06, nullable=true)
    public String getResidentialpin() {
        return residentialpin;
    }

    public void setResidentialpin(String residentialpin) {
        this.residentialpin = residentialpin;
    }



    @Column(name="ResidentialCountry", length=50, nullable=true)
    public String getResidentialcountry() {
        return residentialcountry;
    }

    public void setResidentialcountry(String residentialcountry) {
        this.residentialcountry = residentialcountry;
    }


    @Column(name="ResidentialPhone", length=11, nullable=true)
    public String getResidentialphone() {
        return residentialphone;
    }

    public void setResidentialphone(String residentialphone) {
        this.residentialphone = residentialphone;
    }


    // Permanent Address Details:

    @Column(name="PermanentAddress", length=200, nullable=true)
    public String getPermanentaddress() {
        return permanentaddress;
    }

    public void setPermanentaddress(String permanentaddress) {
        this.permanentaddress = permanentaddress;
    }

    @Column(name="PermanentOptional1", length=100, nullable=true)
    public String getPermanentoptional1() {
        return permanentoptional1;
    }

    public void setPermanentoptional1(String permanentoptional1) {
        this.permanentoptional1 = permanentoptional1;
    }

    @Column(name="PermanentOptional2", length=100, nullable=true)
    public String getPermanentoptional2() {
        return permanentoptional2;
    }

    public void setPermanentoptional2(String permanentoptional2) {
        this.permanentoptional2 = permanentoptional2;
    }

    @Column(name="PermanentCity", length=50, nullable=true)
    public String getPermanentcity() {
        return permanentcity;
    }

    public void setPermanentcity(String permanentcity) {
        this.permanentcity = permanentcity;
    }

    @Column(name="PermanentSate", length=30, nullable=true)
    public String getPermanentstate1() {
        return permanentstate1;
    }

    public void setPermanentstate1(String permanentstate1) {
        this.permanentstate1 = permanentstate1;
    }

    @Column(name="PermanentPin", length=06, nullable=true)
    public String getPermanentpin() {
        return permanentpin;
    }

    public void setPermanentpin(String permanentpin) {
        this.permanentpin = permanentpin;
    }

    @Column(name="PermanentCountry", length=50, nullable=true)
    public String getPermanentcountry() {
        return permanentcountry;
    }

    public void setPermanentcountry(String permanentcountry) {
        this.permanentcountry = permanentcountry;
    }

    @Column(name="PermanentPhone", length=11, nullable=true)
    public String getPermanentphone() {
        return permanentphone;
    }

    public void setPermanentphone(String permanentphone) {
        this.permanentphone = permanentphone;
    }






    // Firest Education detail:


    @Column(name="CourseName", nullable=true)
    public String getCoursename() {
        return coursename;
    }

    public void setCoursename(String coursename) {
        this.coursename = coursename;
    }


    @Column(name="Specialization", length=50, nullable=true)
    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    @Column(name="Institute1", length=30, nullable=true)
    public String getInstitute1() {
        return institute1;
    }

    public void setInstitute1(String institute1) {
        this.institute1 = institute1;
    }





    @Column(name="University", length=30, nullable=true)
    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }


    @Column(name="FirstAcademicYear", nullable=true)
    public String getAcademicYear1() {
        return academicYear1;
    }

    public void setAcademicYear1(String academicYear1) {
        this.academicYear1 = academicYear1;
    }


    // SECOND EDUCATION  DETAILS:

    @Column(name="CourseName2",  nullable=true)
    public String getCoursename2() {
        return coursename2;
    }

    public void setCoursename2(String coursename2) {
        this.coursename2 = coursename2;
    }


    @Column(name="Specialization2", length=50, nullable=true)
    public String getSpecialization2() {
        return specialization2;
    }

    public void setSpecialization2(String specialization2) {
        this.specialization2 = specialization2;
    }


    @Column(name="Institute2", length=30, nullable=true)
    public String getInstitute2() {
        return institute2;
    }

    public void setInstitute2(String institute2) {
        this.institute2 = institute2;
    }


    @Column(name="University2", length=30, nullable=true)
    public String getUniversity2() {
        return university2;
    }

    public void setUniversity2(String university2) {
        this.university2 = university2;
    }


    @Column(name="SecondAcademicYear", nullable=true)
    public String getAcademicYear2() {
        return academicYear2;
    }

    public void setAcademicYear2(String academicYear2) {
        this.academicYear2 = academicYear2;
    }




    // THIRD EDUCATION  DETAILS:

    @Column(name="CourseName3",nullable=true)
    public String getCoursename3() {
        return coursename3;
    }

    public void setCoursename3(String coursename3) {
        this.coursename3 = coursename3;
    }


    @Column(name="Specialization3", length=50, nullable=true)
    public String getSpecialization3() {
        return specialization3;
    }

    public void setSpecialization3(String specialization3) {
        this.specialization3 = specialization3;
    }
    
    @Column(name="Institute3", length=30, nullable=true)

    public String getInstitute3() {
        return institute3;
    }

    public void setInstitute3(String institute3) {
        this.institute3 = institute3;
    }



    @Column(name="University3", length=30, nullable=true)
    public String getUniversity3() {
        return university3;
    }

    public void setUniversity3(String university3) {
        this.university3 = university3;
    }


    @Column(name="ThirdAcademicYear",nullable=true)
    public String getAcademicYear3() {
        return academicYear3;
    }

    public void setAcademicYear3(String academicYear3) {
        this.academicYear3 = academicYear3;
    }




    // Firest Work Experience Details:

    @Column(name="Designation", length=50, nullable=true)
    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    @Column(name="Duration1",nullable=true)
    public String getDuration1() {
        return duration1;
    }

    public void setDuration1(String duration1) {
        this.duration1 = duration1;
    }

    @Column(name="Organization",length=100, nullable=true)
    public String getOrganization() {
        return organization;
    }

    public void setOrganization(String organization) {
        this.organization = organization;
    }

    
    
    @Column(name="PreviousEmpolyer", length=50, nullable=true)
    public String getPreviousempolyer() {
        return previousempolyer;
    }

    public void setPreviousempolyer(String previousempolyer) {
        this.previousempolyer = previousempolyer;
    }

    
   
    
    // Second Work Experience Details:

    @Column(name="Designation2", length=50, nullable=true)
    public String getDesignation2() {
        return designation2;
    }

    public void setDesignation2(String designation2) {
        this.designation2 = designation2;
    }

    @Column(name="Duration2", nullable=true)
    public String getDuration2() {
        return duration2;
    }

    public void setDuration2(String duration2) {
        this.duration2 = duration2;
    }

    @Column(name="Organization2", length=100,nullable=true)
    public String getOrganization2() {
        return organization2;
    }

    public void setOrganization2(String organization2) {
        this.organization2 = organization2;
    }



    @Column(name="PreviousEmpolyer2", length=50, nullable=true)
    public String getPreviousempolyer2() {
        return previousempolyer2;
    }

    public void setPreviousempolyer2(String previousempolyer2) {
        this.previousempolyer2 = previousempolyer2;
    }


    @Id
    @GeneratedValue
    @Column(name="ID")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    @Column(name = "ProfilePhotoFileName", nullable = true)
    public String getProfilePhotoFileName() {
        return profilePhotoFileName;
    }

    public void setProfilePhotoFileName(String profilePhotoFileName) {
        this.profilePhotoFileName = profilePhotoFileName;
    }


}
