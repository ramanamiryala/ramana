package com.suman.domain;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
@Table(name="LIBRARYRULESET")

public class LibraryRuleSet {


    private long id;

    //Studentd Items
    private String stdMaxItems;
    private String stdMaxBorrowDays;
    private String stdLatePayementRate;
    private String stdResrevationPeriod;
    private String stdMaxRenewals;
    private String stdMaxDaysRenewAppl;
    private String stdMaxReservedItems;

    //Staff Items
    private String staffMaxItems;
    private String staffMaxBorrowDays;
    private String staffLatePayementRate;
    private String staffResrevationPeriod;
    private String staffMaxRenewals;
    private String staffMaxDaysRenewAppl;
    private String staffMaxReservedItems;


    @Id
    @GeneratedValue
    @Column(name = "id")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }



    //STUDENT ITEMS

    @Column(name = "StudentMaxItems", nullable = true)
    public String getStdMaxItems() {
        return stdMaxItems;
    }

    public void setStdMaxItems(String stdMaxItems) {
        this.stdMaxItems = stdMaxItems;
    }


    @Column(name = "StudentMaxBorrowDays", nullable = true)
    public String getStdMaxBorrowDays() {
        return stdMaxBorrowDays;
    }

    public void setStdMaxBorrowDays(String stdMaxBorrowDays) {
        this.stdMaxBorrowDays = stdMaxBorrowDays;
    }

    

    @Column(name = "StudentLatePayementRate", nullable = true)
    public String getStdLatePayementRate() {
        return stdLatePayementRate;
    }

    public void setStdLatePayementRate(String stdLatePayementRate) {
        this.stdLatePayementRate = stdLatePayementRate;
    }

    @Column(name = "StudentResrevationPeriod", nullable = true)
    public String getStdResrevationPeriod() {
        return stdResrevationPeriod;
    }

    public void setStdResrevationPeriod(String stdResrevationPeriod) {
        this.stdResrevationPeriod = stdResrevationPeriod;
    }

    @Column(name = "StudentMaxRenewals", nullable = true)
    public String getStdMaxRenewals() {
        return stdMaxRenewals;
    }

    public void setStdMaxRenewals(String stdMaxRenewals) {
        this.stdMaxRenewals = stdMaxRenewals;
    }

    @Column(name = "StudentMaxDaysRenewAppl", nullable = true)
    public String getStdMaxDaysRenewAppl() {
        return stdMaxDaysRenewAppl;
    }

    public void setStdMaxDaysRenewAppl(String stdMaxDaysRenewAppl) {
        this.stdMaxDaysRenewAppl = stdMaxDaysRenewAppl;
    }

    @Column(name = "StudentMaxReservedItems", nullable = true)
    public String getStdMaxReservedItems() {
        return stdMaxReservedItems;
    }

    public void setStdMaxReservedItems(String stdMaxReservedItems) {
        this.stdMaxReservedItems = stdMaxReservedItems;
    }




    //STAFF ITEMS


    @Column(name = "StaffMaxItems", nullable = true)
        public String getStaffMaxItems() {
        return staffMaxItems;
    }

    public void setStaffMaxItems(String staffMaxItems) {
        this.staffMaxItems = staffMaxItems;
    }


    @Column(name = "StaffMaxBorrowDays", nullable = true)
    public String getStaffMaxBorrowDays() {
        return staffMaxBorrowDays;
    }

    public void setStaffMaxBorrowDays(String staffMaxBorrowDays) {
        this.staffMaxBorrowDays = staffMaxBorrowDays;
    }

   
    @Column(name = "StaffLatePayementRate", nullable = true)
    public String getStaffLatePayementRate() {
        return staffLatePayementRate;
    }

    public void setStaffLatePayementRate(String staffLatePayementRate) {
        this.staffLatePayementRate = staffLatePayementRate;
    }

    @Column(name = "StaffResrevationPeriod", nullable = true)
    public String getStaffResrevationPeriod() {
        return staffResrevationPeriod;
    }

    public void setStaffResrevationPeriod(String staffResrevationPeriod) {
        this.staffResrevationPeriod = staffResrevationPeriod;
    }

    @Column(name = "StaffMaxRenewals", nullable = true)
    public String getStaffMaxRenewals() {
        return staffMaxRenewals;
    }

    public void setStaffMaxRenewals(String staffMaxRenewals) {
        this.staffMaxRenewals = staffMaxRenewals;
    }

    @Column(name = "StaffMaxDaysRenewAppl", nullable = true)
    public String getStaffMaxDaysRenewAppl() {
        return staffMaxDaysRenewAppl;
    }

    public void setStaffMaxDaysRenewAppl(String staffMaxDaysRenewAppl) {
        this.staffMaxDaysRenewAppl = staffMaxDaysRenewAppl;
    }

    @Column(name = "StaffMaxReservedItems", nullable = true)
    public String getStaffMaxReservedItems() {
        return staffMaxReservedItems;
    }

    public void setStaffMaxReservedItems(String staffMaxReservedItems) {
        this.staffMaxReservedItems = staffMaxReservedItems;
    }
    
}
