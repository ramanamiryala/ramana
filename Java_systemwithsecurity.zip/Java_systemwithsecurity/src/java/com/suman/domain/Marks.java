package com.suman.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
//import org.springframework.web.

@Entity
@Table(name="MARKS")


public class Marks {

        private String rno;
        private String internaltype;
        private int mathematics;
        private int physics;
        private int chemistry;
        private int id;


        @Id
        @GeneratedValue
        @Column(name ="mr_id")
        public int getId() {
		return id;
	}
        public void setId(int id) {
		this.id = id;
        }

        @Column(name="mr_Rno")
        public String getRno() {
		return rno;
	}
        public void setRno(String rno) {
		this.rno = rno;
        }
        @Column(name ="mr_Internaltype")
        public String getInternaltype() {
		return internaltype;
	}
        public void setInternaltype(String internaltype) {
		this.internaltype = internaltype;
        }

        @Column(name="mr_Mathematics")
        public int getMathematics() {
		return mathematics;
	}
        public void setMathematics(int mathematics) {
		this.mathematics = mathematics;

        }
        @Column(name="mr_Physics")
        public int getPhysics() {
		return physics;
	}
        public void setPhysics(int physics) {
		this.physics = physics;

        }
        @Column(name="mr_Chemistry")
        public int getChemistry() {
		return chemistry;
	}
        public void setChemistry(int chemistry) {
		this.chemistry = chemistry;

        }

}
