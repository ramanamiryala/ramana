package com.suman.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "LIBRARY")
public class Library {

    private int id;
    private String book_name;
    private String subject;
    private String rno;
    private String book_libCode;

    @Id
    @GeneratedValue
    @Column(name = "lib_id")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Column(name = "lib_book_code")
    public String getBook_libCode() {
        return book_libCode;
    }

    public void setBook_libCode(String book_libCode) {
        this.book_libCode = book_libCode;
    }

    @Column(name = "lib_Rno")
    public String getRno() {
        return rno;
    }

    public void setRno(String rno) {
        this.rno = rno;
    }

    @Column(name = "lib_book_name")
    public String getBook_name() {
        return book_name;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    @Column(name = "lib_subject")
    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }
}
