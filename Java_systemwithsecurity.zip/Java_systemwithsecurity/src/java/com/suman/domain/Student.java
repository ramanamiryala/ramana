package com.suman.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="STUDENT")

public class Student {
        private String name;
	private String password;
        //private String dob ="1234";
        private String year1;
        private String rno;
        private String branch;
        private String phno;
        private String emailid;
        private String studentAddress;
        private String parentAddress;

        private int id;


	//
	@Column(name="st_name")
        public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

        @Column(name="st_password")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;

        }

        @Column(name="st_year1")
        public String getYear1() {
		return year1;
	}
        public void setYear1(String year1) {
		this.year1 = year1;

        }

        @Column(name="st_Rno")
        public String getRno() {
		return rno;
	}
        public void setRno(String rno) {
		this.rno = rno;

        }
        @Column(name="st_Branch")
        public String getBranch() {
		return branch;
	}
        public void setBranch(String branch) {
		this.branch = branch;

        }
        @Column(name="st_Phno")
        public String getPhno() {
		return phno;
	}
        public void setPhno(String phno) {
		this.phno = phno;
        }
        @Column(name="st_Emailid")
        public String getEmailid() {
		return emailid;
	}
        public void setEmailid(String emailid) {
		this.emailid = emailid;
        }
        @Id
        @GeneratedValue
        @Column(name ="st_id")
        public int getId() {
		return id;
	}
        public void setId(int id) {
		this.id = id;
        }

        @Column(name ="st_studentAddress")
        public String getStudentAddress() {
		return studentAddress;
	}
        public void setStudentAddress(String studentAddress) {
		this.studentAddress = studentAddress;
        }

        @Column(name ="st_parentAddress")
        public String getParentAddress() {
		return parentAddress;
	}
        public void setParentAddress(String parentAddress) {
		this.parentAddress = parentAddress;
        }
        
}
