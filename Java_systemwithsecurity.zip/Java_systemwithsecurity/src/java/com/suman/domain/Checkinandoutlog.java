package com.suman.domain;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="CHECKINANDOUTLOG")
public class Checkinandoutlog {

    private long userprimkey;
    private String recordIdentifier ; //(like 677.11 N)
    //private String borrowerUsername;
    private String issuedDate;
    private String issuedTime;
    private String status;    //(check-in/Checkout)
    private String statusDate;
    private String finePaid;  //(if not empty)
    private String remarks;
    private int renewal;
    private String dueDate;
    private int id;

    @Column(name="Userprimkey", nullable=true)
    public long getUserprimkey() {
        return userprimkey;
    }

    public void setUserprimkey(long userprimkey) {
        this.userprimkey = userprimkey;
    }


    @Column(name="RecordIdentifier",  nullable=true)
    public String getRecordIdentifier() {
        return recordIdentifier;
    }

    public void setRecordIdentifier(String recordIdentifier) {
        this.recordIdentifier = recordIdentifier;
    }

//    @Column(name="BorrowerUsername",  nullable=true)
//    public String getBorrowerUsername() {
//        return borrowerUsername;
//    }
//
//    public void setBorrowerUsername(String borrowerUsername) {
//        this.borrowerUsername = borrowerUsername;
//    }

    @Column(name="IssuedDate",  nullable=true)
    public String getIssuedDate() {
        return issuedDate;
    }

    public void setIssuedDate(String issuedDate) {
        this.issuedDate = issuedDate;
    }

    @Column(name="IssuedTime",  nullable=true)
    public String getIssuedTime() {
        return issuedTime;
    }

    public void setIssuedTime(String issuedTime) {
        this.issuedTime = issuedTime;
    }

    @Column(name="Status",  nullable=true)
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Column(name="StatusDate",  nullable=true)
    public String getStatusDate() {
        return statusDate;
    }

    public void setStatusDate(String statusDate) {
        this.statusDate = statusDate;
    }

    @Column(name="FinePaid",  nullable=true)
    public String getFinePaid() {
        return finePaid;
    }

    public void setFinePaid(String finePaid) {
        this.finePaid = finePaid;
    }

     @Column(name="Remarks",  nullable=true)
    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }


    @Column(name="Renewal",  nullable=true)
    public int getRenewal() {
        return renewal;
    }

    public void setRenewal(int renewal) {
        this.renewal = renewal;
    }

    @Column(name="DueDate",  nullable=true)
    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }




    @Id
    @GeneratedValue
    @Column(name="ID")
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }



}
