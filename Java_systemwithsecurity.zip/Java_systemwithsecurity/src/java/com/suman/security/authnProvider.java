package com.suman.security;

import org.springframework.security.Authentication;
import org.springframework.security.AuthenticationException;
import org.springframework.security.BadCredentialsException;
import org.springframework.security.DisabledException;
import org.springframework.security.GrantedAuthority;
import org.springframework.security.GrantedAuthorityImpl;
import org.springframework.security.providers.AuthenticationProvider;
import org.springframework.security.providers.UsernamePasswordAuthenticationToken;
import org.springframework.beans.factory.InitializingBean;





import java.util.List;
import java.util.ArrayList;
//import org.apache.log4j.Logger;

//import com.suman.service.StudentService;

import com.suman.domain.Users;
//import org.hibernate.SessionFactory;
//import org.springframework.orm.hibernate3.HibernateTemplate;




public class authnProvider implements AuthenticationProvider, InitializingBean {

    public authnProvider(){ }


    private UsersService usersService;
        public void setUsersService(UsersService usersService){
            this.usersService = usersService;
        }


    //private StudentService studentDetailService;

   // public void setStudentDetailService(StudentService studentDetailService) {
   //     this.studentDetailService = studentDetailService;
   // }


    

  public boolean supports(Class authn) {
    return true;
  }

  //private static final Logger log = Logger.getLogger(authnProvider.class);


  /**
   * Authenticate the user
   * @param token    The authn object
   * @return The authentication object with more details
   * @throws AuthenticationException thrown if the user is not authenticated
   */
  public Authentication authenticate(Authentication token) throws AuthenticationException {


    UsernamePasswordAuthenticationToken upToken;
    String username = (String)token.getPrincipal();
    String password = (String)token.getCredentials();

    if(username.equals(""))
    {
        throw new BadCredentialsException("Username is Empty");
    }

    if(password.equals(""))
    {
        throw new BadCredentialsException("Password is Empty");
    }

  //
    //log.info("Got username: " + username + ", password: " + password);

    Users user = new Users();
    user.setUsername(username);
    user.setPassword(password);
    List<Users> userDetails = usersService.userLoginCheck(user);

    //this.studentService.studentLoginCheck(student)==false ||
    /* See if the username is passed or not */
    if(userDetails.size()<1 )
    {
      throw new BadCredentialsException("UserName is not supplied or is empty");
    }


    if(!userDetails.get(0).isEnabled())
    {
        throw new DisabledException("User account is disabled");
    }



    List<GrantedAuthority> gaList = new ArrayList<GrantedAuthority>(2);
    /* Every user will be given access as Anonymous -- Why? I dont know for now */



    if(userDetails.get(0).getUsertype().equals("STUDENT"))
    {
    /*XXX: lets give users permission to everybody  */
    GrantedAuthority ga1 = new GrantedAuthorityImpl("ROLE_STUDENT");
    gaList.add(ga1);
    }


    if(userDetails.get(0).getUsertype().equals("STAFF"))
    {
    /*XXX: lets give users permission to everybody  */
    GrantedAuthority ga1 = new GrantedAuthorityImpl("ROLE_STAFF");
    gaList.add(ga1);
    }


    if (userDetails.get(0).getUsertype().equals("ADMINSTRATOR"))
    {
    /*XXX: lets give users permission to everybody  */


    GrantedAuthority ga1 = new GrantedAuthorityImpl("ROLE_ADMIN");
    gaList.add(ga1);

    //GrantedAuthority ga2 = new GrantedAuthorityImpl("ROLE_STUDENT");
    //gaList.add(ga2);

    //GrantedAuthority ga3 = new GrantedAuthorityImpl("ROLE_STAFF");
    //gaList.add(ga3);

    }

    GrantedAuthority ga4 = new GrantedAuthorityImpl("ROLE_ANONYMOUS");
    gaList.add(ga4);


    /* Add the roles to the token */
    upToken = new UsernamePasswordAuthenticationToken(username, token.getCredentials(), (GrantedAuthority[]) gaList.toArray(new GrantedAuthority[gaList.size()]));
    upToken.setDetails(token.getDetails());

   // log.info("AuthnProvider: returnin token for: " + username);

    return upToken;
  }


  /**
   * This API will be called after all of the properties are set
   * @throws Exception thrown when there is any error
   */
  public final void afterPropertiesSet() throws Exception {
    //do nothing
    //log.info("---------after properties----------");
  }

}
