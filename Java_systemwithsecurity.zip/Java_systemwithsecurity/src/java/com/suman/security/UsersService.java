package com.suman.security;
import java.util.List;
import com.suman.domain.Users;

public interface UsersService {

    public List<Users> userLoginCheck(Users user);
    public boolean userEmailCheck(String emailid);
    public boolean userNameCheck(String username);
    public String userPasswordReset(String username, String emailid);
    public List<Users> userDetailsCheck(String userattribute, String userattributename);

    public void AddNewUser(Users user);
    public void UpdateUser(Users user);
    public String uniqueIdGenerator();

    public  List<Users> findUsersByUsername(String username);



}
