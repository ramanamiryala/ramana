package com.suman.security;

import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.apache.commons.lang.RandomStringUtils;
import com.suman.domain.Users;
import java.util.ArrayList;

import org.apache.commons.lang.RandomStringUtils;
import java.io.FileInputStream;
import java.io.DataInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.File;
import java.io.Writer;

import java.io.BufferedWriter;
import java.io.FileWriter;



import java.util.ResourceBundle;




public class UsersServiceImp implements UsersService {

    private HibernateTemplate hibernateTemplate;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.hibernateTemplate = new HibernateTemplate(sessionFactory);
    }

    public List<Users> userLoginCheck(Users user) {
        List<Users> userDetails;
        //List<Marks> studentDetails;
        Object row[] = new Object[2];
        row[0] = (Object) user.getUsername();
        row[1] = (Object) user.getPassword();
        userDetails = (List<Users>) hibernateTemplate.find("from Users where username = ? AND password = ? ", row);
        return userDetails;
    }


    public List<Users> userDetailsCheck(String userattribute, String userattributename) {
        List<Users> userDetails;
//        Users user = new Users();
        userDetails = (List<Users>) hibernateTemplate.find("from Users where "+ userattributename + " = ? ", userattribute);
        return userDetails;
    }



    public boolean userEmailCheck(String emailid) {
        Users user = new Users();
        user.setEmailid(emailid);
        List<Users> userDetails;

        userDetails = (List<Users>) hibernateTemplate.find("from Users where emailid = ? ", emailid);


        if (userDetails.size() < 1) {
            return false;
        } else
        {
            if(userDetails.get(0).isEnabled()){
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    public boolean userNameCheck(String username) {
        Users user = new Users();
        user.setUsername(username);
        List<Users> userDetails;

        userDetails = (List<Users>) hibernateTemplate.find("from Users where username = ? ", username);

        if (userDetails.size() < 1) {
            return false;
        } else {
            if(userDetails.get(0).isEnabled()){
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public String userPasswordReset(String username, String emailid)
    {
        String forgotmessage="";

        Users user = new Users();

        String password= RandomStringUtils.randomAlphanumeric(10);

        List<Users> userDetails;

          if (emailid.equals("") && username.equals("")) {
            forgotmessage = "Please Enter <b>usrename</b> or <b>email id </b> or <b> both</b>";
          } else if (!emailid.equals("") && username.equals(""))
          {
            if (userEmailCheck(emailid)) {

            userDetails = (List<Users>) hibernateTemplate.find("from Users where emailid = ? ", emailid);
            user = userDetails.get(0);
            user.setPassword(password);

            hibernateTemplate.update(user);


            } else {
                forgotmessage = "your <b>Email id</b> is not Valid";
            }

        } else if (emailid.equals("") && !username.equals("")) { // emailis is Empty & username is not Empty

            if (userNameCheck(username)) {

                userDetails = (List<Users>) hibernateTemplate.find("from Users where username = ? ", username);
            user = userDetails.get(0);
            user.setPassword(password);

            hibernateTemplate.update(user);

            } else {
                forgotmessage = "Your <b>username</b> is not Valid";
            }
        } else { //if both values are entered
            if (userNameCheck(username) && userEmailCheck(emailid)) {


            Object row[] = new Object[2];
            row[0] = (Object)username;
            row[1] = (Object)emailid;


            userDetails = (List<Users>) hibernateTemplate.find("from Users where username = ? AND emailid = ?", row);
            user = userDetails.get(0);
            user.setPassword(password);

            hibernateTemplate.update(user);


            } else {
                forgotmessage = "Your <b> username </b> & <b> Email id </b> are not valid";

            }



        }

        return forgotmessage;

    }

    public void AddNewUser(Users user)
    {
      hibernateTemplate.save(user);
    }

    public void UpdateUser(Users user)
    {
        // Updating is by Id always which is PRIMARY KEY
      hibernateTemplate.update(user);
    }



    public String uniqueIdGenerator() {
        String uniqueId = null;
        try {


        ArrayList IdList = new ArrayList();

            ResourceBundle bundle = ResourceBundle.getBundle("messages");
            String rootwebapp = bundle.getString("webapp.root");
            // Open the file that is the first
            // command line parameter
            FileInputStream fstream = new FileInputStream(rootwebapp + "/common/uniqueidlist.txt");
            // Get the object of DataInputStream
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String strLine;
            //Read File Line By Line
            while ((strLine = br.readLine()) != null) {
                // Print the content on the console
                IdList.add(strLine);
            }
            //Close the input stream
            in.close();


        if (IdList.size()>0) {
            boolean idUnique = false;

            while (idUnique == false) {
                uniqueId = RandomStringUtils.randomNumeric(10);

                for (int i = 0; i < IdList.size(); i++) {
                    if (uniqueId.equals(IdList.get(i).toString())) {
                        idUnique = false;
                        break;
                    }

                    if(i==IdList.size()-1)
                    {
                        idUnique = true;
                    }

                }

            }

        } else {
            uniqueId = RandomStringUtils.randomNumeric(10);
        }

        Writer output = null;

   // File file = new File(rootwebapp + "/common/uniqueidlist.txt");
    FileWriter fostream = new FileWriter(rootwebapp + "/common/uniqueidlist.txt",true);
    output = new BufferedWriter(fostream);//new FileWriter(file));


    output.write(uniqueId +"\n");
    output.close();

        }
         catch (Exception e) {//Catch exception if any
            System.err.println("Error: " + e.getMessage());
        }
                return uniqueId;


    }




    @Override
    @SuppressWarnings("unchecked")
    public  List<Users> findUsersByUsername(String username) {
        return hibernateTemplate.find("from Users where username = ? ", username);
    }



}

