package com.suman.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.Authentication;

// File Uploading
import org.springframework.web.multipart.MultipartFile;
import java.io.File;

//Recaptcha
import net.tanesha.recaptcha.ReCaptchaImpl;
import net.tanesha.recaptcha.ReCaptchaResponse;

import com.suman.domain.Users;

import com.suman.domain.Student;
import com.suman.domain.Marks;
import com.suman.domain.Attendence;
import com.suman.domain.Library;
import com.suman.domain.Staff;



import com.suman.service.StudentService;
import com.suman.security.authnProvider;



//Logger
//import org.apache.log4j.Logger;


@Controller
@SessionAttributes("student")
public class StudentController {

	private StudentService studentService;
       
        private authnProvider authProvider;

        //authProvider.



       //  private final Logger log = Logger.getLogger(StudentController.class);


	@Autowired
	public StudentController(StudentService studentService,authnProvider authProvider) {
		this.studentService = studentService;
                
                this.authProvider  = authProvider;
	}

        @RequestMapping("/StudentPerformance.htm")
        public ModelAndView performance (ModelMap model, @ModelAttribute("student") Student student)
        {

          
            model.addAttribute("marks", new Marks());
            model.addAttribute("attendence", new Attendence());
            model.addAttribute("marksList", studentService.listMarks(student));
            model.addAttribute("attendenceList",studentService.listAttendence(student));

            return new ModelAndView("StudentPerformance", model);
	}
        
        

        @RequestMapping("/library.htm")
        public ModelAndView library (ModelMap model, @ModelAttribute("student") Student student, @ModelAttribute("library1") Library library1)
        {
            model.addAttribute("library", new  Library());
            model.addAttribute("libraryList", studentService.listLibrary(student));
            model.addAttribute("librarySearch", studentService.searchLibrary(library1));

           
            return new ModelAndView("Library",model);
        }

        @RequestMapping("/uploadingFiles.htm")
        public ModelAndView uploadingFiles (ModelMap model, @ModelAttribute("student") Student student)        {
            return new ModelAndView("UploadingFiles","uploadsuccesmsg","");
        }




       private static final String destinationDir = "C:/Temp/";
        @RequestMapping("/fileUpload.htm")
        public ModelAndView fileupload(
        HttpServletRequest req,
        @RequestParam("recaptcha_challenge_field") String challenge,
        @RequestParam("recaptcha_response_field") String response,
        @RequestParam("file1") MultipartFile file1,
        @RequestParam("file2") MultipartFile file2,
        @RequestParam("file3") MultipartFile file3
     
        ) throws Exception {


    // Validate the reCAPTCHA
    String remoteAddr = req.getRemoteAddr();
    ReCaptchaImpl reCaptcha = new ReCaptchaImpl();

    // Probably don't want to hardcode your private key here but
    // just to get it working is OK...
    reCaptcha.setPrivateKey("<6LehzgsAAAAAAJ9lkrmqdsfXGfS79PLN1V3bZZWY>");
    ReCaptchaResponse reCaptchaResponse =
        reCaptcha.checkAnswer(remoteAddr, challenge, response);




    // If there are errors, then validation fails.
    if (!reCaptchaResponse.isValid()) {
        return new ModelAndView("UploadingFiles","uploadsuccesmsg", "Please Enter Correct Captcha");
    }
    else
    {
            if (file1.isEmpty() || file2.isEmpty() ||  file3.isEmpty()) {
                return new ModelAndView("UploadingFiles","uploadsuccesmsg", "Please Upload All files");
            }
            else
            {
               File destination1 = new File(destinationDir + file1.getOriginalFilename());
               File destination2 = new File(destinationDir + file2.getOriginalFilename());
               File destination3 = new File(destinationDir + file3.getOriginalFilename());

               file1.transferTo(destination1);
               file2.transferTo(destination2);
               file3.transferTo(destination3);




            return new ModelAndView("UploadSuccess", "msg", "All files are successfully uploaded.");
            }
    }
        }

}

