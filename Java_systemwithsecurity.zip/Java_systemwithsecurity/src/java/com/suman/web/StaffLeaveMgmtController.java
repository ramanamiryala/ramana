package com.suman.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.annotation.RequestParam;

import com.suman.domain.Staff;
import com.suman.domain.Users;
import com.suman.domain.LeaveApplication;
import com.suman.domain.LeaveSummary;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.util.List;
import java.util.Date;
import java.text.DateFormat;

import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;



import org.apache.log4j.Logger;
import org.apache.commons.lang.RandomStringUtils;

import com.suman.service.StaffService;
import com.suman.security.UsersService;
import com.suman.validator.StaffValidator;
import com.suman.validator.LeaveApplicationValidator;

import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.Authentication;

import com.suman.email.EmailSender;
import com.suman.email.EmailDetails;
import java.text.SimpleDateFormat;

@Controller
public class StaffLeaveMgmtController {

    private StaffService staffService;
    private StaffValidator staffValidator;
    private LeaveApplicationValidator leaveApplicationValidator;
    private UsersService usersService;
    private GenericManageableCaptchaService captchaService;
    private Logger log = Logger.getLogger(StaffLeaveMgmtController.class);
    private EmailSender emailSender;

    @Autowired
    public StaffLeaveMgmtController(StaffService staffService, StaffValidator staffValidator, GenericManageableCaptchaService captchaService,
            UsersService usersService, EmailSender emailSender, LeaveApplicationValidator leaveApplicationValidator) {
        this.staffService = staffService;
        this.staffValidator = staffValidator;
        this.captchaService = captchaService;
        this.usersService = usersService;
        this.emailSender = emailSender;
        this.leaveApplicationValidator = leaveApplicationValidator;

    }

    @RequestMapping(value = "/LeaveHome.htm")
    public ModelAndView LeaveHome(ModelMap modelMap) {
        LeaveApplication leaveApplication = new LeaveApplication();
        modelMap.addAttribute("leaveApplication", leaveApplication);

        return new ModelAndView("LeaveHome", modelMap);
    }

    @RequestMapping(value = "/LeaveApplication.htm")
    public ModelAndView LeaveApplication(ModelMap modelMap) {
        LeaveApplication leaveApplication = new LeaveApplication();
        Date currentDate = new Date();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

        String[] splitedDate = (dateFormat.format(currentDate).toString()).split("/");
//            modelMap.addAttribute("fromtime", splitedDur[0]);
        modelMap.addAttribute("fromday", splitedDate[0]);
        modelMap.addAttribute("frommonth", splitedDate[1]);
        modelMap.addAttribute("fromyear", splitedDate[2]);

        //          modelMap.addAttribute("totime", splitedDur[4]);
        modelMap.addAttribute("today", splitedDate[0]);
        modelMap.addAttribute("tomonth", splitedDate[1]);
        modelMap.addAttribute("toyear", splitedDate[2]);
        modelMap.addAttribute("leaveApplication", leaveApplication);
        staffService.formAddOptionvalues(modelMap);
        String formerror = "";
        modelMap.addAttribute("formerror", formerror);
        return new ModelAndView("Leave/LeaveApplication", modelMap);
    }

    @RequestMapping(value = "/LeaveApplicationSuccess.htm")
    public ModelAndView LeaveApplicationSuccess(
            @ModelAttribute("leaveApplication") LeaveApplication leaveApplication,
            BindingResult result, ModelMap model,
             @RequestParam(value = "change", required = false) Object change,
            @RequestParam(value = "confirm", required = false) Object confirm,
            HttpServletRequest request) throws Exception {

        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();

        if (change != null || confirm != null) {
            staffService.formAddOptionvalues(model);
            model.addAttribute("fromtime", request.getParameter("fromtime"));
            model.addAttribute("fromday", request.getParameter("fromday"));
            model.addAttribute("frommonth", request.getParameter("frommonth"));
            model.addAttribute("fromyear", request.getParameter("fromyear"));

            model.addAttribute("totime", request.getParameter("totime"));
            model.addAttribute("today", request.getParameter("today"));
            model.addAttribute("tomonth", request.getParameter("tomonth"));
            model.addAttribute("toyear", request.getParameter("toyear"));
        }
        if (change != null) {
             model.addAttribute("leaveApplication", leaveApplication);
            return new ModelAndView("Leave/LeaveApplication", model);
        }
         else //if (confirm != null)
        {


        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");

        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }
        leaveApplication.setDuration(request.getParameter("fromtime") + ";" + request.getParameter("fromday") + "/"
                + request.getParameter("frommonth") + "/" + request.getParameter("fromyear") + "-" + request.getParameter("totime") + ";" + request.getParameter("today") + "/" + request.getParameter("tomonth") + "/" + request.getParameter("toyear"));
        leaveApplicationValidator.validate(leaveApplication, result);

        if (result.hasErrors()) {
            staffService.formAddOptionvalues(model);
            return new ModelAndView("Leave/LeaveApplication", model);
        } else {
            if (!isResponseCorrect) { //Capatcha is not correct
                staffService.formAddOptionvalues(model);
                model.addAttribute("leaveApplication", leaveApplication);
                model.addAttribute("formerror", "Capacth is Invalid");
                return new ModelAndView("Leave/LeaveApplication", model);
            } else {


                List<Users> usersDetailsList = usersService.findUsersByUsername(username);

                List<Staff> staffDetails = staffService.findStaffByUserprimkey(usersDetailsList.get(0).getId());

                String staffEmailId = staffDetails.get(0).getEmailid();

                long RAUserprimkey = staffDetails.get(0).getRaUserprimkey();

                List<Staff> RADetails = staffService.findStaffByUserprimkey(RAUserprimkey);

                String RAEmailId = RADetails.get(0).getEmailid();

                Date currentDate = new Date();
                DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

                leaveApplication.setAppliedDate(dateFormat.format(currentDate).toString());
                leaveApplication.setStatusDate(dateFormat.format(currentDate).toString());
                leaveApplication.setStatusTime(currentTime.format(currentDate).toString());
                leaveApplication.setStatus("In Process");
                leaveApplication.setRaUserprimkey(RAUserprimkey);
                leaveApplication.setUserprimkey(staffDetails.get(0).getUserprimkey());
                leaveApplication.setRemarks(" ");
                String CurrentUser=usersDetailsList.get(0).getUsername();

                staffService.saveLeaveApplication(leaveApplication);

                Staff staff = new Staff();
                staff.setFirstname(staffDetails.get(0).getFirstname());
                staff.setLastname(staffDetails.get(0).getLastname());
                staff.setDesignation(staffDetails.get(0).getDesignation());

                Staff RA = new Staff();
                RA.setFirstname(RADetails.get(0).getFirstname());
                RA.setLastname(RADetails.get(0).getLastname());

                EmailDetails emailDetails = new EmailDetails();

                emailDetails.setTo(RAEmailId);
                emailDetails.setFrom("ramana.miryala@gmail.com");
                emailDetails.setCC(staffDetails.get(0).getEmailid());
                emailDetails.setSubject(" Leave Application details ");
                emailDetails.setVMTemplate("LeaveEmailTempate.vm");

                String[] InlineFilenames = new String[1];
                InlineFilenames[0] = "F:/Haritha_Tech_Project/Java_systemwithsecurity/web/img/medicalcollegeLogo.jpg";

                emailDetails.setAddInline(InlineFilenames);

                String[] AttachmentFilenames = new String[1];
                AttachmentFilenames[0] = null;

                emailDetails.setAttachment(AttachmentFilenames);
                model.addAttribute("RA", RA);
                model.addAttribute("CurrentUser", CurrentUser);
                model.addAttribute("staff", staff);
                model.addAttribute("leaveApplication", leaveApplication);

                emailSender.sendEmail(model, emailDetails);

                LeaveSummary leaveSummary = new LeaveSummary();
                leaveSummary.setUserprimkey(staffDetails.get(0).getUserprimkey());
                leaveSummary.setRaUserprimkey(RAUserprimkey);
                staffService.saveLeaveSummary(leaveSummary);
              
                List<LeaveSummary> leavesummaryDetails = staffService.findleaveSummaryByUserprimkey(usersDetailsList.get(0).getId());
                
                leaveSummary = leavesummaryDetails.get(0);


                if (leaveApplication.getTypeOfLeave().equals("CCL")) {
                    int appliedleaves = leaveSummary.getCclAppliedNo() + 1;
                    leaveSummary.setCclAppliedNo(appliedleaves);
                } else if (leaveApplication.getTypeOfLeave().equals("SL")) {
                    int appliedleaves = leaveSummary.getSlAppliedNo() + 1;
                    leaveSummary.setSlAppliedNo(appliedleaves);
                } else if (leaveApplication.getTypeOfLeave().equals("CL")) {
                    int appliedleaves = leaveSummary.getClAppliedNo() + 1;
                    leaveSummary.setClAppliedNo(appliedleaves);
                } else if (leaveApplication.getTypeOfLeave().equals("SPCL")) {
                    int appliedleaves = leaveSummary.getSpclAppliedNo() + 1;
                    leaveSummary.setSpclAppliedNo(appliedleaves);
                } else if (leaveApplication.getTypeOfLeave().equals("EL")) {
                    int appliedleaves = leaveSummary.getElAppliedNo() + 1;
                    leaveSummary.setElAppliedNo(appliedleaves);
                    }
                    staffService.saveLeaveSummary(leaveSummary);
                    return new ModelAndView("Leave/LeaveApplicationSuccess", model);
                }
            }
        }
    }

    @RequestMapping(value = "/LeaveSummary.htm")
    public ModelAndView LeaveSummary(ModelMap modelMap) {

        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();

        List<Users> usersDetailsList = usersService.findUsersByUsername(username);

        List<LeaveSummary> leavesummaryDetails = staffService.findleaveSummaryByUserprimkey(usersDetailsList.get(0).getId());
        LeaveSummary leaveSummary = new LeaveSummary();
        leaveSummary = leavesummaryDetails.get(0);
        modelMap.addAttribute("leaveSummary", leaveSummary);

        return new ModelAndView("Leave/LeaveSummary", modelMap);
    }

    @RequestMapping(value = "/LeaveView.htm")
    public ModelAndView View(ModelMap modelMap) {

        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();

        List<Users> usersDetailsList = usersService.findUsersByUsername(username);

        List<LeaveApplication> leaveAppDetails = staffService.findLeaveApplicationByUserprimkey(usersDetailsList.get(0).getId());
        modelMap.addAttribute("leaveAppDetails", leaveAppDetails);
        modelMap.addAttribute("leaveApplication", new LeaveApplication());
        modelMap.addAttribute("leaveAppDetails", staffService.findLeaveApplicationByUserprimkey(usersDetailsList.get(0).getId()));
        return new ModelAndView("Leave/LeaveView", modelMap);
    }

    @RequestMapping(value = "/LeaveUpdate.htm")
    public ModelAndView LeaveUpdate(ModelMap modelMap) {

        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();

        List<Users> usersDetailsList = usersService.findUsersByUsername(username);

        List<LeaveApplication> leaveAppDetails = staffService.findLeaveApplicationForUpdate(usersDetailsList.get(0).getId());

        modelMap.addAttribute("leaveAppDetails", leaveAppDetails);

        return new ModelAndView("Leave/LeaveUpdate", modelMap);

    }

    @RequestMapping("/LeaveModify.htm")
    public ModelAndView Modify(
            ModelMap model,
            @ModelAttribute("leaveApplication") LeaveApplication leaveApplication, HttpServletRequest request,
            @RequestParam("selection") int selection) {

        if (selection != 0) {
            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));
            LeaveApplication leaveAppDetails = leaveAppDetailsList.get(0);


            String duration = leaveAppDetails.getDuration();
            String[] splitedDur = duration.split("[\\;/\\-]");
            //"9:00 AM;1/1/1900-6:00 PM;2/3/1901";

            model.addAttribute("fromtime", splitedDur[0]);
            model.addAttribute("fromday", splitedDur[1]);
            model.addAttribute("frommonth", splitedDur[2]);
            model.addAttribute("fromyear", splitedDur[3]);

            model.addAttribute("totime", splitedDur[4]);
            model.addAttribute("today", splitedDur[5]);
            model.addAttribute("tomonth", splitedDur[6]);
            model.addAttribute("toyear", splitedDur[7]);
            model.addAttribute("selection", selection);
            model.addAttribute("leaveAppDetails", leaveAppDetails);
            //request.getSession().setAttribute("leaveAppDetails", leaveAppDetails);


            staffService.formAddOptionvalues(model);

            return new ModelAndView("Leave/LeaveModify", model);
        } else {
            return new ModelAndView("Leave/LeaveUpdate", model);
        }

    }

    @RequestMapping("/LeaveModifySuccess.htm")
    public ModelAndView ModifySuccess(
            ModelMap model,
            @ModelAttribute("leaveAppDetails") LeaveApplication leaveApplication, BindingResult result,
            HttpServletRequest request,
            @RequestParam(value = "change", required = false) Object change,
            @RequestParam(value = "confirm", required = false) Object confirm,
            @RequestParam("selection") int selection) {
        if (change != null || confirm != null) {
            staffService.formAddOptionvalues(model);
            model.addAttribute("selection", selection);
            model.addAttribute("fromtime", request.getParameter("fromtime"));
            model.addAttribute("fromday", request.getParameter("fromday"));
            model.addAttribute("frommonth", request.getParameter("frommonth"));
            model.addAttribute("fromyear", request.getParameter("fromyear"));

            model.addAttribute("totime", request.getParameter("totime"));
            model.addAttribute("today", request.getParameter("today"));
            model.addAttribute("tomonth", request.getParameter("tomonth"));
            model.addAttribute("toyear", request.getParameter("toyear"));
        }

        if (change != null) {
             model.addAttribute("leaveAppDetails", leaveApplication);

            return new ModelAndView("Leave/LeaveModify", model);
        } else //if (confirm != null) 
        {
            model.addAttribute("selection", selection);

            LeaveApplication leaveAppDetails = staffService.findLeaveApplicationById((selection)).get(0);

             List<Users> usersDetailsList = usersService.findUsersById(leaveAppDetails.getUserprimkey());

            List<Staff> staffDetails = staffService.findStaffByUserprimkey(usersDetailsList.get(0).getId());
            String staffEmailId = staffDetails.get(0).getEmailid();
            long RAUserprimkey = staffDetails.get(0).getRaUserprimkey();

            List<Staff> RADetails = staffService.findStaffByUserprimkey(RAUserprimkey);
            String RAEmailId = RADetails.get(0).getEmailid();

            // Checking Capatch Response
            boolean isResponseCorrect = false;
            String captchaId = request.getSession().getId();
            String response = request.getParameter("j_captcha_response");

            try {
                if (response != null) {
                    isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                }

            } catch (CaptchaServiceException e) {
                log.error("Problem Jcaptcha settings ", e);
            }

            leaveApplication.setDuration(request.getParameter("fromtime") + ";" + request.getParameter("fromday") + "/"
                    + request.getParameter("frommonth") + "/" + request.getParameter("fromyear") + "-" + request.getParameter("totime") + ";" + request.getParameter("today") + "/" + request.getParameter("tomonth") + "/" + request.getParameter("toyear"));

          

            leaveApplicationValidator.validate(leaveApplication, result);

            if (result.hasErrors()) {
                model.addAttribute("leaveAppDetails", leaveApplication);
                staffService.formAddOptionvalues(model);
                return new ModelAndView("Leave/LeaveModify", model);
            } else {
                if (!isResponseCorrect) { //Capatcha is not correct
                    model.addAttribute("leaveAppDetails", leaveApplication);
                    staffService.formAddOptionvalues(model);
                    model.addAttribute("formerror", "Capacth is Invalid");
                    return new ModelAndView("Leave/LeaveModify", model);
                } else {

                    Date currentDate = new Date();
                    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                    DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");


                    // leaveApplication.setId(selection);
                    leaveApplication.setAppliedDate(dateFormat.format(currentDate).toString());
                    leaveApplication.setStatusDate(dateFormat.format(currentDate).toString());
                    leaveApplication.setStatusTime(currentTime.format(currentDate).toString());
                    leaveApplication.setStatus("In Process");
                    // leaveApplication.setReportingAuthority(leaveAppDetailsList.get(0).getReportingAuthority());
                    // leaveApplication.setUsername(leaveAppDetailsList.get(0).getUsername());
                    leaveApplication.setRemarks(" ");
                    leaveApplication.setUserprimkey(leaveAppDetails.getUserprimkey());
                    leaveApplication.setRaUserprimkey(leaveAppDetails.getRaUserprimkey());
                    leaveApplication.setId(selection);

//                    leaveApplication.setDays(leaveAppDetails.getDays());
//                    leaveApplication.setReason(leaveAppDetails.getReason());
//                    //leaveApplication.setTypeOfLeave(leaveAppDetails.getTypeOfLeave());

                    staffService.saveLeaveApplication(leaveApplication);
                    Staff staff = new Staff();
                    staff.setFirstname(staffDetails.get(0).getFirstname());
                    staff.setLastname(staffDetails.get(0).getLastname());
                    staff.setDesignation(staffDetails.get(0).getDesignation());

                    Staff RA = new Staff();
                    RA.setFirstname(RADetails.get(0).getFirstname());
                    RA.setLastname(RADetails.get(0).getLastname());

                    EmailDetails emailDetails = new EmailDetails();
                    emailDetails.setTo(RAEmailId);
                    //emailDetails.setFrom("bharathsuman.g5@gmail.com");
                    emailDetails.setFrom("ramana.miryala@gmail.com");
                    emailDetails.setSubject("Leave Modify Application details");
                    emailDetails.setVMTemplate("LeaveEmailTempate.vm");

                    String[] InlineFilenames = new String[1];
                    InlineFilenames[0] = "F:/Haritha_Tech_Project/Java_systemwithsecurity/web/img/medicalcollegeLogo.jpg";

                    emailDetails.setAddInline(InlineFilenames);

                    String[] AttachmentFilenames = new String[1];
                    AttachmentFilenames[0] = null;

                    emailDetails.setAttachment(AttachmentFilenames);

                    String CurrentUser=usersDetailsList.get(0).getUsername();
                    
                    model.addAttribute("CurrentUser", CurrentUser);
                    model.addAttribute("RA", RA);
                    model.addAttribute("staff", staff);
                    model.addAttribute("leaveApplication", leaveApplication);

                    emailSender.sendEmail(model, emailDetails);
                    // staffService.formAddOptionvalues(model);
                    return new ModelAndView("Leave/LeaveModifySuccess", model);
                }
            }
        }
    }

    @RequestMapping("/LeaveRemind.htm")
    public ModelAndView Remind(
            ModelMap model,
            HttpServletRequest request,
            @RequestParam("selection") int selection) {

        if (selection != 0) {

            Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
            String username = userauth.getPrincipal().toString();

            List<Users> usersDetailsList = usersService.findUsersByUsername(username);

            List<Staff> staffDetails = staffService.findStaffByUserprimkey(usersDetailsList.get(0).getId());
            String staffEmailId = staffDetails.get(0).getEmailid();
            long RAUserprimkey = staffDetails.get(0).getRaUserprimkey();

            List<Staff> RADetails = staffService.findStaffByUserprimkey(RAUserprimkey);
            String RAEmailId = RADetails.get(0).getEmailid();

            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));
            LeaveApplication leaveApplication = new LeaveApplication();
            leaveApplication = leaveAppDetailsList.get(0);

            Staff staff = new Staff();
            staff.setFirstname(staffDetails.get(0).getFirstname());
            staff.setLastname(staffDetails.get(0).getLastname());
            staff.setDesignation(staffDetails.get(0).getDesignation());

            Staff RA = new Staff();
            RA.setFirstname(RADetails.get(0).getFirstname());
            RA.setLastname(RADetails.get(0).getLastname());

            EmailDetails emailDetails = new EmailDetails();
            emailDetails.setTo(RAEmailId);

            //emailDetails.setFrom("bharathsuman.g5@gmail.com");
            emailDetails.setFrom("ramana.miryala@gmail.com");
            emailDetails.setSubject("LeaveRemind Application details");
            emailDetails.setVMTemplate("LeaveEmailTempate.vm");

            String[] InlineFilenames = new String[1];
            InlineFilenames[0] = "F:/Haritha_Tech_Project/Java_systemwithsecurity/web/img/medicalcollegeLogo.jpg";

            emailDetails.setAddInline(InlineFilenames);

            String[] AttachmentFilenames = new String[1];
            AttachmentFilenames[0] = null;

            emailDetails.setAttachment(AttachmentFilenames);

            String CurrentUser=usersDetailsList.get(0).getUsername();

            model.addAttribute("CurrentUser", CurrentUser);
            model.addAttribute("RA", RA);
            model.addAttribute("staff", staff);
            model.addAttribute("leaveApplication", leaveApplication);

            emailSender.sendEmail(model, emailDetails);
            staffService.formAddOptionvalues(model);

            return new ModelAndView("Leave/LeaveRemind", model);
        } else {
            return new ModelAndView("Leave/LeaveUpdate", model);
        }

    }

    @RequestMapping("/LeaveCancel.htm")
    public ModelAndView Cancel(
            ModelMap model,
            @RequestParam("selection") int selection) {

        if (selection != 0) {

            Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
            String username = userauth.getPrincipal().toString();

            List<Users> usersDetailsList = usersService.findUsersByUsername(username);

            List<Staff> staffDetails = staffService.findStaffByUserprimkey(usersDetailsList.get(0).getId());
            String staffEmailId = staffDetails.get(0).getEmailid();
            long RAUserprimkey = staffDetails.get(0).getRaUserprimkey();

            List<Staff> RADetails = staffService.findStaffByUserprimkey(RAUserprimkey);
            String RAEmailId = RADetails.get(0).getEmailid();

            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));

            LeaveApplication leaveApplication = new LeaveApplication();

            leaveApplication = leaveAppDetailsList.get(0);

            Date currentDate = new Date();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

            leaveApplication.setStatus("Cancelled");
            leaveApplication.setStatusDate(dateFormat.format(currentDate).toString());
            leaveApplication.setStatusTime(currentTime.format(currentDate).toString());

            staffService.saveLeaveApplication(leaveApplication);


            Staff staff = new Staff();
            staff.setFirstname(staffDetails.get(0).getFirstname());
            staff.setLastname(staffDetails.get(0).getLastname());
            staff.setDesignation(staffDetails.get(0).getDesignation());

            Staff RA = new Staff();
            RA.setFirstname(RADetails.get(0).getFirstname());
            RA.setLastname(RADetails.get(0).getLastname());

            EmailDetails emailDetails = new EmailDetails();

            emailDetails.setTo(RAEmailId);

            //emailDetails.setFrom("bharathsuman.g5@gmail.com");
            emailDetails.setFrom("ramana.miryala@gmail.com");
            emailDetails.setSubject("LeaveCancel Application details");
            emailDetails.setVMTemplate("LeaveEmailTempate.vm");

            String[] InlineFilenames = new String[1];
            InlineFilenames[0] = "F:/Haritha_Tech_Project/Java_systemwithsecurity/web/img/medicalcollegeLogo.jpg";

            emailDetails.setAddInline(InlineFilenames);

            String[] AttachmentFilenames = new String[1];
            AttachmentFilenames[0] = null;

            emailDetails.setAttachment(AttachmentFilenames);

            String CurrentUser=usersDetailsList.get(0).getUsername();

            model.addAttribute("CurrentUser", CurrentUser);
            model.addAttribute("RA", RA);
            model.addAttribute("staff", staff);
            model.addAttribute("leaveApplication", leaveApplication);

            emailSender.sendEmail(model, emailDetails);

            List<LeaveSummary> leavesummaryDetails = staffService.findleaveSummaryByUserprimkey(usersDetailsList.get(0).getId());
            LeaveSummary leaveSummary = new LeaveSummary();
            leaveSummary = leavesummaryDetails.get(0);


            if (leaveApplication.getTypeOfLeave().equals("CCL")) {
                int canceledleaves = leaveSummary.getCclcancel() + 1;
                leaveSummary.setCclcancel(canceledleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("SPCL")) {
                int canceledleaves = leaveSummary.getSpclcancel() + 1;
                leaveSummary.setSpclcancel(canceledleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("CL")) {
                int canceledleaves = leaveSummary.getClcancel() + 1;
                leaveSummary.setClcancel(canceledleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("SL")) {
                int canceledleaves = leaveSummary.getSlcancel() + 1;
                leaveSummary.setSlcancel(canceledleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("EL")) {
                int canceledleaves = leaveSummary.getElcancel() + 1;
                leaveSummary.setElcancel(canceledleaves);
            }

            staffService.saveLeaveSummary(leaveSummary);


            return new ModelAndView("Leave/LeaveCancel", model);
        } else {
            return new ModelAndView("Leave/LeaveUpdate", model);
        }

    }

    @RequestMapping(value = "/Approver.htm")
    public ModelAndView Approver(ModelMap modelMap) {

        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();

        List<Users> usersDetailsList = usersService.findUsersByUsername(username);

        List<LeaveApplication> leaveAppDetails = staffService.findLeaveApplicationByRAUserprimkey(usersDetailsList.get(0).getId());

         String CurrentUser=usersDetailsList.get(0).getUsername();

        modelMap.addAttribute("CurrentUser", CurrentUser);
        modelMap.addAttribute("leaveAppDetails", leaveAppDetails);
        return new ModelAndView("Leave/Approver", modelMap);
    }

    @RequestMapping("/ApproverLeaveAccept.htm")
    public ModelAndView ApproverLeaveAccept(
            ModelMap model, HttpServletRequest request,
            @RequestParam("selection") int selection) {

        if (selection != 0) {
            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));
            LeaveApplication leaveApplication = leaveAppDetailsList.get(0);

            String duration = leaveApplication.getDuration();
            String[] splitedDur = duration.split("[\\;/\\-]");
            //"9:00 AM;1/1/1900-6:00 PM;2/3/1901";

            model.addAttribute("fromtime", splitedDur[0]);
            model.addAttribute("fromday", splitedDur[1]);
            model.addAttribute("frommonth", splitedDur[2]);
            model.addAttribute("fromyear", splitedDur[3]);

            model.addAttribute("totime", splitedDur[4]);
            model.addAttribute("today", splitedDur[5]);
            model.addAttribute("tomonth", splitedDur[6]);
            model.addAttribute("toyear", splitedDur[7]);
            model.addAttribute("selection", selection);
            model.addAttribute("leaveApplication", leaveApplication);

            staffService.formAddOptionvalues(model);
            return new ModelAndView("Leave/ApproverLeaveAccept", model);
        } else {
            return new ModelAndView("Leave/Approver", model);
        }

    }

    @RequestMapping("/ApproverAcceptLeaveConfirm.htm")
    public ModelAndView ApproverLeaveConfirm(
            ModelMap model,
            @ModelAttribute("leaveApplication") LeaveApplication leaveApplication,
            HttpServletRequest request,
            @RequestParam(value = "change", required = false) Object change,
            @RequestParam(value = "confirm", required = false) Object confirm,
            @RequestParam("selection") int selection) {

        if (change != null || confirm != null) {

       // model.addAttribute("leaveApplication", leaveApplication);
        model.addAttribute("selection", selection);
        model.addAttribute("fromtime", request.getParameter("fromtime"));
        model.addAttribute("fromday", request.getParameter("fromday"));
        model.addAttribute("frommonth", request.getParameter("frommonth"));
        model.addAttribute("fromyear", request.getParameter("fromyear"));

        model.addAttribute("totime", request.getParameter("totime"));
        model.addAttribute("today", request.getParameter("today"));
        model.addAttribute("tomonth", request.getParameter("tomonth"));
        model.addAttribute("toyear", request.getParameter("toyear"));
        }
        if (change != null) {
             model.addAttribute("leaveApplication", leaveApplication);
            return new ModelAndView("Leave/ApproverLeaveAccept", model);
        }
        else //if (confirm != null)
        {
            
        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");

        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
            }
        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }
        if (!isResponseCorrect) { //Capatcha is not correct
            staffService.formAddOptionvalues(model);
            model.addAttribute("formerror", "Capacth is Invalid");
            return new ModelAndView("Leave/ApproverLeaveAccept", model);
        } else {
            //}
            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));

            List<Users> usersDetailsList = usersService.findUsersById(leaveAppDetailsList.get(0).getUserprimkey());

            Date currentDate = new Date();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

            leaveApplication.setId(selection);
            leaveApplication.setStatusDate(dateFormat.format(currentDate).toString());
            leaveApplication.setStatusTime(currentTime.format(currentDate).toString());
            leaveApplication.setAppliedDate(leaveAppDetailsList.get(0).getAppliedDate());
            leaveApplication.setRaUserprimkey(leaveAppDetailsList.get(0).getRaUserprimkey());
            leaveApplication.setUserprimkey(leaveAppDetailsList.get(0).getUserprimkey());
            leaveApplication.setStatus("Accepted");
            leaveApplication.setDuration(request.getParameter("fromtime") + ";" + request.getParameter("fromday") + "/"
                    + request.getParameter("frommonth") + "/" + request.getParameter("fromyear") + "-" + request.getParameter("totime") + ";" + request.getParameter("today") + "/" + request.getParameter("tomonth") + "/" + request.getParameter("toyear"));

            staffService.saveLeaveApplication(leaveApplication);
            List<Staff> staffDetails = staffService.findStaffByUserprimkey(leaveApplication.getUserprimkey());

            Staff staff = new Staff();
            //staff =staffDetails.get(0);
            staff.setFirstname(staffDetails.get(0).getFirstname());
            staff.setLastname(staffDetails.get(0).getLastname());
            staff.setDesignation(staffDetails.get(0).getDesignation());
            List<Staff> RADetails = staffService.findStaffByUserprimkey(leaveApplication.getRaUserprimkey());

            Staff RA = new Staff();
            // RA=RADetails.get(0);
            RA.setFirstname(RADetails.get(0).getFirstname());
            RA.setLastname(RADetails.get(0).getLastname());

            EmailDetails emailDetails = new EmailDetails();
            emailDetails.setTo(staffDetails.get(0).getEmailid());
            emailDetails.setFrom("ramana.miryala@gmail.com");
            emailDetails.setCC(RADetails.get(0).getEmailid());
            emailDetails.setSubject("Accepted Leave Application details");
            emailDetails.setVMTemplate("LeaveEmailTempate.vm");

            String[] InlineFilenames = new String[1];
            InlineFilenames[0] = "F:/Haritha_Tech_Project/Java_systemwithsecurity/web/img/medicalcollegeLogo.jpg";
            emailDetails.setAddInline(InlineFilenames);

            String[] AttachmentFilenames = new String[1];
            AttachmentFilenames[0] = null;

            emailDetails.setAttachment(AttachmentFilenames);

            String CurrentUser=usersDetailsList.get(0).getUsername();

            model.addAttribute("CurrentUser", CurrentUser);
            model.addAttribute("RA", RA);
            model.addAttribute("staff", staff);
            model.addAttribute("leaveApplication", leaveApplication);

            emailSender.sendEmail(model, emailDetails);

            List<LeaveSummary> leavesummaryDetails = staffService.findleaveSummaryByUserprimkey(leaveApplication.getUserprimkey());
            LeaveSummary leaveSummary = new LeaveSummary();
            leaveSummary = leavesummaryDetails.get(0);

            if (leaveApplication.getTypeOfLeave().equals("CCL")) {
                int Acceptedleaves = leaveSummary.getCclAccepted() + 1;
                leaveSummary.setCclAccepted(Acceptedleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("SPCL")) {
                int Acceptedleaves = leaveSummary.getSpclAccepted() + 1;
                leaveSummary.setSpclAccepted(Acceptedleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("CL")) {
                int Acceptedleaves = leaveSummary.getClAccepted() + 1;
                leaveSummary.setClAccepted(Acceptedleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("SL")) {
                int Acceptedleaves = leaveSummary.getSlAccepted() + 1;
                leaveSummary.setSlAccepted(Acceptedleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("EL")) {
                    int Acceptedleaves = leaveSummary.getElAccepted() + 1;
                    leaveSummary.setElAccepted(Acceptedleaves);
                }
                staffService.saveLeaveSummary(leaveSummary);
                return new ModelAndView("Leave/ApproverAcceptLeaveConfirm", model);
            }
        }
    }

    @RequestMapping("/ApproverLeaveReject.htm")
    public ModelAndView ApproverLeaveReject(
            ModelMap model, HttpServletRequest request,
            @RequestParam("selection") int selection) {

        if (selection != 0) {
            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));
            LeaveApplication leaveApplication = leaveAppDetailsList.get(0);

            String duration = leaveApplication.getDuration();
            String[] splitedDur = duration.split("[\\;/\\-]");
            //"9:00 AM;1/1/1900-6:00 PM;2/3/1901";

            model.addAttribute("fromtime", splitedDur[0]);
            model.addAttribute("fromday", splitedDur[1]);
            model.addAttribute("frommonth", splitedDur[2]);
            model.addAttribute("fromyear", splitedDur[3]);

            model.addAttribute("totime", splitedDur[4]);
            model.addAttribute("today", splitedDur[5]);
            model.addAttribute("tomonth", splitedDur[6]);
            model.addAttribute("toyear", splitedDur[7]);
            model.addAttribute("selection", selection);
            model.addAttribute("leaveApplication", leaveApplication);

            staffService.formAddOptionvalues(model);

            return new ModelAndView("Leave/ApproverLeaveReject", model);
        } else {
            return new ModelAndView("Leave/Approver", model);
        }
    }

    @RequestMapping("/ApproverLeaveRejectConfirm.htm")
    public ModelAndView ApproverLeaveRejectConfirm(
            ModelMap model,
            @ModelAttribute("leaveApplication") LeaveApplication leaveApplication,
            HttpServletRequest request,
             @RequestParam(value = "change", required = false) Object change,
            @RequestParam(value = "confirm", required = false) Object confirm,
            @RequestParam("selection") int selection) {

        if (change != null || confirm != null) {
        model.addAttribute("leaveApplication", leaveApplication);
        model.addAttribute("selection", selection);
        model.addAttribute("fromtime", request.getParameter("fromtime"));
        model.addAttribute("fromday", request.getParameter("fromday"));
        model.addAttribute("frommonth", request.getParameter("frommonth"));
        model.addAttribute("fromyear", request.getParameter("fromyear"));

        model.addAttribute("totime", request.getParameter("totime"));
        model.addAttribute("today", request.getParameter("today"));
        model.addAttribute("tomonth", request.getParameter("tomonth"));
        model.addAttribute("toyear", request.getParameter("toyear"));
        }

        if (change != null) {
             model.addAttribute("leaveAppDetails", leaveApplication);
            return new ModelAndView("Leave/ApproverLeaveReject", model);
        }
         else //if (confirm != null)
        {
            
        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");

        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
            }
        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }
        if (!isResponseCorrect) { //Capatcha is not correct

            staffService.formAddOptionvalues(model);
            model.addAttribute("formerror", "Capacth is Invalid");
            return new ModelAndView("Leave/ApproverLeaveReject", model);
        } else {


            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));


            List<Users> usersDetailsList = usersService.findUsersById(leaveAppDetailsList.get(0).getUserprimkey());

            Date currentDate = new Date();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

            leaveApplication.setId(selection);
            leaveApplication.setStatusDate(dateFormat.format(currentDate).toString());
            leaveApplication.setStatusTime(currentTime.format(currentDate).toString());
            leaveApplication.setRaUserprimkey(leaveAppDetailsList.get(0).getRaUserprimkey());
            leaveApplication.setUserprimkey(leaveAppDetailsList.get(0).getUserprimkey());
            leaveApplication.setStatus("Rejected");
            leaveApplication.setAppliedDate(leaveAppDetailsList.get(0).getAppliedDate());

            leaveApplication.setDuration(request.getParameter("fromtime") + ";" + request.getParameter("fromday") + "/"
                    + request.getParameter("frommonth") + "/" + request.getParameter("fromyear") + "-" + request.getParameter("totime") + ";" + request.getParameter("today") + "/" + request.getParameter("tomonth") + "/" + request.getParameter("toyear"));

            staffService.saveLeaveApplication(leaveApplication);

            List<Staff> staffDetails = staffService.findStaffByUserprimkey(leaveApplication.getUserprimkey());
            Staff staff = new Staff();
            staff.setFirstname(staffDetails.get(0).getFirstname());
            staff.setLastname(staffDetails.get(0).getLastname());
            staff.setDesignation(staffDetails.get(0).getDesignation());

            List<Staff> RADetails = staffService.findStaffByUserprimkey(leaveApplication.getRaUserprimkey());

            Staff RA = new Staff();
            RA.setFirstname(RADetails.get(0).getFirstname());
            RA.setLastname(RADetails.get(0).getLastname());

            EmailDetails emailDetails = new EmailDetails();
            emailDetails.setTo(staffDetails.get(0).getEmailid());
            emailDetails.setFrom("ramana.miryala@gmail.com");
            emailDetails.setCC(RADetails.get(0).getEmailid());
            emailDetails.setSubject("Rejected Leave Application details");
            emailDetails.setVMTemplate("LeaveEmailTempate.vm");

            String[] InlineFilenames = new String[1];
            InlineFilenames[0] = "F:/Haritha_Tech_Project/Java_systemwithsecurity/web/img/medicalcollegeLogo.jpg";

            emailDetails.setAddInline(InlineFilenames);

            String[] AttachmentFilenames = new String[1];
            AttachmentFilenames[0] = null;

            emailDetails.setAttachment(AttachmentFilenames);

            String CurrentUser=usersDetailsList.get(0).getUsername();

            model.addAttribute("CurrentUser", CurrentUser);
            model.addAttribute("RA", RA);
            model.addAttribute("staff", staff);
            model.addAttribute("leaveApplication", leaveApplication);

            emailSender.sendEmail(model, emailDetails);

            List<LeaveSummary> leavesummaryDetails = staffService.findleaveSummaryByUserprimkey(leaveApplication.getUserprimkey());
            LeaveSummary leaveSummary = new LeaveSummary();
            leaveSummary = leavesummaryDetails.get(0);
            if (leaveApplication.getTypeOfLeave().equals("CCL")) {
                int rejectleaves = leaveSummary.getCclRejectedNo() + 1;
                leaveSummary.setCclRejectedNo(rejectleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("SPCL")) {
                int rejectleaves = leaveSummary.getSpclRejectedNo() + 1;
                leaveSummary.setSpclRejectedNo(rejectleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("CL")) {
                int rejectleaves = leaveSummary.getClRejectedNo() + 1;
                leaveSummary.setClRejectedNo(rejectleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("SL")) {
                int rejectleaves = leaveSummary.getSlRejectedNo() + 1;
                leaveSummary.setSlRejectedNo(rejectleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("EL")) {
                int rejectleaves = leaveSummary.getElRejectedNo() + 1;
                    leaveSummary.setElRejectedNo(rejectleaves);
                }
                staffService.saveLeaveSummary(leaveSummary);
                return new ModelAndView("Leave/ApproverLeaveRejectConfirm", model);
            }
        }
    }
}
