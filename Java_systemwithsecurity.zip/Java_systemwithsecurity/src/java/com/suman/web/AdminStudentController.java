package com.suman.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.annotation.RequestParam;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.PageContext;

import com.suman.domain.Student;
import com.suman.domain.Users;

import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.ArrayList;
import java.util.Properties;
import java.util.ResourceBundle;

import org.apache.commons.fileupload.FileUpload;
//import net.sf.oval.constraint.EmailCheck;


import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;

import com.suman.service.StudentService;
import com.suman.security.UsersService;
import com.suman.validator.StudentValidator;

import org.apache.log4j.Logger;
import org.apache.commons.lang.RandomStringUtils;

import javax.servlet.ServletContext;




@Controller
public class AdminStudentController {

    private StudentService studentService;
    private StudentValidator studentValidator;
    private GenericManageableCaptchaService captchaService;
    private UsersService usersService;
    private Logger log = Logger.getLogger(AdminStudentController.class);

    @Autowired
    public AdminStudentController(GenericManageableCaptchaService captchaService, StudentService studentService,
            StudentValidator studentValidator, UsersService usersService) {
        this.studentService = studentService;
        this.studentValidator = studentValidator;
        this.captchaService = captchaService;
        this.usersService = usersService;
    }

    @RequestMapping(value = "/AdminStdntReg.htm")
    public ModelAndView userForm(ModelMap modelMap) {


        //String uid=usersService.uniqueIdGenerator();
        Student student = new Student();
        modelMap.addAttribute("student", student);


        studentService.formAddOptionvalues(modelMap);

//        String formerror = "";
        //      modelMap.addAttribute("formerror", formerror);

        return new ModelAndView("admin/studentMgmt/registration", modelMap);
    }
    private static final String destinationDir = "C:/Temp/";

    @RequestMapping(value = "/AdminStdntRegDone.htm")
    public ModelAndView regSuccess(
            @ModelAttribute("student") Student student, BindingResult result, ModelMap modelMap,
            HttpServletRequest request,
            @RequestParam("file1") MultipartFile file1) throws Exception {


        student.setAdmissionDate(request.getParameter("admday") + "/" + request.getParameter("admmonth") + "/" + request.getParameter("admyear"));

        modelMap.addAttribute("admday", request.getParameter("admday"));
        modelMap.addAttribute("admmonth", request.getParameter("admmonth"));
        modelMap.addAttribute("admyear", request.getParameter("admyear"));


        student.setDateofBirth(request.getParameter("bday") + "/" + request.getParameter("bmonth") + "/" + request.getParameter("byear"));

        modelMap.addAttribute("bday", request.getParameter("bday"));
        modelMap.addAttribute("bmonth", request.getParameter("bmonth"));
        modelMap.addAttribute("byear", request.getParameter("byear"));

        student.setCurrentAddress(request.getParameter("stc_line1")+ "," + request.getParameter("stc_line2")+ ","  + request.getParameter("stc_line3"));
        modelMap.addAttribute("stc_line1", request.getParameter("stc_line1"));
        modelMap.addAttribute("stc_line2", request.getParameter("stc_line2"));
        modelMap.addAttribute("stc_line3", request.getParameter("stc_line3"));

        student.setPermanentAddress(request.getParameter("stp_line1")+ ","  + request.getParameter("stp_line2")+ ","  + request.getParameter("stp_line3"));

        modelMap.addAttribute("stp_line1", request.getParameter("stp_line1"));
        modelMap.addAttribute("stp_line2", request.getParameter("stp_line2"));
        modelMap.addAttribute("stp_line3", request.getParameter("stp_line3"));

        student.setParentsCorrespondenceAddress(request.getParameter("pc_line1")+ ","  + request.getParameter("pc_line2")+ ","  + request.getParameter("pc_line3"));

        modelMap.addAttribute("pc_line1", request.getParameter("pc_line1"));
        modelMap.addAttribute("pc_line2", request.getParameter("pc_line2"));
        modelMap.addAttribute("pc_line3", request.getParameter("pc_line3"));

        student.setAcedamicYearStudiedQE(request.getParameter("qefromyear") + "-" + request.getParameter("qetoyear"));

        modelMap.addAttribute("qefromyear", request.getParameter("qefromyear"));
        modelMap.addAttribute("qetoyear", request.getParameter("qetoyear"));

        student.setClassVIAcademicYear(request.getParameter("VIfromyear") + "-" + request.getParameter("VItoyear"));

        modelMap.addAttribute("VIfromyear", request.getParameter("VIfromyear"));
        modelMap.addAttribute("VItoyear", request.getParameter("VItoyear"));

        student.setClassVIIAcademicYear(request.getParameter("VIIfromyear") + "-" + request.getParameter("VIItoyear"));

        modelMap.addAttribute("VIIfromyear", request.getParameter("VIIfromyear"));
        modelMap.addAttribute("VIItoyear", request.getParameter("VIItoyear"));


        student.setClassVIIIAcademicYear(request.getParameter("VIIIfromyear") + "-" + request.getParameter("VIIItoyear"));

        modelMap.addAttribute("VIIIfromyear", request.getParameter("VIIIfromyear"));
        modelMap.addAttribute("VIIItoyear", request.getParameter("VIIItoyear"));

        student.setClassIXAcademicYear(request.getParameter("IXfromyear") + "-" + request.getParameter("IXtoyear"));

        modelMap.addAttribute("IXfromyear", request.getParameter("IXfromyear"));
        modelMap.addAttribute("IXtoyear", request.getParameter("IXtoyear"));


        student.setClassXAcademicYear(request.getParameter("Xfromyear") + "-" + request.getParameter("Xtoyear"));

        modelMap.addAttribute("Xfromyear", request.getParameter("Xfromyear"));
        modelMap.addAttribute("Xtoyear", request.getParameter("Xtoyear"));

        student.setClassXIAcademicYear(request.getParameter("XIfromyear") + "-" + request.getParameter("XItoyear"));

        modelMap.addAttribute("XIfromyear", request.getParameter("XIfromyear"));
        modelMap.addAttribute("XItoyear", request.getParameter("XItoyear"));

        student.setClassXIIAcademicYear(request.getParameter("XIIfromyear") + "-" + request.getParameter("XIItoyear"));

        modelMap.addAttribute("XIIfromyear", request.getParameter("XIIfromyear"));
        modelMap.addAttribute("XIItoyear", request.getParameter("XIItoyear"));



//        studentValidator.validateStudentRegistration(student, result);
  //      if (result.hasErrors()) {
    //        studentService.formAddOptionvalues(modelMap);
//    //        modelMap.addAttribute("formerror", "");
        //    return new ModelAndView("AdminStdntReg", modelMap);
        //}


        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");


        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                log.error("Captcha is valid..Great!");
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }




        if (file1.isEmpty()) {
            studentService.formAddOptionvalues(modelMap);
            modelMap.addAttribute("fileerror", "File is Empty");
            return new ModelAndView("admin/studentMgmt/registration", modelMap);
        } else {
            if (!isResponseCorrect) { //Capatcha is not correct

                studentService.formAddOptionvalues(modelMap);
                modelMap.addAttribute("captchaerror", "Capacth is Invalid");
                return new ModelAndView("admin/studentMgmt/registration", modelMap);
            } else {

                //Setting Username & Passwords
                student.setPassword(RandomStringUtils.randomAlphanumeric(10));
                student.setUsername(student.getEmailId());

                if ((usersService.userDetailsCheck(student.getUsername(), "username").size() < 1)
                        && (usersService.userDetailsCheck(student.getEmailId(), "emailid").size() < 1)) {
//Checking Username & emailid details

                    // College Registarion Number ----> for Old student

                    //Setting Username & Password for Parents
                    student.setParentsUsername(student.getParentsEmailid());
                    student.setParentsPassword(RandomStringUtils.randomAlphanumeric(10));

                    
                    Users user = new Users();
                    user.setUsername(student.getUsername());
                    user.setEnabled(true);
                    user.setPassword(student.getPassword());
                    user.setUsertype("STUDENT");
                    user.setEmailid(student.getEmailId());
                    //Saving into Common Users Table
                    usersService.AddNewUser(user);
                    student.setUserprimkey(usersService.findUsersByUsername(student.getUsername()).get(0).getId());
                    // Saving Student
                    studentService.saveStudent(student);

                    

                    // Saving Student's Parents Login Details
                    studentService.saveStudent(student);

                    Users user_parent = new Users();
                    user_parent.setUsername(student.getParentsUsername());
                    user_parent.setEnabled(true);
                    user_parent.setPassword(student.getParentsPassword());
                    user_parent.setUsertype("PARENTS");
                    user_parent.setEmailid(student.getParentsEmailid());
                    //Saving into Common Users Table
                    usersService.AddNewUser(user_parent);



                    List<Student> studentDetails = studentService.findStudentByUsername(student.getUsername());

                    ResourceBundle bundle = ResourceBundle.getBundle("messages");
                    String rootwebapp = bundle.getString("webapp.root");

                    String filename = file1.getOriginalFilename().toString();

                    int dotPosi = filename.lastIndexOf(".");
                    String extension = filename.substring(dotPosi);
                    String NewFilename = Long.toString(studentDetails.get(0).getId()) + extension;


                    String profPhotoContextPath = "/profile_photos/student/" + NewFilename;
                    String profPhotoAbsolutePathName = rootwebapp + profPhotoContextPath;


                    File file = new File("Student.class");


                    //file1.transferTo(new File(profPhotoAbsolutePathName));

                    file1.transferTo(new File(profPhotoContextPath));

                    student.setId(studentDetails.get(0).getId());
                    student.setProfilePhotoFileName(NewFilename);

                    //Updating the Student table with Profile File name
                    studentService.updateStudent(student);

                    return new ModelAndView("admin/studentMgmt/registrationSuccess");

                } else {

                    studentService.formAddOptionvalues(modelMap);
                    modelMap.addAttribute("formerror", "User with given details already exists. <br> Please change Email Id <br>");
                    return new ModelAndView("admin/studentMgmt/registration", modelMap);

                }
            }

        }

    }

    @RequestMapping("/AdminStdntProfSearch.htm")
    public ModelAndView studentSearch(ModelMap model, @ModelAttribute("student") Student student, @ModelAttribute("student1") Student student1) {

        model.addAttribute("student", new Student());

        List<Student> studentSearch = studentService.searchStudent(student1);
        model.addAttribute("studentSearch", studentSearch);




        return new ModelAndView("AdminStdntProfSearch", model);

    }

    @RequestMapping("/AdminStdntProfUpdate.htm")
    public ModelAndView update(
            ModelMap model,
            @ModelAttribute("student") Student student,
            @RequestParam("selection") int selection) {
        if (selection != 0) {
            student.setId(selection);

            studentService.retrieveStudent(student);

            Users user = new Users();
            user.setUsername(student.getUsername());
            user.setPassword(student.getPassword());


            List<Users> userdetails = usersService.userLoginCheck(user);

            long userid = userdetails.get(0).getId();





            return new ModelAndView("AdminStdntProfUpdate", "userid", userid);
        } else {
            return new ModelAndView("AdminStdntProfSearch", model);
        }

    }

    @RequestMapping(value = "/AdminStdntProfUpdateDone.htm")
    public ModelAndView UpdateSuccess(
            @ModelAttribute("student") Student student, BindingResult result, ModelMap model,
            HttpServletRequest request,
            @RequestParam("userid") int userid,//user's Primary Key
            @RequestParam("file1") MultipartFile file1) throws Exception {

        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");


        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                log.error("Captcha is valid..Great!");
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        studentValidator.validateRegistration(student, result);
        if (result.hasErrors()) {
            return new ModelAndView("AdminStdntProfUpdate");
        }


        if (file1.isEmpty()) {
            return new ModelAndView("AdminStdntProfUpdate", "captchaerror", "Empty File");
        } else {
            if (!isResponseCorrect) {
                return new ModelAndView("AdminStdntProfUpdate", "captchaerror", "Invalid Captcha");
            } else {

                Users user = new Users();
                user.setUsername(student.getUsername());
                user.setEnabled(true);
                user.setPassword(student.getPassword());
                user.setEmailid(student.getEmailId());
                user.setId(userid); // Userid is the Primarykey in Users table
                user.setUsertype("STUDENT");


                // Updation is to be by id(Primary key) matching
                usersService.UpdateUser(user);
                studentService.updateStudent(student);

                String filename = file1.getOriginalFilename().toString();

                int dotPosi = filename.lastIndexOf(".");
                String extension = filename.substring(dotPosi);

                File destination1 = new File(destinationDir + student.getUsername() + extension);

                file1.transferTo(destination1);
                return new ModelAndView("AdminStdntProfUpdateDone");


            }
        }

    }
}



