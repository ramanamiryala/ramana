package com.suman.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.annotation.RequestParam;

import com.suman.domain.Student;
import com.suman.domain.Users;


import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;


import com.suman.service.StudentService;
import com.suman.security.UsersService;
import com.suman.validator.StudentValidator;

import org.apache.log4j.Logger;

@Controller
public class AdminStudentController {

    private StudentService studentService;
    private StudentValidator studentValidator;
    private GenericManageableCaptchaService captchaService;
    private UsersService usersService;
    private Logger log = Logger.getLogger(AdminStudentController.class);

    @Autowired
    public AdminStudentController(StudentService studentService, StudentValidator studentValidator, GenericManageableCaptchaService captchaService, UsersService usersService) {
        this.studentService = studentService;
        this.studentValidator = studentValidator;
        this.usersService = usersService;
        this.captchaService = captchaService;
    }

    @RequestMapping(value = "/studentRegistration.htm")
    public ModelAndView userForm(ModelMap modelMap) {
        Student student = new Student();
        modelMap.addAttribute("student", student);
        return new ModelAndView("NewStudentForm", modelMap);
    }
    private static final String destinationDir = "C:/Temp/";

    @RequestMapping(value = "/stregsuccess.htm")
    public ModelAndView regSuccess(
            @ModelAttribute("student") Student student, BindingResult result, ModelMap model,
            HttpServletRequest request,
            @RequestParam("file1") MultipartFile file1) throws Exception {


        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");


        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                log.error("Captcha is valid..Great!");
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        studentValidator.validateRegistration(student, result);
        if (result.hasErrors()) {
            return new ModelAndView("NewStudentForm");
        }


        if (file1.isEmpty()) {
            return new ModelAndView("NewStudentForm", "formerror", "File is Empty");
        } else {
            if (!isResponseCorrect) { //Capatcha is not correct
                return new ModelAndView("NewStudentForm", "formerror", "Capacth is Invalid");
            } else {

                if (!studentService.studentLoginCheck(student)) {

                    Users user = new Users();

                    user.setUsername(student.getName());
                    user.setEnabled(true);
                    user.setPassword(student.getPassword());
                    user.setUsertype("STUDENT");
                    user.setEmailid(student.getEmailid());



                    usersService.AddNewUser(user);
                    studentService.saveStudent(student);


                    String filename = file1.getOriginalFilename().toString();

                    int dotPosi = filename.lastIndexOf(".");
                    String extension = filename.substring(dotPosi);

                    File destination1 = new File(destinationDir + student.getName() + extension);

                    String imgloc = "C:\\Temp\\" + student.getName() + extension;


                    file1.transferTo(destination1);
                    return new ModelAndView("StudentRegisrtationSuccess", "imgloc", imgloc);

                } else {
                    return new ModelAndView("NewStudentForm", "formerror", "User with given details already exists. <br> Please change username & password <br>");
                }
            }

        }

    }

    @RequestMapping("/StudentSearch.htm")
    public ModelAndView studentSearch(ModelMap model, @ModelAttribute("student") Student student, @ModelAttribute("student1") Student student1) {
        //@ModelAttribute("student") Student student,
        model.addAttribute("student", new Student());

        List<Student> StudentSearch = studentService.searchStudent(student1);
        model.addAttribute("studentSearch", StudentSearch);
        //String selection = "seletion";
        //model.addAttribute("selection", selection);





        return new ModelAndView("StudentSearch", model);

    }

    @RequestMapping("/StudentUpdate.htm")
    public ModelAndView update(ModelMap model,
            //@ModelAttribute("studentSearch") List<Student> studentSearch,
            @ModelAttribute("student") Student student,
            @RequestParam("selection") int selection) {
        if (selection != 0) {
            student.setId(selection);

            studentService.retrieveStudent(student);

            return new ModelAndView("StudentUpdate.htm", model);
        } else {
            return new ModelAndView("StudentSearch", model);
        }

    }

    @RequestMapping(value = "/updateprofile.htm")
    public ModelAndView UpdateSuccess(
            @ModelAttribute("student") Student student, BindingResult result, ModelMap model,
            HttpServletRequest request,
            @RequestParam("userid") int userid,
            @RequestParam("file1") MultipartFile file1) throws Exception {

        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");


        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                log.error("Captcha is valid..Great!");
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        studentValidator.validateRegistration(student, result);
        if (result.hasErrors()) {
            return new ModelAndView("StudentUpdate");
        }


        if (file1.isEmpty()) {
            return new ModelAndView("StudentUpdate", "captchaerror", "Empty File");
        } else {
            if (!isResponseCorrect) {
                return new ModelAndView("StudentUpdate", "captchaerror", "Invalid Captcha");
            } else {

                List<Users> userDetails = usersService.userDetailsCheck(student.getName(),"username");

                Users user = new Users();
                user.setId(userDetails.get(0).getId());
                user.setUsername(student.getName());
                user.setEnabled(userDetails.get(0).isEnabled());
                user.setPassword(student.getPassword());
                user.setEmailid(student.getEmailid());
                user.setUsertype("STUDENT");

                // Updation is to be by id(Primary key) matching




                usersService.UpdateUser(user);

                studentService.updateStudent(student);

                String filename = file1.getOriginalFilename().toString();

                int dotPosi = filename.lastIndexOf(".");
                String extension = filename.substring(dotPosi);

                File destination1 = new File(destinationDir + student.getName() + extension);

                file1.transferTo(destination1);
                return new ModelAndView("updateprofile");


            }
        }

    }
}



