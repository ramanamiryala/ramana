package com.suman.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.annotation.RequestParam;

import com.suman.domain.Staff;
import com.suman.domain.Users;
import com.suman.domain.LeaveApplication;
import com.suman.domain.LeaveSummary;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.util.List;
import java.util.Date;
import java.text.DateFormat;

import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;



import org.apache.log4j.Logger;
import org.apache.commons.lang.RandomStringUtils;

import com.suman.service.StaffService;
import com.suman.security.UsersService;
import com.suman.validator.StaffValidator;

import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.Authentication;


import com.suman.email.EmailSender;
import com.suman.email.EmailDetails;
import java.text.SimpleDateFormat;

@Controller
public class AdminStaffController {

    private StaffService staffService;
    private StaffValidator staffValidator;
    private UsersService usersService;
    private GenericManageableCaptchaService captchaService;
    private Logger log = Logger.getLogger(AdminStudentController.class);
    private EmailSender emailSender;

    @Autowired
    public AdminStaffController(StaffService staffService, StaffValidator staffValidator, GenericManageableCaptchaService captchaService, UsersService usersService, EmailSender emailSender) {
        this.staffService = staffService;
        this.staffValidator = staffValidator;
        this.captchaService = captchaService;
        this.usersService = usersService;
        this.emailSender = emailSender;

    }

    @RequestMapping(value = "/staffRegistration.htm")
    public ModelAndView staffForm(ModelMap modelMap) {
        //Student student = new Student();
        Staff staff = new Staff();
        modelMap.addAttribute("staff", staff);

        staffService.formAddOptionvalues(modelMap);
        String formerror = "";
        modelMap.addAttribute("formerror", formerror);

        return new ModelAndView("NewStaffForm", modelMap);
    }
    private static final String destinationDir = "C:/Temp/";

    @RequestMapping(value = "/staffReg.htm")
    public ModelAndView regSuccess(
            @ModelAttribute("staff") Staff staff, BindingResult result, ModelMap model,
            HttpServletRequest request,
            @RequestParam("file1") MultipartFile file1) throws Exception {

        staff.setDateofbirth(request.getParameter("bday") + "/" + request.getParameter("bmonth") + "/" + request.getParameter("byear"));

        staff.setDuration1(request.getParameter("formmonthduration1") + "/" + request.getParameter("formYearduration1") + "-" + request.getParameter("tomonthduration1") + "/" + request.getParameter("toYearduration1"));
        staff.setDuration2(request.getParameter("formmonthduration2") + "/" + request.getParameter("formYearduration2") + "-" + request.getParameter("tomonthduration2") + "/" + request.getParameter("toYearduration2"));

        staff.setAcademicYear1(request.getParameter("formmonthacademicYear1") + "/" + request.getParameter("formYearacademicYear1") + "-" + request.getParameter("tomonthacademicYear1") + "/" + request.getParameter("toYearacademicYear1"));
        staff.setAcademicYear2(request.getParameter("formmonthacademicYear2") + "/" + request.getParameter("formYearacademicYear2") + "-" + request.getParameter("tomonthacademicYear2") + "/" + request.getParameter("toYearacademicYear2"));
        staff.setAcademicYear3(request.getParameter("formmonthacademicYear3") + "/" + request.getParameter("formYearacademicYear3") + "-" + request.getParameter("tomonthacademicYear3") + "/" + request.getParameter("toYearacademicYear3"));
        staff.setPassword(RandomStringUtils.randomAlphanumeric(10));
        staff.setUserid(staff.getEmailid());

        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");

        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                log.error("Captcha is valid..Great!");
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        staffValidator.validateRegistration(staff, result);

        if (result.hasErrors()) {
            staffService.formAddOptionvalues(model);
            return new ModelAndView("NewStaffForm", model);
        }

        if (file1.isEmpty()) {
            staffService.formAddOptionvalues(model);
            model.addAttribute("formerror", "file is Empty");
            return new ModelAndView("NewStaffForm", model);
        } else {
            if (!isResponseCorrect) { //Capatcha is not correct
                staffService.formAddOptionvalues(model);
                model.addAttribute("formerror", "Capacth is Invalid");
                return new ModelAndView("NewStaffForm", model);
            } else {

                if ((usersService.userDetailsCheck(staff.getUserid(), "username").size() < 1)
                        && (usersService.userDetailsCheck(staff.getEmailid(), "emailid").size() < 1)) {
//Checking Username & emailid details

                    staffService.saveStaff(staff);

                    Users user = new Users();
                    user.setUsername(staff.getUserid());
                    user.setEnabled(true);
                    user.setPassword(staff.getPassword());
                    user.setUsertype("STAFF");
                    user.setEmailid(staff.getEmailid());

                    //Saving into Common Users Table
                    usersService.AddNewUser(user);

                    List<Staff> staffDetails = staffService.findStaffByUserid(staff.getUserid());
                    ResourceBundle bundle = ResourceBundle.getBundle("messages");
                    String rootwebapp = bundle.getString("webapp.root");

                    String filename = file1.getOriginalFilename().toString();

                    int dotPosi = filename.lastIndexOf(".");
                    String extension = filename.substring(dotPosi);
                    String NewFilename = Long.toString(staffDetails.get(0).getId()) + extension;
                    String profPhotoContextPath = "/profile_photos/staff/" + NewFilename;
                    String profPhotoAbsolutePathName = rootwebapp + profPhotoContextPath;

                    file1.transferTo(new File(profPhotoAbsolutePathName));
                    staff.setId(staffDetails.get(0).getId());
                    staff.setProfilePhotoFileName(NewFilename);

                    staffService.updateStaff(staff);

                    model.addAttribute("profPhotoAbsolutePathName", profPhotoAbsolutePathName);
                    return new ModelAndView("StaffRegistrationSuccess", model);

                } else {
                    staffService.formAddOptionvalues(model);
                    model.addAttribute("formerror", "User with given details already exists. <br> Please change username & email ids <br>");
                    return new ModelAndView("NewStaffForm", model);
                }
            }

        }

    }

    @RequestMapping("/AdminStaffProfSearch.htm")
    public ModelAndView staffSearch(ModelMap model, @ModelAttribute("staff") Staff staff, @ModelAttribute("staff1") Staff staff1) {

        model.addAttribute("staff", new Staff());
        List<Staff> staffSearch = staffService.searchStaff(staff1);
        model.addAttribute("staffSearch", staffSearch);

        return new ModelAndView("AdminStaffProfSearch", model);

    }

    @RequestMapping("/AdminStaffProfUpdate.htm")
    public ModelAndView update(
            ModelMap model,
            @ModelAttribute("staff") Staff staff,
            @RequestParam("selection") int selection) {
        if (selection != 0) {
            staff.setId(selection);

            staffService.retrieveStaff(staff);

            Users user = new Users();
            user.setUsername(staff.getUserid());
            user.setPassword(staff.getPassword());

            List<Users> userdetails = usersService.userLoginCheck(user);
            long userid = userdetails.get(0).getId();

            return new ModelAndView("AdminStaffProfUpdate", "userid", userid);
        } else {
            return new ModelAndView("AdminStaffProfSearch", model);
        }

    }

    @RequestMapping(value = "/AdminStaffProfUpdateDone.htm")
    public ModelAndView UpdateSuccess(
            @ModelAttribute("staff") Staff staff, BindingResult result, ModelMap model,
            HttpServletRequest request,
            //@RequestParam("userid") int userid,//user's Primary Key
            @RequestParam("file1") MultipartFile file1) throws Exception {

        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");

        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                log.error("Captcha is valid..Great!");
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        staffValidator.validateRegistration(staff, result);


        if (result.hasErrors()) {
            return new ModelAndView("AdminStaffProfUpdate");
        }


        if (file1.isEmpty()) {
            return new ModelAndView("AdminStaffProfUpdate", "captchaerror", "Empty File");
        } else {
            if (!isResponseCorrect) {
                return new ModelAndView("AdminStaffProfUpdate", "captchaerror", "Invalid Captcha");
            } else {

                List<Users> userDetails = usersService.userDetailsCheck(staff.getUserid(), "username");

                Users user = new Users();
                user.setId(userDetails.get(0).getId());
                user.setUsername(staff.getUserid());
                user.setEnabled(userDetails.get(0).isEnabled());
                user.setPassword(staff.getPassword());
                user.setEmailid(staff.getEmailid());
                user.setUsertype("STAFF");

                usersService.UpdateUser(user);

                staffService.updateStaff(staff);
                String filename = file1.getOriginalFilename().toString();
                int dotPosi = filename.lastIndexOf(".");
                String extension = filename.substring(dotPosi);

                File destination1 = new File(destinationDir + staff.getUserid() + extension);

                file1.transferTo(destination1);
                return new ModelAndView("AdminStaffProfUpdateDone");

            }

        }
    }

    @RequestMapping(value = "/LeaveHome.htm")
    public ModelAndView LeaveHome(ModelMap modelMap) {
        LeaveApplication leaveApplication = new LeaveApplication();
        modelMap.addAttribute("leaveApplication", leaveApplication);

        return new ModelAndView("LeaveHome", modelMap);
    }

    @RequestMapping(value = "/LeaveApplication.htm")
    public ModelAndView LeaveApplication(ModelMap modelMap) {
        LeaveApplication leaveApplication = new LeaveApplication();
        modelMap.addAttribute("leaveApplication", leaveApplication);

        staffService.formAddOptionvalues(modelMap);
        String formerror = "";
        modelMap.addAttribute("formerror", formerror);

        return new ModelAndView("LeaveApplication", modelMap);
    }

    @RequestMapping(value = "/LeaveApplicationSuccess.htm")
    public ModelAndView LeaveApplicationSuccess(
            @ModelAttribute("leaveApplicatin") LeaveApplication leaveApplication,
            BindingResult result, ModelMap model,
            HttpServletRequest request) throws Exception {

        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();

        leaveApplication.setDuration(request.getParameter("fromtime") + ";" + request.getParameter("fromday") + "/"
                + request.getParameter("frommonth") + "/" + request.getParameter("fromyear") + "-" + request.getParameter("totime") + ";" + request.getParameter("today") + "/" + request.getParameter("tomonth") + "/" + request.getParameter("toyear"));

        List<Staff> staffDetails = staffService.findStaffByUserid(username);
        String staffEmailId = staffDetails.get(0).getEmailid();
        String ReportingAuthUsername = staffDetails.get(0).getReportingAuthority();

        List<Staff> RADetails = staffService.findStaffByUserid(ReportingAuthUsername);
        String RAEmailId = RADetails.get(0).getEmailid();

        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");


        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);

            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        staffValidator.validateLeaveApplication(leaveApplication, result);

        if (result.hasErrors()) {
            staffService.formAddOptionvalues(model);
            return new ModelAndView("LeaveApplication", model);
        } else {
            if (!isResponseCorrect) { //Capatcha is not correct
                staffService.formAddOptionvalues(model);
                model.addAttribute("formerror", "Capacth is Invalid");
                return new ModelAndView("LeaveApplication", model);
            } else {
                Date currentDate = new Date();
                DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

                leaveApplication.setAppliedDate(dateFormat.format(currentDate).toString());
                leaveApplication.setStatusDate(dateFormat.format(currentDate).toString());
                leaveApplication.setStatusTime(currentTime.format(currentDate).toString());
                leaveApplication.setStatus("In Process");
                leaveApplication.setReportingAuthority(ReportingAuthUsername);
                leaveApplication.setUsername(staffDetails.get(0).getUserid());
                leaveApplication.setRemarks(" ");

                staffService.saveLeaveApplication(leaveApplication);


                Staff staff = new Staff();
                staff.setFirstname(staffDetails.get(0).getFirstname());
                staff.setLastname(staffDetails.get(0).getLastname());
                staff.setDesignation(staffDetails.get(0).getDesignation());

                Staff RA = new Staff();
                RA.setFirstname(RADetails.get(0).getFirstname());
                RA.setLastname(RADetails.get(0).getLastname());

                EmailDetails emailDetails = new EmailDetails();

                emailDetails.setTo(RAEmailId);
                emailDetails.setFrom("ramana.miryala@gmail.com");
                emailDetails.setSubject(" Leave Application details ");
                emailDetails.setVMTemplate("LeaveEmailTempate.vm");

                String[] InlineFilenames = new String[1];
                InlineFilenames[0] = "F:/Haritha_Tech_Project/Java_systemwithsecurity/web/img/medicalcollegeLogo.jpg";

                emailDetails.setAddInline(InlineFilenames);

                String[] AttachmentFilenames = new String[1];
                AttachmentFilenames[0] = null;

                emailDetails.setAttachment(AttachmentFilenames);
                model.addAttribute("RA", RA);
                model.addAttribute("staff", staff);
                model.addAttribute("leaveApplication", leaveApplication);


                emailSender.sendEmail(model, emailDetails);


                List<LeaveSummary> leavesummaryDetails = staffService.findleaveSummaryByUsername(username);
                LeaveSummary leaveSummary = new LeaveSummary();
                leaveSummary = leavesummaryDetails.get(0);


                if (leaveApplication.getTypeOfLeave().equals("CCL")) {
                    int appliedleaves = leaveSummary.getCclAppliedNo() + 1;
                    leaveSummary.setCclAppliedNo(appliedleaves);
                } else if (leaveApplication.getTypeOfLeave().equals("SL")) {
                    int appliedleaves = leaveSummary.getSlAppliedNo() + 1;
                    leaveSummary.setSlAppliedNo(appliedleaves);
                } else if (leaveApplication.getTypeOfLeave().equals("CL")) {
                    int appliedleaves = leaveSummary.getClAppliedNo() + 1;
                    leaveSummary.setClAppliedNo(appliedleaves);
                } else if (leaveApplication.getTypeOfLeave().equals("SPCL")) {
                    int appliedleaves = leaveSummary.getSpclAppliedNo() + 1;
                    leaveSummary.setSpclAppliedNo(appliedleaves);
                } else if (leaveApplication.getTypeOfLeave().equals("EL")) {
                    int appliedleaves = leaveSummary.getElAppliedNo() + 1;
                    leaveSummary.setElAppliedNo(appliedleaves);
                }

                staffService.saveLeaveSummary(leaveSummary);

                return new ModelAndView("LeaveHome", model);
            }
        }


    }

    @RequestMapping(value = "/LeaveSummary.htm")
    public ModelAndView LeaveSummary(ModelMap modelMap) {

        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();

        List<LeaveSummary> leavesummaryDetails = staffService.findleaveSummaryByUsername(username);
        LeaveSummary leaveSummary = new LeaveSummary();
        leaveSummary = leavesummaryDetails.get(0);
        modelMap.addAttribute("leaveSummary", leaveSummary);

        return new ModelAndView("LeaveSummary", modelMap);
    }

    @RequestMapping(value = "/LeaveView.htm")
    public ModelAndView View(ModelMap modelMap) {

        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();

        List<LeaveApplication> leaveAppDetails = staffService.findLeaveApplicationByUsername(username);
        modelMap.addAttribute("leaveAppDetails", leaveAppDetails);
        modelMap.addAttribute("leaveApplication", new LeaveApplication());
        modelMap.addAttribute("leaveAppDetails", staffService.findLeaveApplicationByUsername(username));

        return new ModelAndView("LeaveView", modelMap);
    }

    @RequestMapping(value = "/LeaveUpdate.htm")
    public ModelAndView LeaveUpdate(ModelMap modelMap) {

        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();

        List<LeaveApplication> leaveAppDetails = staffService.findLeaveApplicationForUpdate(username);

        modelMap.addAttribute("leaveAppDetails", leaveAppDetails);

        return new ModelAndView("LeaveUpdate", modelMap);

    }

    @RequestMapping("/LeaveModify.htm")
    public ModelAndView Modify(
            ModelMap model,
            @ModelAttribute("leaveApplication") LeaveApplication leaveApplication,
            @RequestParam("selection") int selection) {

        if (selection != 0) {
            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));
            LeaveApplication leaveAppDetails = new LeaveApplication();
            leaveAppDetails = leaveAppDetailsList.get(0);


            String duration = leaveAppDetails.getDuration();
            String[] splitedDur = duration.split("[\\;/\\-]");
            //"9:00 AM;1/1/1900-6:00 PM;2/3/1901";

            model.addAttribute("fromtime", splitedDur[0]);
            model.addAttribute("fromday", splitedDur[1]);
            model.addAttribute("frommonth", splitedDur[2]);
            model.addAttribute("fromyear", splitedDur[3]);

            model.addAttribute("totime", splitedDur[4]);
            model.addAttribute("today", splitedDur[5]);
            model.addAttribute("tomonth", splitedDur[6]);
            model.addAttribute("toyear", splitedDur[7]);
            model.addAttribute("selection", selection);
            model.addAttribute("leaveAppDetails", leaveAppDetails);

            staffService.formAddOptionvalues(model);

            return new ModelAndView("LeaveModify", model);
        } else {
            return new ModelAndView("LeaveUpdate", model);
        }

    }

    @RequestMapping("/LeaveModifySuccess.htm")
    public ModelAndView ModifySuccess(
            ModelMap model,
            @ModelAttribute("leaveApplication") LeaveApplication leaveApplication,
            HttpServletRequest request,
            @RequestParam("selection") int selection) {

        if (selection != 0) {

            leaveApplication.setId(selection);

            Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
            String username = userauth.getPrincipal().toString();

            List<Staff> staffDetails = staffService.findStaffByUserid(username);
            String staffEmailId = staffDetails.get(0).getEmailid();
            String ReportingAuthUsername = staffDetails.get(0).getReportingAuthority();

            List<Staff> RADetails = staffService.findStaffByUserid(ReportingAuthUsername);
            String RAEmailId = RADetails.get(0).getEmailid();

            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));

            leaveApplication.setDuration(request.getParameter("fromtime") + ";" + request.getParameter("fromday") + "/"
                    + request.getParameter("frommonth") + "/" + request.getParameter("fromyear") + "-" + request.getParameter("totime") + ";" + request.getParameter("today") + "/" + request.getParameter("tomonth") + "/" + request.getParameter("toyear"));


            Date currentDate = new Date();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

            leaveApplication.setId(selection);
            leaveApplication.setAppliedDate(dateFormat.format(currentDate).toString());
            leaveApplication.setStatusDate(dateFormat.format(currentDate).toString());
            leaveApplication.setStatusTime(currentTime.format(currentDate).toString());
            leaveApplication.setStatus("In Process");
            leaveApplication.setReportingAuthority(leaveAppDetailsList.get(0).getReportingAuthority());
            leaveApplication.setUsername(leaveAppDetailsList.get(0).getUsername());
            leaveApplication.setRemarks(" ");

            staffService.saveLeaveApplication(leaveApplication);
            Staff staff = new Staff();
            staff.setFirstname(staffDetails.get(0).getFirstname());
            staff.setLastname(staffDetails.get(0).getLastname());
            staff.setDesignation(staffDetails.get(0).getDesignation());

            Staff RA = new Staff();
            RA.setFirstname(RADetails.get(0).getFirstname());
            RA.setLastname(RADetails.get(0).getLastname());

            EmailDetails emailDetails = new EmailDetails();
            emailDetails.setTo(RAEmailId);
            //emailDetails.setFrom("bharathsuman.g5@gmail.com");
            emailDetails.setFrom("ramana.miryala@gmail.com");
            emailDetails.setSubject("Leave Modify Application details");
            emailDetails.setVMTemplate("LeaveEmailTempate.vm");

            String[] InlineFilenames = new String[1];
            InlineFilenames[0] = "F:/Haritha_Tech_Project/Java_systemwithsecurity/web/img/medicalcollegeLogo.jpg";

            emailDetails.setAddInline(InlineFilenames);

            String[] AttachmentFilenames = new String[1];
            AttachmentFilenames[0] = null;

            emailDetails.setAttachment(AttachmentFilenames);
            model.addAttribute("RA", RA);
            model.addAttribute("staff", staff);
            model.addAttribute("leaveApplication", leaveApplication);

            emailSender.sendEmail(model, emailDetails);

            // staffService.formAddOptionvalues(model);

            return new ModelAndView("LeaveModifySuccess", model);
        } else {
            return new ModelAndView("LeaveModify", model);
        }

    }

    @RequestMapping("/LeaveRemind.htm")
    public ModelAndView Remind(
            ModelMap model,
            HttpServletRequest request,
            @RequestParam("selection") int selection) {

        if (selection != 0) {

            Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
            String username = userauth.getPrincipal().toString();

            List<Staff> staffDetails = staffService.findStaffByUserid(username);
            String staffEmailId = staffDetails.get(0).getEmailid();
            String ReportingAuthUsername = staffDetails.get(0).getReportingAuthority();

            List<Staff> RADetails = staffService.findStaffByUserid(ReportingAuthUsername);
            String RAEmailId = RADetails.get(0).getEmailid();

            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));
            LeaveApplication leaveApplication = new LeaveApplication();
            leaveApplication = leaveAppDetailsList.get(0);

            Staff staff = new Staff();
            staff.setFirstname(staffDetails.get(0).getFirstname());
            staff.setLastname(staffDetails.get(0).getLastname());
            staff.setDesignation(staffDetails.get(0).getDesignation());

            Staff RA = new Staff();
            RA.setFirstname(RADetails.get(0).getFirstname());
            RA.setLastname(RADetails.get(0).getLastname());

            EmailDetails emailDetails = new EmailDetails();
            emailDetails.setTo(RAEmailId);

            //emailDetails.setFrom("bharathsuman.g5@gmail.com");
            emailDetails.setFrom("ramana.miryala@gmail.com");
            emailDetails.setSubject("LeaveRemind Application details");
            emailDetails.setVMTemplate("LeaveEmailTempate.vm");

            String[] InlineFilenames = new String[1];
            InlineFilenames[0] = "F:/Haritha_Tech_Project/Java_systemwithsecurity/web/img/medicalcollegeLogo.jpg";

            emailDetails.setAddInline(InlineFilenames);

            String[] AttachmentFilenames = new String[1];
            AttachmentFilenames[0] = null;

            emailDetails.setAttachment(AttachmentFilenames);

            model.addAttribute("RA", RA);
            model.addAttribute("staff", staff);
            model.addAttribute("leaveApplication", leaveApplication);

            emailSender.sendEmail(model, emailDetails);
            staffService.formAddOptionvalues(model);

            return new ModelAndView("LeaveRemind", model);
        } else {
            return new ModelAndView("LeaveModify", model);
        }

    }

    @RequestMapping("/LeaveCancel.htm")
    public ModelAndView Cancel(
            ModelMap model,
            @RequestParam("selection") int selection) {

        if (selection != 0) {

            Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
            String username = userauth.getPrincipal().toString();

            List<Staff> staffDetails = staffService.findStaffByUserid(username);
            String staffEmailId = staffDetails.get(0).getEmailid();
            String ReportingAuthUsername = staffDetails.get(0).getReportingAuthority();

            List<Staff> RADetails = staffService.findStaffByUserid(ReportingAuthUsername);
            String RAEmailId = RADetails.get(0).getEmailid();

            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));

            LeaveApplication leaveApplication = new LeaveApplication();

            leaveApplication = leaveAppDetailsList.get(0);

            Date currentDate = new Date();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

            leaveApplication.setStatus("Cancelled");
            leaveApplication.setStatusDate(dateFormat.format(currentDate).toString());
            leaveApplication.setStatusTime(currentTime.format(currentDate).toString());

            staffService.saveLeaveApplication(leaveApplication);


            Staff staff = new Staff();
            staff.setFirstname(staffDetails.get(0).getFirstname());
            staff.setLastname(staffDetails.get(0).getLastname());
            staff.setDesignation(staffDetails.get(0).getDesignation());

            Staff RA = new Staff();
            RA.setFirstname(RADetails.get(0).getFirstname());
            RA.setLastname(RADetails.get(0).getLastname());



            EmailDetails emailDetails = new EmailDetails();

            emailDetails.setTo(RAEmailId);

            //emailDetails.setFrom("bharathsuman.g5@gmail.com");
            emailDetails.setFrom("ramana.miryala@gmail.com");
            emailDetails.setSubject("LeaveCancel Application details");
            emailDetails.setVMTemplate("LeaveEmailTempate.vm");

            String[] InlineFilenames = new String[1];
            InlineFilenames[0] = "F:/Haritha_Tech_Project/Java_systemwithsecurity/web/img/medicalcollegeLogo.jpg";

            emailDetails.setAddInline(InlineFilenames);

            String[] AttachmentFilenames = new String[1];
            AttachmentFilenames[0] = null;

            emailDetails.setAttachment(AttachmentFilenames);

            model.addAttribute("RA", RA);
            model.addAttribute("staff", staff);
            model.addAttribute("leaveApplication", leaveApplication);

            emailSender.sendEmail(model, emailDetails);

            List<LeaveSummary> leavesummaryDetails = staffService.findleaveSummaryByUsername(username);
            LeaveSummary leaveSummary = new LeaveSummary();
            leaveSummary = leavesummaryDetails.get(0);


            if (leaveApplication.getTypeOfLeave().equals("CCL")) {
                int canceledleaves = leaveSummary.getCclcancel() + 1;
                leaveSummary.setCclcancel(canceledleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("SPCL")) {
                int canceledleaves = leaveSummary.getSpclcancel() + 1;
                leaveSummary.setSpclcancel(canceledleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("CL")) {
                int canceledleaves = leaveSummary.getClcancel() + 1;
                leaveSummary.setClcancel(canceledleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("SL")) {
                int canceledleaves = leaveSummary.getSlcancel() + 1;
                leaveSummary.setSlcancel(canceledleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("EL")) {
                int canceledleaves = leaveSummary.getElcancel() + 1;
                leaveSummary.setElcancel(canceledleaves);
            }

            staffService.saveLeaveSummary(leaveSummary);

            return new ModelAndView("LeaveCancel", model);
        } else {
            return new ModelAndView("LeaveModify", model);
        }

    }

    @RequestMapping(value = "/Approver.htm")
    public ModelAndView Approver(ModelMap modelMap) {

        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();

        List<LeaveApplication> leaveAppDetails = staffService.findLeaveApplicationByRAusername(username);

        modelMap.addAttribute("leaveAppDetails", leaveAppDetails);

        return new ModelAndView("Approver", modelMap);

    }

    @RequestMapping("/ApproverLeaveAccept.htm")
    public ModelAndView ApproverLeaveAccept(
            ModelMap model, HttpServletRequest request,
            @ModelAttribute("leaveApplication") LeaveApplication leaveApplication,
            @RequestParam("selection") int selection) {

        if (selection != 0) {
            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));
            LeaveApplication leaveAppDetails = new LeaveApplication();
            leaveAppDetails = leaveAppDetailsList.get(0);

            String duration = leaveAppDetails.getDuration();
            String[] splitedDur = duration.split("[\\;/\\-]");
            //"9:00 AM;1/1/1900-6:00 PM;2/3/1901";

            model.addAttribute("fromtime", splitedDur[0]);
            model.addAttribute("fromday", splitedDur[1]);
            model.addAttribute("frommonth", splitedDur[2]);
            model.addAttribute("fromyear", splitedDur[3]);

            model.addAttribute("totime", splitedDur[4]);
            model.addAttribute("today", splitedDur[5]);
            model.addAttribute("tomonth", splitedDur[6]);
            model.addAttribute("toyear", splitedDur[7]);
            model.addAttribute("selection", selection);
            model.addAttribute("leaveAppDetails", leaveAppDetails);

            staffService.formAddOptionvalues(model);


            return new ModelAndView("ApproverLeaveAccept", model);
        } else {
            return new ModelAndView("Approver", model);
        }

    }





    @RequestMapping("/ApproverAcceptLeaveConfirm.htm")
    public ModelAndView ApproverLeaveConfirm(
            ModelMap model,
            @ModelAttribute("leaveApplication") LeaveApplication leaveApplication,
            HttpServletRequest request,
            @RequestParam("selection") int selection) {

        if (selection != 0) {

            Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
            String username = userauth.getPrincipal().toString();



            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));
         
             Date currentDate = new Date();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

            leaveApplication.setId(selection);
            leaveApplication.setStatusDate(dateFormat.format(currentDate).toString());
            leaveApplication.setStatusTime(currentTime.format(currentDate).toString());
            leaveApplication.setAppliedDate(leaveAppDetailsList.get(0).getAppliedDate());
            leaveApplication.setReportingAuthority(leaveAppDetailsList.get(0).getReportingAuthority());
            leaveApplication.setUsername(leaveAppDetailsList.get(0).getUsername());
            leaveApplication.setStatus("Accepted");
            leaveApplication.setDuration(request.getParameter("fromtime") + ";" + request.getParameter("fromday") + "/"
                    + request.getParameter("frommonth") + "/" + request.getParameter("fromyear") + "-" + request.getParameter("totime") + ";" + request.getParameter("today") + "/" + request.getParameter("tomonth") + "/" + request.getParameter("toyear"));
          

            staffService.saveLeaveApplication(leaveApplication);
            List<Staff> staffDetails = staffService.findStaffByUserid(leaveApplication.getUsername());

            Staff staff = new Staff();
            //staff =staffDetails.get(0);
            staff.setFirstname(staffDetails.get(0).getFirstname());
            staff.setLastname(staffDetails.get(0).getLastname());
            staff.setDesignation(staffDetails.get(0).getDesignation());

            List<Staff> RADetails = staffService.findStaffByUserid(leaveApplication.getReportingAuthority());

            Staff RA = new Staff();
           // RA=RADetails.get(0);
            RA.setFirstname(RADetails.get(0).getFirstname());
            RA.setLastname(RADetails.get(0).getLastname());


            EmailDetails emailDetails = new EmailDetails();
            emailDetails.setTo(staffDetails.get(0).getEmailid());
            emailDetails.setFrom("ramana.miryala@gmail.com");
            emailDetails.setCC(RADetails.get(0).getEmailid());
            emailDetails.setSubject("Accepted Leave Application details");
            emailDetails.setVMTemplate("LeaveEmailTempate.vm");

            String[] InlineFilenames = new String[1];
            InlineFilenames[0] = "F:/Haritha_Tech_Project/Java_systemwithsecurity/web/img/medicalcollegeLogo.jpg";

            emailDetails.setAddInline(InlineFilenames);

            String[] AttachmentFilenames = new String[1];
            AttachmentFilenames[0] = null;

            emailDetails.setAttachment(AttachmentFilenames);
            model.addAttribute("RA", RA);
            model.addAttribute("staff", staff);
            model.addAttribute("leaveApplication", leaveApplication);

            emailSender.sendEmail(model, emailDetails);

            List<LeaveSummary> leavesummaryDetails = staffService.findleaveSummaryByUsername(leaveApplication.getUsername());
            LeaveSummary leaveSummary = new LeaveSummary();
            leaveSummary = leavesummaryDetails.get(0);


            if (leaveApplication.getTypeOfLeave().equals("CCL")) {
                int Acceptedleaves = leaveSummary.getCclAccepted() + 1;
                leaveSummary.setCclAccepted(Acceptedleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("SPCL")) {
                int Acceptedleaves = leaveSummary.getSpclAccepted() + 1;
                leaveSummary.setSpclAccepted(Acceptedleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("CL")) {
                int Acceptedleaves = leaveSummary.getClAccepted() + 1;
                leaveSummary.setClAccepted(Acceptedleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("SL")) {
                int Acceptedleaves = leaveSummary.getSlAccepted() + 1;
                leaveSummary.setSlAccepted(Acceptedleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("EL")) {
                int Acceptedleaves = leaveSummary.getElAccepted() + 1;
                leaveSummary.setElAccepted(Acceptedleaves);
            }


            staffService.saveLeaveSummary(leaveSummary);




            return new ModelAndView("ApproverAcceptLeaveConfirm", model);
        } else {
            return new ModelAndView("Approver", model);
        }

    }





    @RequestMapping("/ApproverLeaveReject.htm")
    public ModelAndView ApproverLeaveReject(
            ModelMap model, HttpServletRequest request,
            @ModelAttribute("leaveApplication") LeaveApplication leaveApplication,
            @RequestParam("selection") int selection) {

        if (selection != 0) {
            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));
            LeaveApplication leaveAppDetails = new LeaveApplication();
            leaveAppDetails = leaveAppDetailsList.get(0);

            String duration = leaveAppDetails.getDuration();
            String[] splitedDur = duration.split("[\\;/\\-]");
            //"9:00 AM;1/1/1900-6:00 PM;2/3/1901";

            model.addAttribute("fromtime", splitedDur[0]);
            model.addAttribute("fromday", splitedDur[1]);
            model.addAttribute("frommonth", splitedDur[2]);
            model.addAttribute("fromyear", splitedDur[3]);

            model.addAttribute("totime", splitedDur[4]);
            model.addAttribute("today", splitedDur[5]);
            model.addAttribute("tomonth", splitedDur[6]);
            model.addAttribute("toyear", splitedDur[7]);
            model.addAttribute("selection", selection);
            model.addAttribute("leaveAppDetails", leaveAppDetails);

            staffService.formAddOptionvalues(model);


            return new ModelAndView("ApproverLeaveReject", model);
        } else {
            return new ModelAndView("Approver", model);
        }

    }











    @RequestMapping("/ApproverLeaveRejectConfirm.htm")
    public ModelAndView ApproverLeaveReject(
            ModelMap model,
            @ModelAttribute("leaveApplication") LeaveApplication leaveApplication,
            HttpServletRequest request,
            @RequestParam("selection") int selection) {

        if (selection != 0) {

            Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
            String username = userauth.getPrincipal().toString();



            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));
            

            

            Date currentDate = new Date();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

            leaveApplication.setId(selection);
            leaveApplication.setStatusDate(dateFormat.format(currentDate).toString());
            leaveApplication.setStatusTime(currentTime.format(currentDate).toString());
            leaveApplication.setReportingAuthority(leaveAppDetailsList.get(0).getReportingAuthority());
            leaveApplication.setUsername(leaveAppDetailsList.get(0).getUsername());
            leaveApplication.setStatus("Rejected");
            leaveApplication.setAppliedDate(leaveAppDetailsList.get(0).getAppliedDate());

            leaveApplication.setDuration(request.getParameter("fromtime") + ";" + request.getParameter("fromday") + "/"
                    + request.getParameter("frommonth") + "/" + request.getParameter("fromyear") + "-" + request.getParameter("totime") + ";" + request.getParameter("today") + "/" + request.getParameter("tomonth") + "/" + request.getParameter("toyear"));


            staffService.saveLeaveApplication(leaveApplication);
            List<Staff> staffDetails = staffService.findStaffByUserid(leaveApplication.getUsername());


            Staff staff = new Staff();
            staff.setFirstname(staffDetails.get(0).getFirstname());
            staff.setLastname(staffDetails.get(0).getLastname());
            staff.setDesignation(staffDetails.get(0).getDesignation());

            List<Staff> RADetails = staffService.findStaffByUserid(leaveApplication.getReportingAuthority());

            Staff RA = new Staff();
            RA.setFirstname(RADetails.get(0).getFirstname());
            RA.setLastname(RADetails.get(0).getLastname());

            EmailDetails emailDetails = new EmailDetails();
            emailDetails.setTo(staffDetails.get(0).getEmailid());
            emailDetails.setFrom("ramana.miryala@gmail.com");
            emailDetails.setCC(RADetails.get(0).getEmailid());
            emailDetails.setSubject("Rejected Leave Application details");
            emailDetails.setVMTemplate("LeaveEmailTempate.vm");

            String[] InlineFilenames = new String[1];
            InlineFilenames[0] = "F:/Haritha_Tech_Project/Java_systemwithsecurity/web/img/medicalcollegeLogo.jpg";

            emailDetails.setAddInline(InlineFilenames);

            String[] AttachmentFilenames = new String[1];
            AttachmentFilenames[0] = null;

            emailDetails.setAttachment(AttachmentFilenames);
            model.addAttribute("RA", RA);
            model.addAttribute("staff", staff);
            model.addAttribute("leaveApplication", leaveApplication);

            emailSender.sendEmail(model, emailDetails);

            List<LeaveSummary> leavesummaryDetails = staffService.findleaveSummaryByUsername(leaveApplication.getUsername());
            LeaveSummary leaveSummary = new LeaveSummary();
            leaveSummary = leavesummaryDetails.get(0);


            if (leaveApplication.getTypeOfLeave().equals("CCL")) {
                int rejectleaves = leaveSummary.getCclRejectedNo() + 1;
                leaveSummary.setCclRejectedNo(rejectleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("SPCL")) {
                int rejectleaves = leaveSummary.getSpclRejectedNo() + 1;
                leaveSummary.setSpclRejectedNo(rejectleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("CL")) {
                int rejectleaves = leaveSummary.getClRejectedNo() + 1;
                leaveSummary.setClRejectedNo(rejectleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("SL")) {
                int rejectleaves = leaveSummary.getSlRejectedNo() + 1;
                leaveSummary.setSlRejectedNo(rejectleaves);
            } else if (leaveApplication.getTypeOfLeave().equals("EL")) {
                int rejectleaves = leaveSummary.getElRejectedNo() + 1;
                leaveSummary.setElRejectedNo(rejectleaves);
            }

            staffService.saveLeaveSummary(leaveSummary);




            return new ModelAndView("ApproverLeaveRejectConfirm", model);
        } else {
            return new ModelAndView("Approver", model);
        }

    }
}











