package com.suman.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.RequestParam;

import com.suman.domain.Users;
import com.suman.domain.Catalogue;
import com.suman.domain.Checkinandoutlog;
import com.suman.domain.Staff;
import com.suman.domain.Student;

import java.text.DateFormat;
import java.util.*;

import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.Authentication;


import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;

import org.apache.log4j.Logger;

import com.suman.service.LibraryService;
import com.suman.service.BorrowerLibraryService;
import com.suman.security.UsersService;
import com.suman.service.StaffService;
import com.suman.service.StudentService;
import com.suman.validator.CatalogueValidator;

import com.suman.email.EmailSender;
import java.text.SimpleDateFormat;

@Controller
public class BorrowerLibraryMgmtController {

    private UsersService usersService;
    private CatalogueValidator catalogueValidator;
    private LibraryService libraryService;
    private BorrowerLibraryService borrowerLibraryService;
    private StaffService staffService;
    private StudentService studentService;
    private GenericManageableCaptchaService captchaService;
    private Logger log = Logger.getLogger(LibraryMgmtController.class);
    private EmailSender emailSender;

    @Autowired
    public BorrowerLibraryMgmtController(GenericManageableCaptchaService captchaService, LibraryService libraryService,
            UsersService usersService, EmailSender emailSender, CatalogueValidator catalogueValidator,
            StaffService staffService, StudentService studentService,BorrowerLibraryService borrowerLibraryService) {
        this.libraryService = libraryService;
        this.captchaService = captchaService;
        this.usersService = usersService;
        this.emailSender = emailSender;
        this.catalogueValidator = catalogueValidator;
        this.staffService = staffService;
        this.studentService = studentService;
        this.borrowerLibraryService = borrowerLibraryService;
    }



     @RequestMapping("/StaffLibrarySearch.htm")
    public ModelAndView StaffLibrarySearch(ModelMap modelMap) {

        modelMap.addAttribute("catalogue1", new Catalogue());
        libraryService.formAddOptionvalues(modelMap);
        return new ModelAndView("StaffLibrarySearch", modelMap);

    }



     @RequestMapping(value = "/StaffLibrarySearchResults.htm")
    public ModelAndView StaffLibrarySearchResults(HttpServletRequest request, ModelMap modelMap,
            @ModelAttribute("catalogue1") Catalogue catalogue1) {

        request.getSession().setAttribute("catalogue1_session", catalogue1);
        modelMap.addAttribute("catalogue1", new Catalogue());
        catalogue1.setYearofPublication(request.getParameter("yearofPublication"));
        List<Catalogue> searchCatalogue = borrowerLibraryService.searchCatalogue(catalogue1);

        modelMap.addAttribute("searchCatalogue", searchCatalogue);
        borrowerLibraryService.formAddOptionvalues(modelMap);

        if (request.getParameter("typeofrecord").toString().equals("")
                && request.getParameter("title").toString().equals("")
                && request.getParameter("author").toString().equals("")
                && request.getParameter("yearofPublication").toString().equals("")
                && request.getParameter("subjectCategory").toString().equals("")
                && request.getParameter("keywords").toString().equals("")) {
            return new ModelAndView("StaffLibrarySearch", modelMap);
        } else {
            return new ModelAndView("StaffLibrarySearchResults", modelMap);
        }
    }



      @RequestMapping("/StudentLibrarySearch.htm")
    public ModelAndView StudentLibrarySearch(ModelMap modelMap) {

        modelMap.addAttribute("catalogue1", new Catalogue());
        libraryService.formAddOptionvalues(modelMap);
        return new ModelAndView("StudentLibrarySearch", modelMap);

    }



      @RequestMapping(value = "/StudentLibrarySearchResults.htm")
    public ModelAndView StudentLibrarySearchResults(HttpServletRequest request, ModelMap modelMap,
            @ModelAttribute("catalogue1") Catalogue catalogue1) {

        request.getSession().setAttribute("catalogue1_session", catalogue1);
        modelMap.addAttribute("catalogue1", new Catalogue());
        catalogue1.setYearofPublication(request.getParameter("yearofPublication"));
        List<Catalogue> searchCatalogue = borrowerLibraryService.searchCatalogue(catalogue1);
        modelMap.addAttribute("searchCatalogue", searchCatalogue);
        borrowerLibraryService.formAddOptionvalues(modelMap);

        if (request.getParameter("typeofrecord").toString().equals("")
                && request.getParameter("title").toString().equals("")
                && request.getParameter("author").toString().equals("")
                && request.getParameter("yearofPublication").toString().equals("")
                && request.getParameter("subjectCategory").toString().equals("")
                && request.getParameter("keywords").toString().equals("")) {
            return new ModelAndView("StudentLibrarySearch", modelMap);
        } else {
            return new ModelAndView("StudentLibrarySearchResults", modelMap);
        }
    }


    @RequestMapping(value = "/LibraryAccountDetails.htm")
    public ModelAndView LibrarianCheckInSearchResult(HttpServletRequest request, ModelMap model,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog) {


        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();


        //request.getSession().setAttribute("checkinandoutlog_session", checkinandoutlog);
        model.addAttribute("checkinandoutlog", new Checkinandoutlog());
        List<Checkinandoutlog> searchCheckinandoutlog = borrowerLibraryService.searchCheckinandoutlog(username);

        int sizeOfChekedOutItems = searchCheckinandoutlog.size();




        String bookdetails[] = new String[sizeOfChekedOutItems];
        String IssuedDate[] = new String[sizeOfChekedOutItems];
        String DueDate[] = new String[sizeOfChekedOutItems];
        String TotalFine[] = new String[sizeOfChekedOutItems];
        String issueddate[] = new String[sizeOfChekedOutItems];



        for (int j = 0; j < sizeOfChekedOutItems; j++) {

            //Checkinandoutlog checkinandoutlogDetails = searchCheckinandoutlog.get(0);

            List<Catalogue> catalogueDetailslist = borrowerLibraryService.findCatalogueByRecordIdentifier(searchCheckinandoutlog.get(j).getRecordIdentifier());

            Catalogue catalogueDetails = catalogueDetailslist.get(0);

            bookdetails[j] = catalogueDetails.getTitle() + "," + catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                    + "," + catalogueDetails.getPublishers();

             IssuedDate[j] = searchCheckinandoutlog.get(j).getIssuedDate();


            Calendar c1 = Calendar.getInstance();
            // roll down the month
            c1.set(Integer.parseInt(IssuedDate[j].split("/")[2]),
                    Integer.parseInt(IssuedDate[j].split("/")[1]) - 1,
                    Integer.parseInt(IssuedDate[j].split("/")[0])); // Setting Calendert to Issuded Date 1999 jan 20

            c1.add(Calendar.DAY_OF_MONTH, 15); // Advancing 15 Days from Issued Date for finding Due date

            DueDate[j] = Integer.toString(c1.get(Calendar.DAY_OF_MONTH)) + "/"
                    + Integer.toString(c1.get(Calendar.MONTH) + 1) + "/"
                    + Integer.toString(c1.get(Calendar.YEAR));


            Date duedate = c1.getTime();

            // Get msec from each, and subtract.
            long diff = (new Date()).getTime() - duedate.getTime();
            double lateness;
            if (diff > 0.0) {
                lateness = Math.rint((double) diff / (1000 * 60 * 60 * 24));
            } else {
                lateness = 0.0;
            }


            TotalFine[j] = Double.toString(lateness * 4.0);

            issueddate[j] = searchCheckinandoutlog.get(j).getIssuedDate() + ";" + searchCheckinandoutlog.get(j).getIssuedTime();
        }


        model.addAttribute("bookdetails", bookdetails);
        model.addAttribute("issueddate", issueddate);
        model.addAttribute("DueDate", DueDate);
        model.addAttribute("TotalFine", TotalFine);
        model.addAttribute("sizeOfChekedOutItems", sizeOfChekedOutItems);

        request.getSession().setAttribute("bookdetails",bookdetails);
        request.getSession().setAttribute("issueddate",issueddate);
        request.getSession().setAttribute("DueDate",DueDate);
        request.getSession().setAttribute("TotalFine",TotalFine);
        request.getSession().setAttribute("sizeOfChekedOutItems",sizeOfChekedOutItems);




        return new ModelAndView("LibraryAccountDetails", model);

    }

}
