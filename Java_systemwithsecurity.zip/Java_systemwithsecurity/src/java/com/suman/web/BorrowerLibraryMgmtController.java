package com.suman.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.RequestParam;

import com.suman.domain.Users;
import com.suman.domain.Catalogue;
import com.suman.domain.Checkinandoutlog;
import com.suman.domain.Staff;
import com.suman.domain.Student;
import com.suman.domain.LibraryRuleSet;

import java.text.DateFormat;
import java.util.*;

import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.Authentication;


import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;

import org.apache.log4j.Logger;

import com.suman.service.LibraryService;
import com.suman.service.BorrowerLibraryService;
import com.suman.security.UsersService;
import com.suman.service.StaffService;
import com.suman.service.StudentService;
import com.suman.validator.CatalogueValidator;

import com.suman.email.EmailSender;
import java.text.SimpleDateFormat;

@Controller
public class BorrowerLibraryMgmtController {

    private UsersService usersService;
    private CatalogueValidator catalogueValidator;
    private BorrowerLibraryService borrowerLibraryService;
    private StaffService staffService;
    private StudentService studentService;
    private GenericManageableCaptchaService captchaService;
    private Logger log = Logger.getLogger(LibraryMgmtController.class);
    private EmailSender emailSender;

    @Autowired
    public BorrowerLibraryMgmtController(GenericManageableCaptchaService captchaService,
            UsersService usersService, EmailSender emailSender, CatalogueValidator catalogueValidator,
            StaffService staffService, StudentService studentService, BorrowerLibraryService borrowerLibraryService) {

        this.captchaService = captchaService;
        this.usersService = usersService;
        this.emailSender = emailSender;
        this.catalogueValidator = catalogueValidator;
        this.staffService = staffService;
        this.studentService = studentService;
        this.borrowerLibraryService = borrowerLibraryService;
    }

    @RequestMapping("/BorrowerSearch.htm")
    public ModelAndView BorrowerSearch(ModelMap modelMap) {

        modelMap.addAttribute("catalogue1", new Catalogue());
        borrowerLibraryService.formAddOptionvalues(modelMap);
        return new ModelAndView("Library/BorrowerSearch", modelMap);

    }

    @RequestMapping(value = "/BorrowerSearchResults.htm")
    public ModelAndView BorrowerSearchResults(HttpServletRequest request, ModelMap modelMap,
            @ModelAttribute("catalogue1") Catalogue catalogue1) {

        request.getSession().setAttribute("catalogue1_session", catalogue1);
        modelMap.addAttribute("catalogue1", new Catalogue());
        catalogue1.setYearofPublication(request.getParameter("yearofPublication"));
        List<Catalogue> searchCatalogue = borrowerLibraryService.searchCatalogue(catalogue1);

        if (request.getParameter("typeofrecord").toString().equals("")
                && request.getParameter("title").toString().equals("")
                && request.getParameter("author").toString().equals("")
                && request.getParameter("yearofPublication").toString().equals("")
                && request.getParameter("subjectCategory").toString().equals("")
                && request.getParameter("keywords").toString().equals("")) {
            borrowerLibraryService.formAddOptionvalues(modelMap);
            modelMap.addAttribute("formerror", "You are not selected any Item");
            return new ModelAndView("Library/BorrowerSearch", modelMap);
        } else {

            int sizeOfCataloguetItems = searchCatalogue.size();

            //String searchCatalogue[] = new String[sizeOfCataloguetItems];
            String Availability[] = new String[sizeOfCataloguetItems];
            String IssuedDate[] = new String[sizeOfCataloguetItems];
            String DueDate[] = new String[sizeOfCataloguetItems];
            String borrowerdetails[] = new String[sizeOfCataloguetItems];

            for (int j = 0; j < sizeOfCataloguetItems; j++) {

                List<Checkinandoutlog> checkinandoutlogList = borrowerLibraryService.findCheckinandoutlogByRecordIdentifier(searchCatalogue.get(j).getRecordIdentifier());
                //tring Availability = null;
                if (checkinandoutlogList.size() > 0) {
                    IssuedDate[j] = checkinandoutlogList.get(0).getIssuedDate();
                    DueDate[j] =checkinandoutlogList.get(0).getDueDate();
                    Availability[j] = DueDate[j];
                    List<Users> usersDetailsList = usersService.findUsersById(checkinandoutlogList.get(0).getUserprimkey());
                    Users usersdetails = usersDetailsList.get(0);

                    if (usersdetails.getUsertype().equals("STAFF")) {

                        List<Staff> staffdetailsList = staffService.findStaffByUserprimkey(usersdetails.getId());
                        borrowerdetails[j] = staffdetailsList.get(0).getFirstname() + "," + staffdetailsList.get(0).getLastname() + ","
                                + staffdetailsList.get(0).getCurrentDesignation() + "," + staffdetailsList.get(0).getDepartment() + ","
                                + staffdetailsList.get(0).getEmailid();
                    } else if (usersdetails.getUsertype().equals("STUDENT")) {

                        List<Student> studentdetailsList = studentService.findStudentByUserprimkey(usersdetails.getId());
                        borrowerdetails[j] = studentdetailsList.get(0).getFirstName() + "." + studentdetailsList.get(0).getLastName() + "<br>"
                                + studentdetailsList.get(0).getCollegeRegistrationNumber() + "," + studentdetailsList.get(0).getCourseJoined() + "<br>"
                                + studentdetailsList.get(0).getEmailId();
                    }

                } else {
                    Availability[j] = "Available Now";
                    borrowerdetails[j] = "";
                }
            }
            modelMap.addAttribute("Availability", Availability);
            modelMap.addAttribute("borrowerdetails", borrowerdetails);
            modelMap.addAttribute("searchCatalogue", searchCatalogue);
            modelMap.addAttribute("sizeOfCataloguetItems", sizeOfCataloguetItems);
            borrowerLibraryService.formAddOptionvalues(modelMap);

            request.getSession().setAttribute("Availability", Availability);
            request.getSession().setAttribute("borrowerdetails", borrowerdetails);
            return new ModelAndView("Library/BorrowerSearchResults", modelMap);
        }
    }

    @RequestMapping(value = "/LibraryAccountDetails.htm")
    public ModelAndView LibraryAccountDetails(HttpServletRequest request, ModelMap model,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog) {

        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();


        List<Users> usersDetailsList = usersService.findUsersByUsername(username);

        List<LibraryRuleSet> libraryRuleSetDetailsList = borrowerLibraryService.LibraryRuleSetResults();
        LibraryRuleSet libraryRuleSet = new LibraryRuleSet();

        libraryRuleSet = libraryRuleSetDetailsList.get(0);
        long CurrentUserprimkey =0;
        int MaxBorrowDays = 0;
        double LatePayementRate = 0.0;

        Users usersdetails = usersDetailsList.get(0);
        if (usersdetails.getUsertype().equals("STAFF")) {

            List<Staff> staffdetailsList = staffService.findStaffByUserprimkey(usersdetails.getId());
            CurrentUserprimkey = staffdetailsList.get(0).getUserprimkey();
            MaxBorrowDays =Integer.parseInt(libraryRuleSet.getStaffMaxBorrowDays());
            LatePayementRate =Double.parseDouble(libraryRuleSet.getStaffLatePayementRate());

        } else if (usersdetails.getUsertype().equals("STUDENT")) {

            List<Student> studentdetailsList = studentService.findStudentByUserprimkey(usersdetails.getId());
            CurrentUserprimkey = studentdetailsList.get(0).getUserprimkey();
            MaxBorrowDays =Integer.parseInt(libraryRuleSet.getStdMaxBorrowDays());
            LatePayementRate =Double.parseDouble(libraryRuleSet.getStdLatePayementRate());
        }

        List<Checkinandoutlog> searchCheckinandoutlog = borrowerLibraryService.searchCheckinandoutlog(CurrentUserprimkey);

        int sizeOfChekedOutItems = searchCheckinandoutlog.size();

        String bookdetails[] = new String[sizeOfChekedOutItems];
        String IssuedDate[] = new String[sizeOfChekedOutItems];
        String DueDate[] = new String[sizeOfChekedOutItems];
        String TotalFine[] = new String[sizeOfChekedOutItems];
        String issueddate[] = new String[sizeOfChekedOutItems];

        for (int j = 0; j < sizeOfChekedOutItems; j++) {

            List<Catalogue> catalogueDetailslist = borrowerLibraryService.findCatalogueByRecordIdentifier(searchCheckinandoutlog.get(j).getRecordIdentifier());
            Catalogue catalogueDetails = catalogueDetailslist.get(0);

            bookdetails[j] = catalogueDetails.getTitle() + "," + catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                    + "," + catalogueDetails.getPublishers();
            IssuedDate[j] = searchCheckinandoutlog.get(j).getIssuedDate();
            DueDate[j] =searchCheckinandoutlog.get(j).getDueDate();

             Calendar c1 = Calendar.getInstance();
                    c1.set(Integer.parseInt(DueDate[j].split("/")[2]),
                            Integer.parseInt(DueDate[j].split("/")[1]) - 1,
                            Integer.parseInt(DueDate[j].split("/")[0])); // 1999 jan 20

            Date duedate = c1.getTime();
            // Get msec from each, and subtract.
            long diff = (new Date()).getTime() - duedate.getTime();
            double lateness;
            if (diff > 0.0) {
                lateness = Math.rint((double) diff / (1000 * 60 * 60 * 24));
            } else {
                lateness = 0.0;
            }
            TotalFine[j] = Double.toString(lateness * LatePayementRate);
            issueddate[j] = searchCheckinandoutlog.get(j).getIssuedDate() + ";" + searchCheckinandoutlog.get(j).getIssuedTime();
        }

        model.addAttribute("bookdetails", bookdetails);
        model.addAttribute("issueddate", issueddate);
        model.addAttribute("DueDate", DueDate);
        model.addAttribute("TotalFine", TotalFine);
        model.addAttribute("sizeOfChekedOutItems", sizeOfChekedOutItems);
        model.addAttribute("searchCheckinandoutlog", searchCheckinandoutlog);
        return new ModelAndView("Library/LibraryAccountDetails", model);
    }

    @RequestMapping(value = "/BorrowersRenewal.htm")
    public ModelAndView BorrowersRenewal(HttpServletRequest request, ModelMap model,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog) {

        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();

        List<Users> usersDetailsList = usersService.findUsersByUsername(username);

        List<LibraryRuleSet> libraryRuleSetDetailsList = borrowerLibraryService.LibraryRuleSetResults();

        LibraryRuleSet libraryRuleSet = new LibraryRuleSet();

        libraryRuleSet = libraryRuleSetDetailsList.get(0);
        long CurrentUserprimkey =0;
       // int MaxBorrowDays = 0;
        int MaxRenewals = 0;
        double LatePayementRate = 0.0;
        int MaxDaysRenewAppl = 0;

        Users usersdetails = usersDetailsList.get(0);
        if (usersdetails.getUsertype().equals("STAFF")) {

            List<Staff> staffdetailsList = staffService.findStaffByUserprimkey(usersdetails.getId());
            CurrentUserprimkey = staffdetailsList.get(0).getUserprimkey();
           // MaxBorrowDays = libraryRuleSet.getStaffMaxBorrowDays();
            MaxRenewals =Integer.parseInt(libraryRuleSet.getStaffMaxRenewals());
            LatePayementRate =Double.parseDouble(libraryRuleSet.getStaffLatePayementRate());
            MaxDaysRenewAppl =Integer.parseInt(libraryRuleSet.getStaffMaxDaysRenewAppl());

        } else if (usersdetails.getUsertype().equals("STUDENT")) {

            List<Student> studentdetailsList = studentService.findStudentByUsername(usersdetails.getUsername());
            CurrentUserprimkey = studentdetailsList.get(0).getUserprimkey();
           // MaxBorrowDays = libraryRuleSet.getStdMaxBorrowDays();
            MaxRenewals =Integer.parseInt(libraryRuleSet.getStdMaxRenewals());
            LatePayementRate =Double.parseDouble(libraryRuleSet.getStdLatePayementRate());
            MaxDaysRenewAppl =Integer.parseInt(libraryRuleSet.getStdMaxDaysRenewAppl());
        }

        List<Checkinandoutlog> searchCheckinandoutlog = borrowerLibraryService.searchCheckinandoutlog(CurrentUserprimkey);//Current user chekout details
        int sizeOfChekedOutItems = searchCheckinandoutlog.size();

        String bookdetails[] = new String[sizeOfChekedOutItems];
        String IssuedDate[] = new String[sizeOfChekedOutItems];
        String DueDate[] = new String[sizeOfChekedOutItems];
        String TotalFine[] = new String[sizeOfChekedOutItems];
        String issueddate[] = new String[sizeOfChekedOutItems];
        int IdsOfRenewalBooks[] = new int[sizeOfChekedOutItems];
        double DiffBwCurDateDueDate[] = new double[sizeOfChekedOutItems];
        boolean RenewalpossibulityList[] = new boolean[sizeOfChekedOutItems];
        int countRenewalBooks = 0;

        for (int j = 0; j < sizeOfChekedOutItems; j++) {

            List<Catalogue> catalogueDetailslist = borrowerLibraryService.findCatalogueByRecordIdentifier(searchCheckinandoutlog.get(j).getRecordIdentifier());
            Catalogue catalogueDetails = catalogueDetailslist.get(0);
            bookdetails[j] = catalogueDetails.getTitle() + "," + "<br>" + catalogueDetails.getAuthor() + "," + "<br>" + catalogueDetails.getYearofPublication()
                    + "," + "<br>" +  catalogueDetails.getPublishers();
            IssuedDate[j] = searchCheckinandoutlog.get(j).getIssuedDate();
            DueDate[j] = searchCheckinandoutlog.get(j).getDueDate();

            Calendar c1 = Calendar.getInstance();
            c1.set(Integer.parseInt(DueDate[j].split("/")[2]),
                    Integer.parseInt(DueDate[j].split("/")[1]) - 1,
                    Integer.parseInt(DueDate[j].split("/")[0])); // 1999 jan 20

            Date duedate = c1.getTime();
            // Get msec from each, and subtract.
            long diff = (new Date()).getTime() - duedate.getTime();
            double lateness;
            if (diff > 0.0) {
                lateness = Math.rint((double) diff / (1000 * 60 * 60 * 24));
            } else {
                lateness = 0.0;
            }
            // Means CUrrent Date < Due date
            DiffBwCurDateDueDate[j] = Math.rint((double) (-1 * diff) / (1000 * 60 * 60 * 24));
            TotalFine[j] = Double.toString(lateness * LatePayementRate);
            issueddate[j] = searchCheckinandoutlog.get(j).getIssuedDate() + ";" + searchCheckinandoutlog.get(j).getIssuedTime();
            IdsOfRenewalBooks[j] = searchCheckinandoutlog.get(j).getId();
            RenewalpossibulityList[j] = false;

            List<Checkinandoutlog> ReservedItems = borrowerLibraryService.findReservedItemsByRI(searchCheckinandoutlog.get(j).getRecordIdentifier());

            if (ReservedItems.size() <= 0) { // Reserved Items are not allowed to Renewal

                if (searchCheckinandoutlog.get(j).getRenewal() < MaxRenewals) { //Max no of successive renewals is allowed
                    if (DiffBwCurDateDueDate[j] >= 0.0 && DiffBwCurDateDueDate[j] + 1 <= MaxDaysRenewAppl) {
                        // Renewal is allowed
                        RenewalpossibulityList[j] = true;
                        countRenewalBooks++;
                    }
                }
            }
        }
        model.addAttribute("bookdetails", bookdetails);
        model.addAttribute("issueddate", issueddate);
        model.addAttribute("DueDate", DueDate);
        model.addAttribute("TotalFine", TotalFine);
        model.addAttribute("sizeOfChekedOutItems", sizeOfChekedOutItems);
        model.addAttribute("IdsOfRenewalBooks", IdsOfRenewalBooks);
        model.addAttribute("RenewalpossibulityList", RenewalpossibulityList);
        model.addAttribute("countRenewalBooks", countRenewalBooks);

        request.getSession().setAttribute("bookdetails", bookdetails);
        request.getSession().setAttribute("issueddate", issueddate);
        request.getSession().setAttribute("DueDate", DueDate);
        request.getSession().setAttribute("TotalFine", TotalFine);
        request.getSession().setAttribute("IdsOfRenewalBooks", IdsOfRenewalBooks);
        request.getSession().setAttribute("RenewalpossibulityList", RenewalpossibulityList);
        request.getSession().setAttribute("countRenewalBooks", countRenewalBooks);
        request.getSession().setAttribute("sizeOfChekedOutItems", sizeOfChekedOutItems);

        return new ModelAndView("Library/BorrowersRenewal", model);

    }

    @RequestMapping(value = "/BorrowersRenewalSuccess.htm")
    public ModelAndView BorrowersRenewalSuccess(HttpServletRequest request, ModelMap model) {



        String selectionStrings[] = request.getParameterValues("selection");


        if (selectionStrings == null) {
            Integer countRenewalBooks = (Integer) (request.getSession().getAttribute("countRenewalBooks"));
            Integer sizeOfChekedOutItems = (Integer) request.getSession().getAttribute("sizeOfChekedOutItems");
            String[] issueddate = (String[]) request.getSession().getAttribute("issueddate");
            String[] TotalFine = (String[]) request.getSession().getAttribute("TotalFine");
            String[] DueDate = (String[]) (request.getSession().getAttribute("DueDate"));
            String[] bookdetails = (String[]) (request.getSession().getAttribute("bookdetails"));
            int IdsOfRenewalBooks[] = (int[]) request.getSession().getAttribute("IdsOfRenewalBooks");

            model.addAttribute("countRenewalBooks", countRenewalBooks);
            model.addAttribute("sizeOfChekedOutItems", sizeOfChekedOutItems);
            model.addAttribute("bookdetails", bookdetails);
            model.addAttribute("issueddate", issueddate);
            model.addAttribute("IdsOfRenewalBooks", IdsOfRenewalBooks);
            model.addAttribute("DueDate", DueDate);
            model.addAttribute("TotalFine", TotalFine);



            model.addAttribute("EmptySelectionErroer", "You have not selected any book item");

            return new ModelAndView("Library/BorrowersRenewal", model);

        } else {

            int selection[] = new int[selectionStrings.length];

            for (int i = 0; i < selectionStrings.length; i++) // Converting String Array to Ineteger Array
            {
                selection[i] = Integer.parseInt(selectionStrings[i]);
            }


            List<LibraryRuleSet> libraryRuleSetDetailsList = borrowerLibraryService.LibraryRuleSetResults();
            LibraryRuleSet libraryRuleSet = new LibraryRuleSet();
            libraryRuleSet = libraryRuleSetDetailsList.get(0);
            //String CurrentUser = null;
            int MaxBorrowDays = 0;
            double LatePayementRate = 0.0;

            String DueDate[] = new String[selection.length];
            String IssuedDate[] = new String[selection.length];
            String TotalFine[] = new String[selection.length];
            String Bookdetails[] = new String[selection.length];

            boolean[] RenewalpossibulityList = (boolean[]) request.getSession().getAttribute("RenewalpossibulityList");

            int[] IdsOfRenewalBooks = (int[]) request.getSession().getAttribute("IdsOfRenewalBooks");

            String[] OldDueDates = (String[]) (request.getSession().getAttribute("DueDate"));
            String[] OldBookDetails = (String[]) (request.getSession().getAttribute("bookdetails"));
            for (int count = 0; count < selection.length; count++) {
                for (int k = 0; k < IdsOfRenewalBooks.length; k++) {
                    if (IdsOfRenewalBooks[k] == selection[count]) {
                        IssuedDate[count] = OldDueDates[k];
                        Bookdetails[count] = OldBookDetails[k];
                    }
                }
            }
            for (int j = 0; j < selection.length; j++) {
                if (selection[j] != 0) {
                    List<Checkinandoutlog> checkinandoutlogDetailsList =
                            borrowerLibraryService.findCheckinandoutlogById(selection[j]);
                    Checkinandoutlog checkinandoutlog = checkinandoutlogDetailsList.get(0);

                    List<Users> usersDetailsList = usersService.findUsersById(checkinandoutlog.getUserprimkey());

                    Users usersdetails = usersDetailsList.get(0);
                    if (usersdetails.getUsertype().equals("STAFF")) {

                        List<Staff> staffdetailsList = staffService.findStaffByUserprimkey(usersdetails.getId());
                        MaxBorrowDays =Integer.parseInt(libraryRuleSet.getStaffMaxBorrowDays());
                        LatePayementRate =Double.parseDouble(libraryRuleSet.getStaffLatePayementRate());

                    } else if (usersdetails.getUsertype().equals("STUDENT")) {

                        List<Student> studentdetailsList = studentService.findStudentByUserprimkey(usersdetails.getId());
                        MaxBorrowDays =Integer.parseInt(libraryRuleSet.getStdMaxBorrowDays());
                        LatePayementRate =Double.parseDouble(libraryRuleSet.getStdLatePayementRate());
                    }

                    Date currentDate = new Date();
                    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                    DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");
                    checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());

                    Calendar c1 = Calendar.getInstance();
                    // roll down the month
                    c1.set(Integer.parseInt(IssuedDate[j].split("/")[2]),
                            Integer.parseInt(IssuedDate[j].split("/")[1]) - 1,
                            Integer.parseInt(IssuedDate[j].split("/")[0])); // Setting Calendert to Issuded Date 1999 jan 20

                    c1.add(Calendar.DAY_OF_MONTH, MaxBorrowDays); // Advancing 15 Days from Issued Date for finding Due date

                    DueDate[j] = borrowerLibraryService.DateConversion(c1);

//                        Integer.toString(c1.get(Calendar.DAY_OF_MONTH)) + "/"
//                        + Integer.toString(c1.get(Calendar.MONTH) + 1) + "/"
//                        + Integer.toString(c1.get(Calendar.YEAR));
                    Date duedate = c1.getTime();
                    // Get msec from each, and subtract.
                    long diff = (new Date()).getTime() - duedate.getTime();

                    double lateness;
                    if (diff > 0.0) {
                        lateness = Math.rint((double) diff / (1000 * 60 * 60 * 24));
                    } else {
                        lateness = 0.0;
                    }

                    TotalFine[j] = Double.toString(lateness * LatePayementRate);

                    checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());
                    checkinandoutlog.setStatus("CheckOut");
                    checkinandoutlog.setIssuedDate(IssuedDate[j]);
                    checkinandoutlog.setDueDate(DueDate[j]);
                    checkinandoutlog.setIssuedTime(currentTime.format(currentDate).toString());
                    checkinandoutlog.setFinePaid(TotalFine[j]);
                    checkinandoutlog.setRemarks("Renewal");

                    if (checkinandoutlog.getRemarks().equals("Renewal")) {
                        int renewalscount = checkinandoutlog.getRenewal() + 1;
                        checkinandoutlog.setRenewal(renewalscount);
                    }

                    borrowerLibraryService.saveCheckinandoutlog(checkinandoutlog);
                }
            }

            model.addAttribute("bookdetails", Bookdetails);
            model.addAttribute("DueDate", DueDate);
            model.addAttribute("TotalFine", TotalFine);
            model.addAttribute("issueddate", IssuedDate);
            model.addAttribute("booksselected", selection.length);

            return new ModelAndView("Library/BorrowersRenewalSuccess", model);
        }

    }

    @RequestMapping("/OnlineReservationSearch.htm")
    public ModelAndView OnlineReservationSearch(ModelMap modelMap) {

        modelMap.addAttribute("catalogue1", new Catalogue());
        borrowerLibraryService.formAddOptionvalues(modelMap);
        return new ModelAndView("Library/OnlineReservationSearch", modelMap);

    }

    @RequestMapping(value = "/OnlineReservationSearchResults.htm")
    public ModelAndView OnlineReservationSearchResults(HttpServletRequest request, ModelMap modelMap,
            @ModelAttribute("catalogue1") Catalogue catalogue1) {

        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();

        if (request.getParameter("typeofrecord").toString().equals("")
                && request.getParameter("title").toString().equals("")
                && request.getParameter("author").toString().equals("")
                && request.getParameter("yearofPublication").toString().equals("")
                && request.getParameter("subjectCategory").toString().equals("")
                && request.getParameter("keywords").toString().equals("")) {

            borrowerLibraryService.formAddOptionvalues(modelMap);
            modelMap.addAttribute("ErrorMessage", "Your not selected any item for search");
            return new ModelAndView("Library/OnlineReservationSearch", modelMap);
        } else {

            request.getSession().setAttribute("catalogue1_session", catalogue1);
            modelMap.addAttribute("catalogue1", new Catalogue());
            //catalogue1.setYearofPublication(request.getParameter("yearofPublication"));
            List<Catalogue> searchCatalogue = borrowerLibraryService.searchCatalogue(catalogue1);

            int sizeOfCataloguetItems = searchCatalogue.size();

            //List<String> check = new ArrayList<String>();
            List<String> Availability = new ArrayList<String>();
          
            List<String> borrowerdetails = new ArrayList<String>();
            //int[] IdsOfReservationbooks= new int[sizeOfCataloguetItems];
            List<Integer> IdsOfReservationbooks = new ArrayList<Integer>();
            List<Catalogue> finalizedCatalogue = new ArrayList<Catalogue>();
            String IssuedDate=null;
            String DueDate=null;

            List<LibraryRuleSet> libraryRuleSetDetailsList = borrowerLibraryService.LibraryRuleSetResults();
            LibraryRuleSet libraryRuleSet = new LibraryRuleSet();
            libraryRuleSet = libraryRuleSetDetailsList.get(0);

            long CurrentUserprimkey =0;
            int MaxBorrowDays = 0;
            int ResrevationPeriod = 0;
            double DiffBwCurDateDueDate = 0.0;


            List<Users> usersDetailsList = usersService.findUsersByUsername(username);

            Users usersdetails = usersDetailsList.get(0);

            if (usersdetails.getUsertype().equals("STAFF")) {

                List<Staff> staffdetailsList = staffService.findStaffByUserprimkey(usersdetails.getId());

                CurrentUserprimkey = staffdetailsList.get(0).getUserprimkey();
                ResrevationPeriod =Integer.parseInt(libraryRuleSet.getStaffResrevationPeriod());
            } else if (usersdetails.getUsertype().equals("STUDENT")) {

                List<Student> studentdetailsList = studentService.findStudentByUserprimkey(usersdetails.getId());

                CurrentUserprimkey = studentdetailsList.get(0).getUserprimkey();
                ResrevationPeriod =Integer.parseInt(libraryRuleSet.getStdResrevationPeriod());
            }
            //int count = 0;
            for (int j = 0; j < sizeOfCataloguetItems; j++) {

                List<Checkinandoutlog> checkoutlogList = borrowerLibraryService.findCheckinandoutlogByRecordIdentifier(searchCatalogue.get(j).getRecordIdentifier()); //checkout details

                if (checkoutlogList.size() > 0) { // Chekcing Item is Checked-out

                    if (checkoutlogList.get(0).getUserprimkey()!=(CurrentUserprimkey)) { //Accept items not equel to current user
                        List<Checkinandoutlog> ReservedItems = borrowerLibraryService.findReservedItemsByRI(searchCatalogue.get(j).getRecordIdentifier());
                        if (ReservedItems.size() <= 0) { //Accepting Items which are Status is equal to "Reserved" is not allowed here

                            //check.add("YES");

                            IssuedDate=checkoutlogList.get(0).getIssuedDate();
                           
//                            if (BorrowerDetails.getUsertype().equals("STAFF")) {
//                                MaxBorrowDays = libraryRuleSet.getStaffMaxBorrowDays();
//
//                            } else if (BorrowerDetails.getUsertype().equals("STUDENT")) {
//                                MaxBorrowDays = libraryRuleSet.getStdMaxBorrowDays();
//                            }

                            DueDate=checkoutlogList.get(0).getDueDate();

                            Calendar c1 = Calendar.getInstance();
                            c1.set(Integer.parseInt(DueDate.split("/")[2]),
                                    Integer.parseInt(DueDate.split("/")[1]) - 1,
                                    Integer.parseInt(DueDate.split("/")[0])); // 1999 jan 20


                            Date duedate = c1.getTime();
                            long diff = (new Date()).getTime() - duedate.getTime();
                            DiffBwCurDateDueDate=(Math.rint((double) (-1 * diff) / (1000 * 60 * 60 * 24)));
                            if (DiffBwCurDateDueDate >= 0.0 && DiffBwCurDateDueDate+1 <= ResrevationPeriod) {

                                Users BorrowerDetails = usersService.findUsersById(checkoutlogList.get(0).getUserprimkey()).get(0);
                                if (BorrowerDetails.getUsertype().equals("STAFF")) {

                                    List<Staff> staffdetailsList = staffService.findStaffByUserprimkey(BorrowerDetails.getId());
                                    borrowerdetails.add(staffdetailsList.get(0).getFirstname() + "," + staffdetailsList.get(0).getLastname() + ","
                                            + staffdetailsList.get(0).getCurrentDesignation() + "," + staffdetailsList.get(0).getDepartment() + ","
                                            + staffdetailsList.get(0).getEmailid());

                                } else if (BorrowerDetails.getUsertype().equals("STUDENT")) {

                                    List<Student> studentdetailsList = studentService.findStudentByUserprimkey(BorrowerDetails.getId());
                                    borrowerdetails.add(studentdetailsList.get(0).getFirstName() + "," + studentdetailsList.get(0).getLastName() + ","
                                            + studentdetailsList.get(0).getCollegeRegistrationNumber() + "," + studentdetailsList.get(0).getCourseJoined() + ","
                                            + studentdetailsList.get(0).getEmailId());
                                }
                                IdsOfReservationbooks.add(searchCatalogue.get(j).getId());
                                finalizedCatalogue.add(searchCatalogue.get(j));
                                Availability.add(DueDate);
                                //count++;
                            }
                        }
                    }
                }
            }

            modelMap.addAttribute("Availability", Availability);
            modelMap.addAttribute("borrowerdetails", borrowerdetails);
            modelMap.addAttribute("searchCatalogue", finalizedCatalogue);
           // modelMap.addAttribute("sizeOfCataloguetItems", sizeOfCataloguetItems);
           // modelMap.addAttribute("check", check);
            modelMap.addAttribute("IdsOfReservationbooks", IdsOfReservationbooks);
            if(finalizedCatalogue.size()<=0){
                borrowerLibraryService.formAddOptionvalues(modelMap);
                modelMap.addAttribute("ErrorMessage", "Your account does not have eligible Reserved books from Your selected type");
                return new ModelAndView("Library/OnlineReservationSearch", modelMap);
            }
            else{
                borrowerLibraryService.formAddOptionvalues(modelMap);
            request.getSession().setAttribute("Availability", Availability);
            request.getSession().setAttribute("borrowerdetails", borrowerdetails);
            request.getSession().setAttribute("searchCatalogue", finalizedCatalogue);
           // request.getSession().setAttribute("sizeOfCataloguetItems", sizeOfCataloguetItems);
           // request.getSession().setAttribute("check", check);
            request.getSession().setAttribute("IdsOfReservationbooks", IdsOfReservationbooks);

            return new ModelAndView("Library/OnlineReservationSearchResults", modelMap);
            }            
        }
    }

    @RequestMapping(value = "/OnlineReservation.htm")
    public ModelAndView OnlineReservation(HttpServletRequest request, ModelMap modelMap
            ) {

        String selectionStrings[] = request.getParameterValues("selection");

        if (selectionStrings == null) { // When No items are selected
            List<String> Availability = (ArrayList<String>) request.getSession().getAttribute("Availability");
            List<String> borrowerdetails = (ArrayList<String>) request.getSession().getAttribute("borrowerdetails");
            List<Catalogue> finalizedCatalogue = (ArrayList<Catalogue>)request.getSession().getAttribute("finalizedCatalogue");
            modelMap.addAttribute("Availability", Availability);
            modelMap.addAttribute("borrowerdetails", borrowerdetails);
            modelMap.addAttribute("searchCatalogue", finalizedCatalogue);
            modelMap.addAttribute("EmptySelectionErroer", "You have not selected any Item");
            return new ModelAndView("Library/OnlineReservationSearchResults", modelMap);

        } else {
            int selection[] = new int[selectionStrings.length];
            for (int i = 0; i < selectionStrings.length; i++) // Converting String Array to Ineteger Array
            {
                selection[i] = Integer.parseInt(selectionStrings[i]);
            }
            List<Catalogue> ReservedCatalogue = new ArrayList<Catalogue>();
            List<Checkinandoutlog> checkinandoutlogList = new ArrayList<Checkinandoutlog>();
            List<String> Availability = new ArrayList<String>();
            
            List<String> OldAvailabilityDates = (ArrayList<String>) request.getSession().getAttribute("Availability");
            List<Integer> IdsOfReservationbooks = (ArrayList<Integer>) request.getSession().getAttribute("IdsOfReservationbooks");
            for (int count = 0; count < selection.length; count++) {
                for (int k = 0; k < IdsOfReservationbooks.size(); k++) {
                    if (IdsOfReservationbooks.get(k) == selection[count]) {
                        Availability.add(OldAvailabilityDates.get(k));
                    }
                }
            }
            Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
            String username = userauth.getPrincipal().toString();

            List<LibraryRuleSet> libraryRuleSetDetailsList = borrowerLibraryService.LibraryRuleSetResults();
            LibraryRuleSet libraryRuleSet = new LibraryRuleSet();
            libraryRuleSet = libraryRuleSetDetailsList.get(0);

            long CurrentUserprimkey = 0;
            int MaxReservedItems = 0;

            List<Users> usersDetailsList = usersService.findUsersByUsername(username);
            Users usersdetails = usersDetailsList.get(0);
            if (usersdetails.getUsertype().equals("STAFF")) {
                List<Staff> staffdetailsList = staffService.findStaffByUserprimkey(usersdetails.getId());
                CurrentUserprimkey = staffdetailsList.get(0).getUserprimkey();
                MaxReservedItems =Integer.parseInt(libraryRuleSet.getStaffMaxReservedItems());
            } else if (usersdetails.getUsertype().equals("STUDENT")) {
                List<Student> studentdetailsList = studentService.findStudentByUserprimkey(usersdetails.getId());
                CurrentUserprimkey = studentdetailsList.get(0).getUserprimkey();
                MaxReservedItems =Integer.parseInt(libraryRuleSet.getStdMaxReservedItems());
            }

            List<Checkinandoutlog> ReservedItemsOfCurrentUser = borrowerLibraryService.NoOfReservedItemsOfCurrentUser(CurrentUserprimkey);
            if ((selection.length) + (ReservedItemsOfCurrentUser.size()) <= MaxReservedItems) {

                for (int j = 0; j < selection.length; j++) {
                    List<Catalogue> searchCatalogue = borrowerLibraryService.findCatalogueByID(selection[j]);
                    Checkinandoutlog checkinandoutlog = new Checkinandoutlog();

                    Date currentDate = new Date();
                    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                    DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

                    checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());
                    checkinandoutlog.setUserprimkey(CurrentUserprimkey);
                    checkinandoutlog.setFinePaid("0.0");
                    checkinandoutlog.setIssuedTime(currentTime.format(currentDate).toString());
                    checkinandoutlog.setIssuedDate("");
                    checkinandoutlog.setRecordIdentifier(searchCatalogue.get(0).getRecordIdentifier());
                    checkinandoutlog.setRemarks("");
                    checkinandoutlog.setStatus("Reserved");
                    checkinandoutlog.setRenewal(0);
                    checkinandoutlog.setDueDate("");


                    ReservedCatalogue.add(searchCatalogue.get(0));
                    checkinandoutlogList.add(checkinandoutlog);
                }

                 modelMap.addAttribute("ReservedCatalogue", ReservedCatalogue);
            modelMap.addAttribute("Availability", Availability);
            request.getSession().setAttribute("checkinandoutlogList", checkinandoutlogList);
            return new ModelAndView("Library/OnlineReservation", modelMap);
            
            } else {
                modelMap.addAttribute("SelectionCountError", " Borrower exceeded maximum reserved books");
                return new ModelAndView("Library/OnlineReservationSearchResults", modelMap);
            }
           
        }
    }

    @RequestMapping(value = "/OnlineReservationConfirm.htm")
    public ModelAndView OnlineReservationConfirm(HttpServletRequest request, ModelMap modelMap) {
        List<Checkinandoutlog> checkinandoutlogList = (ArrayList<Checkinandoutlog>) request.getSession().getAttribute("checkinandoutlogList");
        for (int j = 0; j < checkinandoutlogList.size(); j++) {
            borrowerLibraryService.saveCheckinandoutlog((checkinandoutlogList.get(j)));
        }
        return new ModelAndView("Library/OnlineReservationConfirm", modelMap);
    }

    @RequestMapping(value = "/OnlineReservationBack.htm")
    public ModelAndView OnlineReservationBack(HttpServletRequest request, ModelMap modelMap) {
        List<String> Availability = (ArrayList<String>) request.getSession().getAttribute("Availability");
        List<String> borrowerdetails = (ArrayList<String>) request.getSession().getAttribute("borrowerdetails");
        List<Catalogue> finalizedCatalogue = (ArrayList<Catalogue>) request.getSession().getAttribute("searchCatalogue");
        return new ModelAndView("Library/OnlineReservationSearchResults", modelMap);
    }
}
