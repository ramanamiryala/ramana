package com.suman.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.RequestParam;

import com.suman.domain.Users;
import com.suman.domain.Catalogue;
import com.suman.domain.Checkinandoutlog;
import com.suman.domain.Staff;
import com.suman.domain.Student;
import com.suman.domain.LibraryRuleSet;

import java.text.DateFormat;
import java.util.*;


import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;

import org.apache.log4j.Logger;

import com.suman.service.LibraryService;
import com.suman.security.UsersService;
import com.suman.service.StaffService;
import com.suman.service.StudentService;
import com.suman.validator.CatalogueValidator;
import com.suman.validator.LibraryRuleSetValidator;

import com.suman.email.EmailSender;
import java.text.SimpleDateFormat;

@Controller
public class LibraryMgmtController {

    private UsersService usersService;
    private CatalogueValidator catalogueValidator;
    private LibraryService libraryService;
    private StaffService staffService;
    private StudentService studentService;
    private GenericManageableCaptchaService captchaService;
    private Logger log = Logger.getLogger(LibraryMgmtController.class);
    private EmailSender emailSender;
    private LibraryRuleSetValidator libraryRuleSetValidator;

    @Autowired
    public LibraryMgmtController(GenericManageableCaptchaService captchaService, LibraryService libraryService,
            UsersService usersService, EmailSender emailSender, CatalogueValidator catalogueValidator,
            StaffService staffService, StudentService studentService, LibraryRuleSetValidator libraryRuleSetValidator) {
        this.libraryService = libraryService;
        this.captchaService = captchaService;
        this.usersService = usersService;
        this.emailSender = emailSender;
        this.catalogueValidator = catalogueValidator;
        this.staffService = staffService;
        this.studentService = studentService;
        this.libraryRuleSetValidator = libraryRuleSetValidator;
    }

    @RequestMapping(value = "/CatalogueMgmtAddRecord.htm")
    public ModelAndView CatalogueMgmtAddRecord(ModelMap modelMap) {
        Catalogue catalogue = new Catalogue();
        modelMap.addAttribute("catalogue", catalogue);
        libraryService.formAddOptionvalues(modelMap);
        String formerror = "";
        modelMap.addAttribute("formerror", formerror);
        return new ModelAndView("librarian/CatalogueMgmtAddRecord", modelMap);
    }

    @RequestMapping(value = "/CatalogueMgmtAddRecordSuccess.htm")
    public ModelAndView CatalogueMgmtAddRecordSuccess(
            @ModelAttribute("catalogue") Catalogue catalogue,
            BindingResult result, ModelMap model,
            @RequestParam(value = "change", required = false) Object change,
            @RequestParam(value = "confirm", required = false) Object confirm,
            HttpServletRequest request) throws Exception {


        if (change != null || confirm != null) {
            libraryService.formAddOptionvalues(model);
            model.addAttribute("catalogue", catalogue);
        }

        if (change != null) {
            return new ModelAndView("librarian/CatalogueMgmtAddRecord", model);
        }

        else //if (confirm != null)
        {
            catalogue.setYearofPublication(request.getParameter("yearofPublication"));

            // Checking Capatch Response
            boolean isResponseCorrect = false;
            String captchaId = request.getSession().getId();
            String response = request.getParameter("j_captcha_response");

            try {
                if (response != null) {
                    isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                }
            } catch (CaptchaServiceException e) {
                log.error("Problem Jcaptcha settings ", e);
            }

            catalogueValidator.validate(catalogue, result);

            if (result.hasErrors()) {
                libraryService.formAddOptionvalues(model);
                return new ModelAndView("librarian/CatalogueMgmtAddRecord", model);
            } else {
                if (!isResponseCorrect) { //Capatcha is not correct
                    libraryService.formAddOptionvalues(model);
                    model.addAttribute("formerror", "Capacth is Invalid");
                    return new ModelAndView("librarian/CatalogueMgmtAddRecord", model);
                }  
                
                else {

                    List<Catalogue> CataloguedetailsList = libraryService.findCatalogueByRecordIdentifier(catalogue.getRecordIdentifier());

                    if (CataloguedetailsList.size() > 0) {

                        libraryService.formAddOptionvalues(model);
                        model.addAttribute("RecordIdentifierError", "Item with Record Identifier is already existed");
                        return new ModelAndView("librarian/CatalogueMgmtAddRecord", model);
                    }

                    libraryService.saveCatalogue(catalogue);
                    model.addAttribute("catalogue", catalogue);
                    return new ModelAndView("librarian/CatalogueMgmtAddRecordSuccess", model);
                }
            }
        }
    }

    @RequestMapping("/CatalogueMgmtSearch.htm")
    public ModelAndView CatalogueMgmtSearch(ModelMap modelMap) {

        modelMap.addAttribute("catalogue1", new Catalogue());
        libraryService.formAddOptionvalues(modelMap);
        return new ModelAndView("librarian/CatalogueMgmtSearch", modelMap);
    }

    @RequestMapping(value = "/CatalogueMgmtSearchResult.htm")
    public ModelAndView CatalogueMgmtSearchResult(HttpServletRequest request, ModelMap modelMap,
            @ModelAttribute("catalogue1") Catalogue catalogue1) {

        request.getSession().setAttribute("catalogue1_session", catalogue1);

        modelMap.addAttribute("catalogue1", new Catalogue());
        List<Catalogue> finalizedCatalogue = new ArrayList<Catalogue>();
        catalogue1.setYearofPublication(request.getParameter("yearofPublication"));

        if (request.getParameter("typeofrecord").toString().equals("")
                && request.getParameter("title").toString().equals("")
                && request.getParameter("author").toString().equals("")
                && request.getParameter("yearofPublication").toString().equals("")
                && request.getParameter("subjectCategory").toString().equals("")
                && request.getParameter("keywords").toString().equals("")) 
        {

            libraryService.formAddOptionvalues(modelMap);
            modelMap.addAttribute("formerror", "You are not selected any Item");
            return new ModelAndView("librarian/CatalogueMgmtSearch", modelMap);

        }
        
        else {

            List<Catalogue> searchCatalogue = libraryService.searchCatalogue(catalogue1);
            int Cataloguesize = searchCatalogue.size();

            for (int j = 0; j < Cataloguesize; j++) {
                //Check-Out Items not allowed
                List<Checkinandoutlog> checkOutList = libraryService.findCheckinandoutlogByRIwithCheckout(searchCatalogue.get(j).getRecordIdentifier());

                if (checkOutList.size() <= 0) {
                    //Reserved Items not allowed
                    List<Checkinandoutlog> ReservedItems = libraryService.findReservedItemsByRI(searchCatalogue.get(j).getRecordIdentifier());
                    
                    if (ReservedItems.size() <= 0) {
                        finalizedCatalogue.add(searchCatalogue.get(j));
                    }
                }
            }
            modelMap.addAttribute("searchCatalogue", finalizedCatalogue);
            return new ModelAndView("librarian/CatalogueMgmtSearchResult", modelMap);
        }
    }

    @RequestMapping("/CatalogueMgmtModify.htm")
    public ModelAndView CatalogueMgmtModify(
            ModelMap model,
            @RequestParam("selection") int selection, HttpServletRequest request) {
        if (selection != 0) {


            List<Catalogue> catalogueDetailsList = libraryService.findCatalogueById(selection);

            Catalogue catalogue = new Catalogue();
            catalogue = catalogueDetailsList.get(0);
//            String year = catalogue.getYearofPublication();
//            model.addAttribute("yearofPublication", year);
            model.addAttribute("selection", selection);
            model.addAttribute("catalogue", catalogue);

            libraryService.formAddOptionvalues(model);
            return new ModelAndView("librarian/CatalogueMgmtModify", model);
        } else {

            return new ModelAndView("librarian/CatalogueMgmtSearchResult", model);
        }
    }

    @RequestMapping(value = "/CatalogueMgmtModifySuccess.htm")
    public ModelAndView CatalogueMgmtModifySuccess(
            ModelMap model,
            @ModelAttribute("catalogue") Catalogue catalogue,
            BindingResult result,
            @RequestParam("selection") int selection,
            @RequestParam(value = "change", required = false) Object change,
            @RequestParam(value = "confirm", required = false) Object confirm,
            @RequestParam(value = "cancel", required = false) Object cancel,
            HttpServletRequest request) throws Exception {


        if (change != null || confirm != null) {
            // model.addAttribute("year", request.getParameter("year"));
            model.addAttribute("selection", selection);
            model.addAttribute("catalogue", catalogue);
            libraryService.formAddOptionvalues(model);

        }
        if (change != null) {

            return new ModelAndView("librarian/CatalogueMgmtModify", model);

        } else if (confirm != null) {


            if (selection != 0) {
                catalogue.setId(selection);
                model.addAttribute("selection", selection);

                
               
                // Checking Capatch Response
                boolean isResponseCorrect = false;
                String captchaId = request.getSession().getId();
                String response = request.getParameter("j_captcha_response");
                try {
                    if (response != null) {
                        isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                    }
                } catch (CaptchaServiceException e) {
                    log.error("Problem Jcaptcha settings ", e);
                }

                catalogue.setYearofPublication(request.getParameter("yearofPublication"));
                catalogueValidator.validate(catalogue, result);

                if (result.hasErrors()) {

                    libraryService.formAddOptionvalues(model);
                    model.addAttribute("catalogue", catalogue);
                    return new ModelAndView("librarian/CatalogueMgmtModify", model);

                }

                else {
                    if (!isResponseCorrect) { //Capatcha is not correct
                        libraryService.formAddOptionvalues(model);
                        model.addAttribute("formerror", "Capacth is Invalid");
                        return new ModelAndView("librarian/CatalogueMgmtModify", model);

                    }
                    else {
                        libraryService.saveCatalogue(catalogue);
                        model.addAttribute("catalogue", catalogue);
                    }
                }
            }
            return new ModelAndView("librarian/CatalogueMgmtModifySuccess", model);
        } else //cancel!=null
        {

            Catalogue catalogue1 = (Catalogue) request.getSession().getAttribute("catalogue1_session");

            model.addAttribute("catalogue1", new Catalogue());

            List<Catalogue> searchCatalogue = libraryService.searchCatalogue(catalogue1);

            model.addAttribute("searchCatalogue", searchCatalogue);
            libraryService.formAddOptionvalues(model);
            return new ModelAndView("librarian/CatalogueMgmtSearchResult", model);
        }


    }

//    @RequestMapping(value = "/CatalogueMgmtSearchResultback.htm")
//    public ModelAndView CatalogueMgmtSearchResultback(HttpServletRequest request, ModelMap modelMap) {
//
//        Catalogue catalogue1 = (Catalogue) request.getSession().getAttribute("catalogue1_session");
//        modelMap.addAttribute("catalogue1", new Catalogue());
//        List<Catalogue> searchCatalogue = libraryService.searchCatalogue(catalogue1);
//        modelMap.addAttribute("searchCatalogue", searchCatalogue);
//        libraryService.formAddOptionvalues(modelMap);
//        return new ModelAndView("librarian/CatalogueMgmtSearchResult", modelMap);
//    }
    @RequestMapping("/CatalogueMgmtDeleteCatalogue.htm")
    public ModelAndView CatalogueMgmtDeleteCatalogue(
            ModelMap model,
            @ModelAttribute("catalogue") Catalogue catalogue,
            @RequestParam("selection") int selection, HttpServletRequest request) {


        if (selection != 0) {

            List<Catalogue> catalogueDetailsList = libraryService.findCatalogueById(selection);

            Catalogue catalogueDetails = catalogueDetailsList.get(0);

            String year = catalogueDetails.getYearofPublication();

            model.addAttribute("yearofPublication", year);
            model.addAttribute("selection", selection);
            model.addAttribute("catalogueDetails", catalogueDetails);

            request.getSession().setAttribute("catalogueDetails", catalogueDetails);

            libraryService.formAddOptionvalues(model);
            return new ModelAndView("librarian/CatalogueMgmtDeleteCatalogue", model);
        } else {
            return new ModelAndView("librarian/CatalogueMgmtSearchResult", model);
        }
    }

    @RequestMapping("/CatalogueMgmtDeleteCatalogueSuccess.htm")
    public ModelAndView CatalogueMgmtDeleteCatalogueSuccess(
            ModelMap model,
            @ModelAttribute("catalogue") Catalogue catalogue, BindingResult result, HttpServletRequest request,
            @RequestParam("selection") int selection,
            @RequestParam(value = "change", required = false) Object change,
            @RequestParam(value = "confirm", required = false) Object confirm,
            @RequestParam(value = "cancel", required = false) Object cancel) {



        if (change != null || confirm != null) {

            model.addAttribute("selection", selection);

            Catalogue catalogueDetails = (Catalogue) request.getSession().getAttribute("catalogueDetails");

            String year = catalogueDetails.getYearofPublication();

            model.addAttribute("yearofPublication", year);

            model.addAttribute("catalogueDetails", catalogueDetails);

        }

        if (change != null) {

            return new ModelAndView("librarian/CatalogueMgmtDeleteCatalogue", model);

        } else if (confirm != null) {

            if (selection != 0) {

                Catalogue catalogueDetails = (Catalogue) request.getSession().getAttribute("catalogueDetails");
                
                String year = catalogueDetails.getYearofPublication();

                model.addAttribute("yearofPublication", year);
                model.addAttribute("catalogueDetails", catalogueDetails);
                model.addAttribute("selection", selection);

                // Checking Capatch Response
                boolean isResponseCorrect = false;
                String captchaId = request.getSession().getId();
                String response = request.getParameter("j_captcha_response");
                try {

                    if (response != null) {
                        isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                    }

                }
                
                catch (CaptchaServiceException e) {

                    log.error("Problem Jcaptcha settings ", e);
                }

                if (!isResponseCorrect) { //Capatcha is not correct

                    libraryService.formAddOptionvalues(model);
                    model.addAttribute("formerror", "Capacth is Invalid");

                    return new ModelAndView("librarian/CatalogueMgmtDeleteCatalogue", model);

                }
                
                else {

                    libraryService.deleteCatalogueRecord(catalogueDetails);
                    return new ModelAndView("librarian/CatalogueMgmtDeleteCatalogueSuccess", model);

                }
            }
            
            else {

                return new ModelAndView("librarian/CatalogueMgmtDeleteCatalogue", model);

            }
        } else //cancel!=null
        {
            Catalogue catalogue1 = (Catalogue) request.getSession().getAttribute("catalogue1_session");

            model.addAttribute("catalogue1", new Catalogue());

            List<Catalogue> searchCatalogue = libraryService.searchCatalogue(catalogue1);

            model.addAttribute("searchCatalogue", searchCatalogue);

            libraryService.formAddOptionvalues(model);
            return new ModelAndView("librarian/CatalogueMgmtSearchResult", model);

        }

    }

    @RequestMapping("/LibrarianCheckOut.htm")
    public ModelAndView LibrarianCheckOut(ModelMap model) {


        String recordIdentifier = null;
        String Username = null;
        //Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
        model.addAttribute("recordIdentifier", recordIdentifier);
        model.addAttribute("recordIdentifier", Username);

        return new ModelAndView("librarian/LibrarianCheckOut", model);

    }

    @RequestMapping("/LibrarianCheckOutConfirm.htm")
    public ModelAndView LibrarianCheckOutConfirm(ModelMap model,
            HttpServletRequest request) {


        List<LibraryRuleSet> libraryRuleSetDetailsList = libraryService.LibraryRuleSetResults();

        LibraryRuleSet libraryRuleSet = new LibraryRuleSet();

        libraryRuleSet = libraryRuleSetDetailsList.get(0);

        int MaxbookItems = 0;
        int MaxBorrowDays = 0;
        String borrowerdetails = null;
        String borrowerUsername = null;
        //String Username=null;

        List<Users> usersDetailsList = usersService.findUsersByUsername(request.getParameter("Username"));
        if (usersDetailsList.size() <= 0) {

            model.addAttribute("Username",request.getParameter("Username"));
            model.addAttribute("recordIdentifier",request.getParameter("recordIdentifier"));
            model.addAttribute("BorrowerUsernameError", "User does not exist");

            List<Catalogue> catalogueDetailsList = libraryService.findCatalogueByRecordIdentifier(request.getParameter("recordIdentifier"));

            if (catalogueDetailsList.size() <= 0) {

                model.addAttribute("RecordIdentifierError", "RecordIdentifier does not exist or empty");
                return new ModelAndView("librarian/LibrarianCheckOut", model);
            }
            else
            {
                return new ModelAndView("librarian/LibrarianCheckOut", model);
            }


            

        } else {

            List<Catalogue> catalogueDetailsList = libraryService.findCatalogueByRecordIdentifier(request.getParameter("recordIdentifier"));

            if (catalogueDetailsList.size() <= 0) {

                model.addAttribute("Username",request.getParameter("Username"));
                model.addAttribute("recordIdentifier",request.getParameter("recordIdentifier"));
                model.addAttribute("RecordIdentifierError", "RecordIdentifier does not existed or empty");
                return new ModelAndView("librarian/LibrarianCheckOut", model);

            } else {

                List<Checkinandoutlog> checkinandoutlogDetailslist = libraryService.findCheckinandoutlogByRIwithCheckout(request.getParameter("recordIdentifier"));

                if (checkinandoutlogDetailslist.size() <= 0) {

                    List<Checkinandoutlog> ReservedItems = libraryService.findReservedItemsByRI(request.getParameter("recordIdentifier"));

                    if (ReservedItems.size() <= 0 || (ReservedItems.size() > 0 && ReservedItems.get(0).getUserprimkey() == usersDetailsList.get(0).getId())) {

                        // ReservedItems.get(0).getUserprimkey(usersDetailsList.get(0).getId());


                        //List<Users> usersDetailsList = usersService.findUsersByUsername(checkinandoutlog.getBorrowerUsername());
                        Catalogue catalogueDetails = catalogueDetailsList.get(0);

                        String bookdetails = catalogueDetails.getTitle() + "," + catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                                + "," + catalogueDetails.getPublishers();


                     if (!usersDetailsList.get(0).isEnabled()) {

                        model.addAttribute("Username",request.getParameter("Username"));
                        model.addAttribute("recordIdentifier",request.getParameter("recordIdentifier"));
                        model.addAttribute("BorrowerUsernameError", "User is not enabled");
                        return new ModelAndView("librarian/LibrarianCheckOut", model);

                    } else {

                        Users usersdetails = usersDetailsList.get(0);

                        if (usersdetails.getUsertype().equals("STAFF")) {

                            List<Staff> staffdetailsList = staffService.findStaffByUserprimkey(usersdetails.getId());

                            borrowerdetails = staffdetailsList.get(0).getFirstname() + "." + staffdetailsList.get(0).getLastname() + ","
                                    + staffdetailsList.get(0).getCurrentDesignation() + "," + staffdetailsList.get(0).getDepartment();

                            MaxbookItems = Integer.parseInt(libraryRuleSet.getStaffMaxItems());

                            MaxBorrowDays = Integer.parseInt(libraryRuleSet.getStaffMaxBorrowDays());

                            borrowerUsername = staffdetailsList.get(0).getUsername();

                        } else if (usersdetails.getUsertype().equals("STUDENT")) {

                            List<Student> studentdetailsList = studentService.findStudentByUserprimkey(usersdetails.getId());

                            borrowerdetails = studentdetailsList.get(0).getFirstName() + "." + studentdetailsList.get(0).getLastName() + ","
                                    + studentdetailsList.get(0).getCollegeRegistrationNumber() + "," + studentdetailsList.get(0).getParentsName();

                            MaxbookItems = Integer.parseInt(libraryRuleSet.getStdMaxItems());

                            MaxBorrowDays = Integer.parseInt(libraryRuleSet.getStdMaxBorrowDays());

                            borrowerUsername = studentdetailsList.get(0).getUsername();
                        }
                        if (borrowerdetails == null) {

                            model.addAttribute("Username",request.getParameter("Username"));
                            model.addAttribute("recordIdentifier",request.getParameter("recordIdentifier"));
                            model.addAttribute("BorrowerUsernameError", "User is not authorized to access library");
                            return new ModelAndView("librarian/LibrarianCheckOut", model);

                        } else {

                            if (libraryService.findCheckOutsByUserprimkey(usersDetailsList.get(0).getId()) < MaxbookItems) {

                                Date currentDate = new Date();
                                DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                                DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

                                Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
                                checkinandoutlog.setRecordIdentifier(request.getParameter("recordIdentifier"));
                                checkinandoutlog.setIssuedDate(dateFormat.format(currentDate).toString());
                                checkinandoutlog.setIssuedTime(currentTime.format(currentDate).toString());
                                checkinandoutlog.setUserprimkey(usersdetails.getId());

                                String issuedDate = dateFormat.format(currentDate).toString();

                                Calendar c1 = Calendar.getInstance();
                                // roll down the month
                                c1.set(Integer.parseInt(issuedDate.split("/")[2]),
                                        Integer.parseInt(issuedDate.split("/")[1]) - 1,
                                        Integer.parseInt(issuedDate.split("/")[0])); // Setting Calendert to Issuded Date 1999 jan 20

                                c1.add(Calendar.DAY_OF_MONTH, MaxBorrowDays); // Advancing 15 Days from Issued Date for finding Due date

                                String duedate = libraryService.DateConversion(c1);

                                checkinandoutlog.setDueDate(duedate);
                                checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());
                                checkinandoutlog.setStatus("CheckOut");
                                checkinandoutlog.setFinePaid("0.0");
                                checkinandoutlog.setRemarks("");

                                if (ReservedItems.size() > 0) {

                                    checkinandoutlog.setId(ReservedItems.get(0).getId());
                                    checkinandoutlog.setRemarks("Reserved on" + ReservedItems.get(0).getStatusDate());

                                }

                                String recordIdentifier = checkinandoutlog.getRecordIdentifier();

                                model.addAttribute("checkinandoutlog", checkinandoutlog);
                                model.addAttribute("bookdetails", bookdetails);
                                model.addAttribute("borrowerdetails", borrowerdetails);
                                model.addAttribute("recordIdentifier", recordIdentifier);
                                model.addAttribute("borrowerUsername", borrowerUsername);
                                //model.addAttribute("ReservedItems", ReservedItems);
                                //request.getSession().setAttribute("ReservedItems", ReservedItems);
                                request.getSession().setAttribute("checkinandoutlog", checkinandoutlog);
                                return new ModelAndView("librarian/LibrarianCheckOutConfirm", model);

                            } else {

                                model.addAttribute("Username",request.getParameter("Username"));
                                model.addAttribute("recordIdentifier",request.getParameter("recordIdentifier"));
                                model.addAttribute("BorrowerUsernameError", " Borrower exceeded maximum Checkouts");
                                return new ModelAndView("librarian/LibrarianCheckOut", model);

                                }
                            }
                        }
                    } else {

                        model.addAttribute("Username",request.getParameter("Username"));
                        model.addAttribute("recordIdentifier",request.getParameter("recordIdentifier"));
                        model.addAttribute("RecordIdentifierError", "Item with Record Identifier is already Reserved");
                        return new ModelAndView("librarian/LibrarianCheckOut", model);

                    }
                } else {

                    model.addAttribute("Username",request.getParameter("Username"));
                    model.addAttribute("recordIdentifier",request.getParameter("recordIdentifier"));
                    model.addAttribute("RecordIdentifierError", "Item with Record Identifier is already Checked Out");
                    return new ModelAndView("librarian/LibrarianCheckOut", model);

                }
            }
        }
    }

    @RequestMapping("/LibrarianCheckOutConfirmSuccess.htm")
    public ModelAndView LibrarianCheckOutConfirmSuccess(ModelMap model,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog,
            HttpServletRequest request,
            @RequestParam(value = "change", required = false) Object change,
            @RequestParam(value = "confirm", required = false) Object confirm,
            @RequestParam(value = "cancel", required = false) Object cancel) {

        if (change != null || confirm != null) {
            checkinandoutlog = (Checkinandoutlog) request.getSession().getAttribute("checkinandoutlog");
            model.addAttribute("bookdetails", request.getParameter("bookdetails"));
            model.addAttribute("borrowerdetails", request.getParameter("borrowerdetails"));
            model.addAttribute("recordIdentifier", request.getParameter("recordIdentifier"));
            model.addAttribute("borrowerUsername", request.getParameter("borrowerUsername"));
        }
        if (change != null) {

            return new ModelAndView("librarian/LibrarianCheckOutConfirm", model);

        } else if (confirm != null) {


            // Checking Capatch Response
            boolean isResponseCorrect = false;
            String captchaId = request.getSession().getId();
            String response = request.getParameter("j_captcha_response");
            try {
                if (response != null) {

                    isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                }

            } catch (CaptchaServiceException e) {

                log.error("Problem Jcaptcha settings ", e);
            }

            if (!isResponseCorrect) { //Capatcha is not correct

                libraryService.formAddOptionvalues(model);
                model.addAttribute("formerror", "Capacth is Invalid");
                return new ModelAndView("librarian/LibrarianCheckOutConfirm", model);

            }
            
            else {

                model.addAttribute("checkinandoutlog", checkinandoutlog);
                libraryService.saveCheckinandoutlog(checkinandoutlog);
                return new ModelAndView("librarian/LibrarianCheckOutConfirmSuccess", model);
            }
        }

        else //cancel!=null
        {
            //Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
            model.addAttribute("borrowerUsername", request.getParameter("borrowerUsername"));
            model.addAttribute("checkinandoutlog", checkinandoutlog);
            return new ModelAndView("librarian/LibrarianCheckOut", model);

        }

    }

//    @RequestMapping(value = "/LibrarianCheckOutConfirmCancel.htm")
//    public ModelAndView LibrarianCheckOutConfirmCancel(ModelMap modelMap) {
//        Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
//        modelMap.addAttribute("checkinandoutlog", checkinandoutlog);
//        return new ModelAndView("librarian/LibrarianCheckOut", modelMap);
//    }
    @RequestMapping("/LibrarianCheckIn.htm")
    public ModelAndView LibrarianCheckIn(ModelMap model) {

        Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
        model.addAttribute("checkinandoutlog", checkinandoutlog);
        return new ModelAndView("librarian/LibrarianCheckIn", model);

    }

    @RequestMapping("/LibrarianCheckInConfirm.htm")
    public ModelAndView LibrarianCheckInConfirm(ModelMap model,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog,
            HttpServletRequest request) {


        List<Catalogue> catalogueDetailslist = libraryService.findCatalogueByRecordIdentifier(checkinandoutlog.getRecordIdentifier());
        
        if (catalogueDetailslist.size() <= 0) {

            model.addAttribute("RecordIdentifierError", "Item with this Record Identifier does not exist in Catalogue");
            return new ModelAndView("librarian/LibrarianCheckIn", model);

        } 
        else {

            List<LibraryRuleSet> libraryRuleSetDetailsList = libraryService.LibraryRuleSetResults();

            LibraryRuleSet libraryRuleSet = new LibraryRuleSet();

            libraryRuleSet = libraryRuleSetDetailsList.get(0);

            String borrowerUsername = null;
            double LatePayementRate = 0.0;

            //check-out details find by record identifier (or) RI
            List<Checkinandoutlog> checkoutlist = libraryService.findCheckinandoutlogByRIwithCheckout(catalogueDetailslist.get(0).getRecordIdentifier());

            if (checkoutlist.size() <= 0) {

                model.addAttribute("RecordIdentifierError", "Item with RecordIdentifier is not Ckecked Out!");
                return new ModelAndView("librarian/LibrarianCheckIn", model);

            } else {

                Catalogue catalogueDetails = catalogueDetailslist.get(0);

                String booktitle = catalogueDetails.getTitle();

                String bookdetails = catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                        + "," + catalogueDetails.getPublishers();

                Checkinandoutlog checkinandoutlogDetails = checkoutlist.get(0);

                String borrowerdetails = null;

                List<Users> BorrowerDetailsList = usersService.findUsersById(checkinandoutlogDetails.getUserprimkey());
                
                Users BorrowerDetails = BorrowerDetailsList.get(0);

                if (BorrowerDetails.getUsertype().equals("STAFF")) {

                    List<Staff> staffdetailsList = staffService.findStaffByUserprimkey(BorrowerDetails.getId());

                    borrowerdetails = staffdetailsList.get(0).getFirstname() + "," + staffdetailsList.get(0).getLastname() + ","
                            + staffdetailsList.get(0).getCurrentDesignation() + "," + staffdetailsList.get(0).getDepartment();

                    borrowerUsername = staffdetailsList.get(0).getUsername();

                    LatePayementRate = Double.parseDouble(libraryRuleSet.getStaffLatePayementRate());
                } else if (BorrowerDetails.getUsertype().equals("STUDENT")) {

                    List<Student> studentdetailsList = studentService.findStudentByUserprimkey(BorrowerDetails.getId());
                    borrowerdetails = studentdetailsList.get(0).getFirstName() + "," + studentdetailsList.get(0).getLastName() + ","
                            + studentdetailsList.get(0).getCollegeRegistrationNumber() + "," + studentdetailsList.get(0).getParentsName();
                    borrowerUsername = studentdetailsList.get(0).getUsername();
                    LatePayementRate = Double.parseDouble(libraryRuleSet.getStdLatePayementRate());
                }

                String IssuedDate = checkinandoutlogDetails.getIssuedDate();

                String DueDate = checkinandoutlogDetails.getDueDate();

                Calendar c1 = Calendar.getInstance();
                c1.set(Integer.parseInt(DueDate.split("/")[2]),
                        Integer.parseInt(DueDate.split("/")[1]) - 1,
                        Integer.parseInt(DueDate.split("/")[0])); // 1999 jan 20

                Date duedate = c1.getTime();
                Date today = new Date();
                // Get msec from each, and subtract.
                long diff = today.getTime() - duedate.getTime();
                double lateness;
                if (diff > 0.0) {
                    lateness = Math.rint((double) diff / (1000 * 60 * 60 * 24));
                } else {
                    lateness = 0.0;
                }

                String TotalFine = Double.toString(lateness * LatePayementRate);

                model.addAttribute("checkinandoutlog", checkinandoutlog);
                model.addAttribute("booktitle", booktitle);
                model.addAttribute("bookdetails", bookdetails);
                model.addAttribute("borrowerdetails", borrowerdetails);
                model.addAttribute("IssuedDate", IssuedDate);
                model.addAttribute("DueDate", DueDate);
                model.addAttribute("TotalFine", TotalFine);
                model.addAttribute("recordIdentifier", checkinandoutlog.getRecordIdentifier());
                model.addAttribute("borrowerUsername", borrowerUsername);

                return new ModelAndView("librarian/LibrarianCheckInConfirm", model);
            }
        }

    }

    @RequestMapping("/LibrariancheckInConfirmSuccess.htm")
    public ModelAndView LibrariancheckInConfirmSuccess(ModelMap model,
            HttpServletRequest request,
            @RequestParam(value = "change", required = false) Object change,
            @RequestParam(value = "confirm", required = false) Object confirm,
            @RequestParam(value = "cancel", required = false) Object cancel) {


        if (change != null || confirm != null) {


            model.addAttribute("checkinandoutlog", request.getParameter("checkinandoutlog"));
            model.addAttribute("booktitle", request.getParameter("booktitle"));
            model.addAttribute("bookdetails", request.getParameter("bookdetails"));
            model.addAttribute("borrowerdetails", request.getParameter("borrowerdetails"));
            model.addAttribute("IssuedDate", request.getParameter("IssuedDate"));
            model.addAttribute("DueDate", request.getParameter("DueDate"));
            model.addAttribute("TotalFine", request.getParameter("TotalFine"));
            model.addAttribute("recordIdentifier", request.getParameter("recordIdentifier"));
            model.addAttribute("borrowerUsername", request.getParameter("borrowerUsername"));

        }
        if (change != null) {

            return new ModelAndView("librarian/LibrarianCheckInConfirm", model);

        } else if (confirm != null) {

            // Checking Capatch Response
            boolean isResponseCorrect = false;
            String captchaId = request.getSession().getId();
            String response = request.getParameter("j_captcha_response");
            try {

                if (response != null) {
                    isResponseCorrect = captchaService.validateResponseForID(captchaId, response);

                }
            } catch (CaptchaServiceException e) {

                log.error("Problem Jcaptcha settings ", e);
            }

            if (!isResponseCorrect) { //Capatcha is not correct
                model.addAttribute("formerror", "Capacth is Invalid");
                return new ModelAndView("librarian/LibrarianCheckInConfirm", model);

            } else {

                List<Catalogue> catalogueDetailsList = libraryService.findCatalogueByRecordIdentifier(request.getParameter("recordIdentifier").toString());

                Catalogue catalogueDetails = catalogueDetailsList.get(0);

                List<Checkinandoutlog> checkinandoutlogDetailsList = libraryService.findCheckinandoutlogByRIwithCheckout(catalogueDetails.getRecordIdentifier());

                Checkinandoutlog checkinandoutlog = checkinandoutlogDetailsList.get(0);

                Date currentDate = new Date();
                DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                //Date OrigainalDate = new Date(2010,5,18);
                checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());
                checkinandoutlog.setStatus("CheckIn");
                checkinandoutlog.setFinePaid(request.getParameter("TotalFine"));

                libraryService.saveCheckinandoutlog(checkinandoutlog);
                return new ModelAndView("librarian/LibrariancheckInConfirmSuccess", model);

            }
        } else //cancel!=null
        {
            Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
            model.addAttribute("checkinandoutlog", checkinandoutlog);
            return new ModelAndView("librarian/LibrarianCheckIn", model);

        }
    }

    @RequestMapping("/LibrarianCheckInSearch.htm")
    public ModelAndView LibrarianCheckInSearch(HttpServletRequest request, ModelMap modelMap) {

        request.getSession().removeAttribute("selection");
        request.getSession().removeAttribute("booktitle");
        request.getSession().removeAttribute("recordIdentifier");
        request.getSession().removeAttribute("bookdetails");
        request.getSession().removeAttribute("borrowerdetails");
        request.getSession().removeAttribute("IssuedDate");
        request.getSession().removeAttribute("DueDate");
        request.getSession().removeAttribute("TotalFine");
        request.getSession().removeAttribute("borrowerUsername");
        request.getSession().removeAttribute("booksselected");
        request.getSession().removeAttribute("borrowerdetails");
        request.getSession().removeAttribute("searchCheckinandoutlog");

        return new ModelAndView("librarian/LibrarianCheckInSearch", modelMap);
    }

    @RequestMapping(value = "/LibrarianCheckInSearchResult.htm")
    public ModelAndView LibrarianCheckInSearchResult(HttpServletRequest request, ModelMap modelMap) {

        String borrowerUsername = (String) request.getParameter("borrowerUsername");

        List<Users> usersDetailsList = usersService.findUsersByUsername(borrowerUsername);

        String borrowerdetails=null;
        if (usersDetailsList.size()>0) {
        if (usersDetailsList.get(0).getUsertype().equals("STAFF")) {

                List<Staff> staffdetailsList = staffService.findStaffByUserprimkey(usersDetailsList.get(0).getId());

                borrowerdetails = staffdetailsList.get(0).getFirstname()+"."+staffdetailsList.get(0).getLastname()+"<br>"+staffdetailsList.get(0).getEmailid()+"<br>"+staffdetailsList.get(0).getDepartment();

            } else if (usersDetailsList.get(0).getUsertype().equals("STUDENT")) {

                List<Student> studentdetailsList = studentService.findStudentByUserprimkey(usersDetailsList.get(0).getId());

                borrowerdetails = studentdetailsList.get(0).getFirstName()+"."+studentdetailsList.get(0).getLastName()+"<br>"+studentdetailsList.get(0).getEmailId()+"<br>"+studentdetailsList.get(0).getAdmissionNo();

            }
         List<Checkinandoutlog> searchCheckinandoutlog = libraryService.findCheckoutListByUserprimkey(usersDetailsList.get(0).getId());

            modelMap.addAttribute("borrowerUsername", usersDetailsList.get(0).getUsername());
            modelMap.addAttribute("borrowerdetails",borrowerdetails);
            modelMap.addAttribute("searchCheckinandoutlog", searchCheckinandoutlog);

            request.getSession().setAttribute("borrowerUsername", borrowerUsername);
            request.getSession().setAttribute("borrowerdetails", borrowerdetails);
            request.getSession().setAttribute("searchCheckinandoutlog", searchCheckinandoutlog);

            return new ModelAndView("librarian/LibrarianCheckInSearchResult", modelMap);

           
        } else {
             modelMap.addAttribute("BorrowerUsernameErroer", "Borrower's Username is Empty or Does not exist");
            return new ModelAndView("librarian/LibrarianCheckInSearch", modelMap);
        
           
        }
    }

    @RequestMapping(value = "/LibrarianCheckInSearchResultCheckin.htm")
    public ModelAndView LibrarianCheckInSearchResultCheckin(
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog,
            BindingResult result, ModelMap model,
            HttpServletRequest request) throws Exception {

        String selectionStrings[] = request.getParameterValues("selection");

        if (selectionStrings == null) {

            List<Checkinandoutlog> searchCheckinandoutlog = (ArrayList<Checkinandoutlog>) request.getSession().getAttribute("searchCheckinandoutlog");

            model.addAttribute("borrowerUsername",request.getSession().getAttribute("borrowerUsername"));
            model.addAttribute("borrowerdetails",request.getSession().getAttribute("borrowerdetails"));
            model.addAttribute("searchCheckinandoutlog", searchCheckinandoutlog);
            model.addAttribute("EmptySelectionErroer", "You are not select any Item");

            return new ModelAndView("librarian/LibrarianCheckInSearchResult", model);

        } else {

            int selection[] = new int[selectionStrings.length];

            for (int i = 0; i < selectionStrings.length; i++) // Converting String Array to Ineteger Array
            {
                selection[i] = Integer.parseInt(selectionStrings[i]);
            }

            String booktitle[] = new String[selection.length];
            String recordIdentifier[] = new String[selection.length];
            String bookdetails[] = new String[selection.length];
            String borrowerdetails = null;
            String IssuedDate[] = new String[selection.length];
            String DueDate[] = new String[selection.length];
            String TotalFine[] = new String[selection.length];
            String borrowerUsername = null;

            List<LibraryRuleSet> libraryRuleSetDetailsList = libraryService.LibraryRuleSetResults();

            LibraryRuleSet libraryRuleSet = libraryRuleSetDetailsList.get(0);

            double LatePayementRate = 0.0;

            for (int j = 0; j < selection.length; j++) {

                if (selection[j] != 0) {

                    checkinandoutlog.setId(selection[j]);

                    List<Checkinandoutlog> checkinandoutlogDetailsList = libraryService.findCheckinandoutlogById(selection[j]);

                    Checkinandoutlog checkinandoutlogDetails = checkinandoutlogDetailsList.get(0);

                    List<Users> BorrowerDetailsList = usersService.findUsersById(checkinandoutlogDetails.getUserprimkey());

                    Users usersdetails = BorrowerDetailsList.get(0);

                    if (usersdetails.getUsertype().equals("STAFF")) {

                        List<Staff> staffdetailsList = staffService.findStaffByUserprimkey(usersdetails.getId());
                        
                        borrowerUsername = staffdetailsList.get(0).getUsername();

                        borrowerdetails = staffdetailsList.get(0).getFirstname() + "," + staffdetailsList.get(0).getLastname() + ","
                                + staffdetailsList.get(0).getCurrentDesignation() + "," + staffdetailsList.get(0).getDepartment();
                        
                        LatePayementRate = Double.parseDouble(libraryRuleSet.getStaffLatePayementRate());

                    } else if (usersdetails.getUsertype().equals("STUDENT")) {

                        List<Student> studentdetailsList = studentService.findStudentByUserprimkey(usersdetails.getId());
                        
                        borrowerUsername = studentdetailsList.get(0).getUsername();

                        borrowerdetails = studentdetailsList.get(0).getFirstName() + "," + studentdetailsList.get(0).getLastName() + ","
                                + studentdetailsList.get(0).getCollegeRegistrationNumber() + "," + studentdetailsList.get(0).getParentsName();

                        LatePayementRate = Double.parseDouble(libraryRuleSet.getStdLatePayementRate());
                    }

                    List<Catalogue> catalogueDetailsList = libraryService.findCatalogueByRecordIdentifier(checkinandoutlogDetails.getRecordIdentifier());

                    Catalogue catalogueDetails = catalogueDetailsList.get(0);

                    booktitle[j] = catalogueDetails.getTitle();

                    bookdetails[j] = catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                            + "," + catalogueDetails.getPublishers();

                    recordIdentifier[j] = checkinandoutlogDetails.getRecordIdentifier();

                    IssuedDate[j] = checkinandoutlogDetails.getIssuedDate();

                    DueDate[j] = checkinandoutlogDetails.getDueDate();

                    Calendar c1 = Calendar.getInstance();
                    c1.set(Integer.parseInt(DueDate[j].split("/")[2]),
                            Integer.parseInt(DueDate[j].split("/")[1]) - 1,
                            Integer.parseInt(DueDate[j].split("/")[0])); // 1999 jan 20

                    Date duedate = c1.getTime();
                    Date today = new Date();
                    // Get msec from each, and subtract.
                    long diff = today.getTime() - duedate.getTime();
                    double lateness;
                    if (diff > 0) {
                        lateness = Math.rint((double) diff / (1000 * 60 * 60 * 24));
                    } else {
                        lateness = 0;
                    }

                    TotalFine[j] = Double.toString(lateness * LatePayementRate);
                }
            }

            model.addAttribute("booksselected", selection.length);
            model.addAttribute("borrowerUsername", borrowerUsername);
            model.addAttribute("booktitle", booktitle);
            model.addAttribute("recordIdentifier", recordIdentifier);
            model.addAttribute("bookdetails", bookdetails);
            model.addAttribute("borrowerdetails", borrowerdetails);
            model.addAttribute("IssuedDate", IssuedDate);
            model.addAttribute("DueDate", DueDate);
            model.addAttribute("TotalFine", TotalFine);

            request.getSession().setAttribute("booksselected", selection.length);
            request.getSession().setAttribute("selection", selection);
            request.getSession().setAttribute("booktitle", booktitle);
            request.getSession().setAttribute("recordIdentifier", recordIdentifier);
            request.getSession().setAttribute("bookdetails", bookdetails);
            request.getSession().setAttribute("borrowerdetails", borrowerdetails);
            request.getSession().setAttribute("IssuedDate", IssuedDate);
            request.getSession().setAttribute("DueDate", DueDate);
            request.getSession().setAttribute("TotalFine", TotalFine);

            return new ModelAndView("librarian/LibrarianCheckInSearchResultCheckin", model);
        }
    }

    @RequestMapping(value = "/LibrarianCheckInSearchResultCancel.htm")
    public ModelAndView LibrarianCheckInSearchResultCancel(ModelMap modelMap) {

        Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
        modelMap.addAttribute("checkinandoutlog", checkinandoutlog);
        return new ModelAndView("librarian/LibrarianCheckInSearch", modelMap);

    }

    @RequestMapping(value = "/SearchResultCheckinConfirm.htm")
    public ModelAndView LibrarianCheckInSearchResultCheckinConfirm(ModelMap model,
            HttpServletRequest request,
            @RequestParam(value = "change", required = false) Object change,
            @RequestParam(value = "confirm", required = false) Object confirm,
            @RequestParam(value = "cancel", required = false) Object cancel) throws Exception {


        if (change != null || confirm != null) {

            model.addAttribute("booksselected", request.getSession().getAttribute("booksselected"));
            model.addAttribute("booktitle", request.getSession().getAttribute("booktitle"));
            model.addAttribute("recordIdentifier", request.getSession().getAttribute("recordIdentifier"));
            model.addAttribute("bookdetails", request.getSession().getAttribute("bookdetails"));
            model.addAttribute("borrowerdetails", request.getSession().getAttribute("borrowerdetails"));
            model.addAttribute("IssuedDate", request.getSession().getAttribute("IssuedDate"));
            model.addAttribute("DueDate", request.getSession().getAttribute("DueDate"));
            model.addAttribute("TotalFine", request.getSession().getAttribute("TotalFine"));
            model.addAttribute("borrowerUsername", request.getSession().getAttribute("borrowerUsername"));

        }

        if (change != null) {
            return new ModelAndView("librarian/LibrarianCheckInSearchResultCheckin", model);

        } else if (confirm != null) {

            int selection[] = (int[]) request.getSession().getAttribute("selection");

            String TotalFine[] = (String[]) request.getSession().getAttribute("TotalFine");

            model.addAttribute("booksselected", selection.length);
            model.addAttribute("selection", selection);

            //Capatcha
            boolean isResponseCorrect = false;
            String captchaId = request.getSession().getId();
            String response = request.getParameter("j_captcha_response");

            try {
                if (response != null) {
                    isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                }

            } catch (CaptchaServiceException e) {

                log.error("Problem Jcaptcha settings ", e);
            }

            if (!isResponseCorrect) { //Capatcha is not correct
                libraryService.formAddOptionvalues(model);
                model.addAttribute("formerror", "Capacth is Invalid");

                return new ModelAndView("librarian/LibrarianCheckInSearchResultCheckin", model);

            } else {

                for (int j = 0; j < selection.length; j++) {

                    if (selection[j] != 0) {

                        List<Checkinandoutlog> checkinandoutlogDetailsList =
                                libraryService.findCheckinandoutlogById(selection[j]);

                        Checkinandoutlog checkinandoutlog = checkinandoutlogDetailsList.get(0);

                        Date currentDate = new Date();
                        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

                        checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());
                        checkinandoutlog.setStatus("CheckIn");
                        checkinandoutlog.setFinePaid(TotalFine[j]);

                        libraryService.saveCheckinandoutlog(checkinandoutlog);
                    }
                }

                return new ModelAndView("librarian/SearchResultCheckinConfirm", model);
            }
        } else //cancel!=null
        {
            List<Checkinandoutlog> searchCheckinandoutlog = (ArrayList<Checkinandoutlog>) request.getSession().getAttribute("searchCheckinandoutlog");

            model.addAttribute("searchCheckinandoutlog", searchCheckinandoutlog);
            return new ModelAndView("librarian/LibrarianCheckInSearchResult", model);
        }
    }

//    @RequestMapping(value = "/SearchResultCheckinCancel.htm")
//    public ModelAndView SearchResultCheckinCancel(HttpServletRequest request, ModelMap modelMap) {
//
//        List<Checkinandoutlog> searchCheckinandoutlog = (ArrayList<Checkinandoutlog>) request.getSession().getAttribute("searchCheckinandoutlog");
//        modelMap.addAttribute("searchCheckinandoutlog", searchCheckinandoutlog);
//        return new ModelAndView("librarian/LibrarianCheckInSearchResult", modelMap);
//    }
    @RequestMapping(value = "/LibraryRuleSet.htm")
    public ModelAndView LibraryRuleSet(ModelMap modelMap) {

        //Student student = new Student();
        LibraryRuleSet libraryRuleSet = libraryService.LibraryRuleSetResults().get(0);

        modelMap.addAttribute("libraryRuleSet", libraryRuleSet);
        return new ModelAndView("librarian/LibraryRuleSet", modelMap);
    }

    @RequestMapping(value = "/LibraryRuleSetSubmit.htm")
    public ModelAndView LibraryRuleSetSubmit(ModelMap modelMap, HttpServletRequest request,
            @ModelAttribute("libraryRuleSet") LibraryRuleSet libraryRuleSet, BindingResult result) {

        //Capatcha
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");
        try {

            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        libraryRuleSetValidator.validate(libraryRuleSet, result);
        
        if (result.hasErrors()) {

            return new ModelAndView("librarian/LibraryRuleSet", modelMap);
        }

        if (!isResponseCorrect) { //Capatcha is not correct
            libraryService.formAddOptionvalues(modelMap);
            modelMap.addAttribute("formerror", "Capacth is Invalid");
            return new ModelAndView("librarian/LibraryRuleSet", modelMap);
        }
     
        modelMap.addAttribute("libraryRuleSet", libraryRuleSet);
        libraryService.saveLibraryRuleSet(libraryRuleSet);

        return new ModelAndView("librarian/LibraryRuleSetSubmit", modelMap);

    }

    @RequestMapping("/LibraryBooksSearch.htm")
    public ModelAndView LibraryBooksSearch(ModelMap modelMap) {

        modelMap.addAttribute("catalogue1", new Catalogue());
        libraryService.formAddOptionvalues(modelMap);
        return new ModelAndView("librarian/LibraryBooksSearch", modelMap);

    }

    @RequestMapping(value = "/LibraryBooksSearchResults.htm")
    public ModelAndView LibraryBooksSearchResults(HttpServletRequest request, ModelMap modelMap,
            @ModelAttribute("catalogue1") Catalogue catalogue1) {

        request.getSession().setAttribute("catalogue1_session", catalogue1);

        modelMap.addAttribute("catalogue1", new Catalogue());

        catalogue1.setYearofPublication(request.getParameter("yearofPublication"));

        List<Catalogue> searchCatalogue = libraryService.searchCatalogue(catalogue1);

        if (request.getParameter("typeofrecord").toString().equals("")
                && request.getParameter("title").toString().equals("")
                && request.getParameter("author").toString().equals("")
                && request.getParameter("yearofPublication").toString().equals("")
                && request.getParameter("subjectCategory").toString().equals("")
                && request.getParameter("keywords").toString().equals("")) 
        {

            libraryService.formAddOptionvalues(modelMap);
            return new ModelAndView("librarian/LibraryBooksSearch", modelMap);

        } else {

            int sizeOfCataloguetItems = searchCatalogue.size();

            //String searchCatalogue[] = new String[sizeOfCataloguetItems];
            String Availability[] = new String[sizeOfCataloguetItems];
            String IssuedDate[] = new String[sizeOfCataloguetItems];
            String DueDate[] = new String[sizeOfCataloguetItems];
            String borrowerdetails[] = new String[sizeOfCataloguetItems];

            for (int j = 0; j < sizeOfCataloguetItems; j++) {

                List<Checkinandoutlog> checkinandoutlogList = libraryService.findCheckinandoutlogByRIwithCheckout(searchCatalogue.get(j).getRecordIdentifier());
               
                 if (checkinandoutlogList.size() > 0) {

                    IssuedDate[j] = checkinandoutlogList.get(0).getIssuedDate();

                    DueDate[j] = checkinandoutlogList.get(0).getDueDate();

                    Availability[j] = DueDate[j];

                    List<Users> usersDetailsList = usersService.findUsersById(checkinandoutlogList.get(0).getUserprimkey());

                    Users usersdetails = usersDetailsList.get(0);

                    if (usersdetails.getUsertype().equals("STAFF")) {

                        List<Staff> staffdetailsList = staffService.findStaffByUserprimkey(usersdetails.getId());

                        borrowerdetails[j] = staffdetailsList.get(0).getFirstname() + "," + staffdetailsList.get(0).getLastname() + ","
                                + staffdetailsList.get(0).getCurrentDesignation() + "," + staffdetailsList.get(0).getDepartment() + ","
                                + staffdetailsList.get(0).getEmailid();

                    } else if (usersdetails.getUsertype().equals("STUDENT")) {

                        List<Student> studentdetailsList = studentService.findStudentByUserprimkey(usersdetails.getId());

                        borrowerdetails[j] = studentdetailsList.get(0).getFirstName() + "." + studentdetailsList.get(0).getLastName() + "<br>"
                                + studentdetailsList.get(0).getCollegeRegistrationNumber() + "," + studentdetailsList.get(0).getCourseJoined() + "<br>"
                                + studentdetailsList.get(0).getEmailId();
                    }

                } else {
                    Availability[j] = "Available Now";

                    borrowerdetails[j] = "";
                }
            }

            modelMap.addAttribute("Availability", Availability);
            modelMap.addAttribute("borrowerdetails", borrowerdetails);
            modelMap.addAttribute("searchCatalogue", searchCatalogue);
            modelMap.addAttribute("sizeOfCataloguetItems", sizeOfCataloguetItems);

            libraryService.formAddOptionvalues(modelMap);

            request.getSession().setAttribute("Availability", Availability);
            request.getSession().setAttribute("borrowerdetails", borrowerdetails);
            
            return new ModelAndView("librarian/LibraryBooksSearchResults", modelMap);
        }
    }
}






