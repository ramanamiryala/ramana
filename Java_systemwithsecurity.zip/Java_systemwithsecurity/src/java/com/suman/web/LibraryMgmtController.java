package com.suman.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.annotation.RequestParam;

import com.suman.domain.Users;
import com.suman.domain.Catalogue;
import com.suman.domain.Checkinandoutlog;
import com.suman.domain.Staff;

import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.util.List;
import java.util.Date;
import java.text.DateFormat;
import java.util.*;

import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;



import org.apache.log4j.Logger;
import org.apache.commons.lang.RandomStringUtils;

import com.suman.service.LibraryService;
import com.suman.security.UsersService;
import com.suman.service.StaffService;
import com.suman.validator.CatalogueValidator;

import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.Authentication;

import com.suman.email.EmailSender;
import com.suman.email.EmailDetails;
import java.text.SimpleDateFormat;

@Controller
public class LibraryMgmtController {

    private UsersService usersService;
    private CatalogueValidator catalogueValidator;
    private LibraryService libraryService;
    private StaffService staffService;
    private GenericManageableCaptchaService captchaService;
    private Logger log = Logger.getLogger(LibraryMgmtController.class);
    private EmailSender emailSender;

    @Autowired
    public LibraryMgmtController(GenericManageableCaptchaService captchaService, LibraryService libraryService,
            UsersService usersService, EmailSender emailSender, CatalogueValidator catalogueValidator,
            StaffService staffService) {
        this.libraryService = libraryService;
        this.captchaService = captchaService;
        this.usersService = usersService;
        this.emailSender = emailSender;
        this.catalogueValidator = catalogueValidator;
        this.staffService = staffService;


    }

    @RequestMapping(value = "/CatalogueMgmtAddRecord.htm")
    public ModelAndView CatalogueMgmtAddRecord(ModelMap modelMap) {
        Catalogue catalogue = new Catalogue();
        modelMap.addAttribute("catalogue", catalogue);
        libraryService.formAddOptionvalues(modelMap);
        String formerror = "";
        modelMap.addAttribute("formerror", formerror);
        return new ModelAndView("CatalogueMgmtAddRecord", modelMap);
    }

    @RequestMapping(value = "/CatalogueMgmtAddRecordSuccess.htm")
    public ModelAndView CatalogueMgmtAddRecordSuccess(
            @ModelAttribute("catalogue") Catalogue catalogue,
            BindingResult result, ModelMap model,
            HttpServletRequest request) throws Exception {

        catalogue.setYearofPublication(request.getParameter("yearofPublication"));


        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");


        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);

            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        catalogueValidator.validate(catalogue, result);

        if (result.hasErrors()) {
            libraryService.formAddOptionvalues(model);
            return new ModelAndView("CatalogueMgmtAddRecord", model);
        } else {
            if (!isResponseCorrect) { //Capatcha is not correct
                libraryService.formAddOptionvalues(model);
                model.addAttribute("formerror", "Capacth is Invalid");
                return new ModelAndView("CatalogueMgmtAddRecord", model);
            } else {


                libraryService.saveCatalogue(catalogue);
                model.addAttribute("catalogue", catalogue);
                return new ModelAndView("CatalogueMgmtAddRecordSuccess", model);
            }
        }
    }

    @RequestMapping("/CatalogueMgmtSearch.htm")
    public ModelAndView CatalogueMgmtSearch(ModelMap modelMap) {

        modelMap.addAttribute("catalogue1", new Catalogue());

        libraryService.formAddOptionvalues(modelMap);


        return new ModelAndView("CatalogueMgmtSearch", modelMap);

    }

    @RequestMapping(value = "/CatalogueMgmtSearchResult.htm")
    public ModelAndView CatalogueMgmtSearchResult(HttpServletRequest request, ModelMap modelMap,
            @ModelAttribute("catalogue1") Catalogue catalogue1) {

        request.getSession().setAttribute("catalogue1_session", catalogue1);
        modelMap.addAttribute("catalogue1", new Catalogue());
        catalogue1.setYearofPublication(request.getParameter("yearofPublication"));
        List<Catalogue> searchCatalogue = libraryService.searchCatalogue(catalogue1);
        modelMap.addAttribute("searchCatalogue", searchCatalogue);
        libraryService.formAddOptionvalues(modelMap);

        if (request.getParameter("typeofrecord").toString().equals("")
                && request.getParameter("author").toString().equals("")
                && request.getParameter("yearofPublication").toString().equals("")
                && request.getParameter("ISDNNo").toString().equals("")
                && request.getParameter("recordIdentifier").toString().equals("")) {
            return new ModelAndView("CatalogueMgmtSearch", modelMap);
        } else {
            return new ModelAndView("CatalogueMgmtSearchResult", modelMap);
        }
    }

    @RequestMapping("/CatalogueMgmtModify.htm")
    public ModelAndView CatalogueMgmtModify(
            ModelMap model,
            @ModelAttribute("catalogue") Catalogue catalogue,
            @RequestParam("selection") int selection, HttpServletRequest request) {

        if (selection != 0) {
            List<Catalogue> catalogueDetailsList = libraryService.findCatalogueById(selection);
            Catalogue catalogueDetails = new Catalogue();
            catalogueDetails = catalogueDetailsList.get(0);

            String year = catalogueDetails.getYearofPublication();
            // String[] splitedyear = year.split("[]");
            model.addAttribute("yearofPublication", year);

            model.addAttribute("selection", selection);
            model.addAttribute("catalogueDetails", catalogueDetails);

            libraryService.formAddOptionvalues(model);

            return new ModelAndView("CatalogueMgmtModify", model);
        } else {
            return new ModelAndView("CatalogueMgmtSearchResult", model);
        }

    }

    @RequestMapping(value = "/CatalogueMgmtModifySuccess.htm")
    public ModelAndView CatalogueMgmtModifySuccess(
            @ModelAttribute("catalogue") Catalogue catalogue,
            BindingResult result, ModelMap model,
            HttpServletRequest request,
            @RequestParam("selection") int selection) throws Exception {

        if (selection != 0) {

            catalogue.setId(selection);
            catalogue.setYearofPublication(request.getParameter("yearofPublication"));
            // Checking Capatch Response
            boolean isResponseCorrect = false;
            String captchaId = request.getSession().getId();
            String response = request.getParameter("j_captcha_response");

            try {
                if (response != null) {
                    isResponseCorrect = captchaService.validateResponseForID(captchaId, response);

                }

            } catch (CaptchaServiceException e) {
                log.error("Problem Jcaptcha settings ", e);
            }

            catalogueValidator.validate(catalogue, result);

            if (result.hasErrors()) {
                libraryService.formAddOptionvalues(model);
                return new ModelAndView("CatalogueMgmtModify", model);
            } else {
                if (!isResponseCorrect) { //Capatcha is not correct
                    libraryService.formAddOptionvalues(model);
                    model.addAttribute("formerror", "Capacth is Invalid");
                    return new ModelAndView("CatalogueMgmtModify", model);
                } else {


                    libraryService.saveCatalogue(catalogue);
                    model.addAttribute("catalogue", catalogue);
                }
            }
        }

        return new ModelAndView("CatalogueMgmtModifySuccess", model);
    }

    @RequestMapping(value = "/CatalogueMgmtSearchResultback.htm")
    public ModelAndView CatalogueMgmtSearchResultback(HttpServletRequest request, ModelMap modelMap) {

        Catalogue catalogue1 = (Catalogue) request.getSession().getAttribute("catalogue1_session");
        modelMap.addAttribute("catalogue1", new Catalogue());
        // catalogue1.setYearofPublication(request.getParameter("yearofPublication"));
        List<Catalogue> searchCatalogue = libraryService.searchCatalogue(catalogue1);
        modelMap.addAttribute("searchCatalogue", searchCatalogue);
        libraryService.formAddOptionvalues(modelMap);

        return new ModelAndView("CatalogueMgmtSearchResult", modelMap);
    }

    @RequestMapping("/CatalogueMgmtDeleteCatalogue.htm")
    public ModelAndView CatalogueMgmtDeleteResult(
            ModelMap model,
            @ModelAttribute("catalogue") Catalogue catalogue,
            @RequestParam("selection") int selection, HttpServletRequest request) {

        if (selection != 0) {
            List<Catalogue> catalogueDetailsList = libraryService.findCatalogueById(selection);
            Catalogue catalogueDetails = new Catalogue();
            catalogueDetails = catalogueDetailsList.get(0);

            String year = catalogueDetails.getYearofPublication();
            // String[] splitedyear = year.split("[]");
            model.addAttribute("yearofPublication", year);

            model.addAttribute("selection", selection);
            model.addAttribute("catalogueDetails", catalogueDetails);

            libraryService.formAddOptionvalues(model);

            return new ModelAndView("CatalogueMgmtDeleteCatalogue", model);
        } else {
            return new ModelAndView("CatalogueMgmtSearchResult", model);
        }

    }

    @RequestMapping("/CatalogueMgmtDeleteCatalogueSuccess.htm")
    public ModelAndView CatalogueMgmtDeleteCatalogueSuccess(
            ModelMap model,
            @ModelAttribute("catalogue") Catalogue catalogue,
            @RequestParam("selection") int selection) {

        if (selection != 0) {
            List<Catalogue> catalogueDetailsList = libraryService.findCatalogueById(selection);
            catalogue = catalogueDetailsList.get(0);

            libraryService.deleteCatalogueRecord(catalogue);

            return new ModelAndView("CatalogueMgmtDeleteCatalogueSuccess", model);
        } else {
            return new ModelAndView("CatalogueMgmtDeleteCatalogue", model);
        }

    }

    @RequestMapping("/LibrarianCheckOut.htm")
    public ModelAndView LibrarianCheckOut(ModelMap model) {

        Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
        model.addAttribute("checkinandoutlog", checkinandoutlog);
        return new ModelAndView("LibrarianCheckOut", model);
    }

    @RequestMapping("/LibrarianCheckOutConfirm.htm")
    public ModelAndView LibrarianCheckOutConfirm(ModelMap model,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog,
            HttpServletRequest request) {


        List<Staff> staffDetailsList = staffService.findStaffByUserid(checkinandoutlog.getBorrowerUsername());

        List<Catalogue> catalogueDetailsList = libraryService.findCatalogueByRecordIdentifier(checkinandoutlog.getRecordIdentifier());

        Catalogue catalogueDetails = catalogueDetailsList.get(0);
        String bookdetails;

        bookdetails = catalogueDetails.getTitle() + "," + catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                + "," + catalogueDetails.getPublishers();

        Staff staffdetails = staffDetailsList.get(0);

        String borrowerdetails;
        borrowerdetails = staffdetails.getFirstname() + "," + staffdetails.getLastname() + ","
                + staffdetails.getCurrentDesignation() + "," + staffdetails.getDepartment();

        Date currentDate = new Date();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

        checkinandoutlog.setIssuedDate(dateFormat.format(currentDate).toString());
        checkinandoutlog.setIssuedTime(currentTime.format(currentDate).toString());
        checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());
        checkinandoutlog.setStatus("CheckOut");
        checkinandoutlog.setFinePaid("");

        //libraryService.saveCheckinoutlog(checkinandoutlog);
        model.addAttribute("checkinandoutlog", checkinandoutlog);

        model.addAttribute("bookdetails", bookdetails);
        model.addAttribute("borrowerdetails", borrowerdetails);

        String recordIdentifier = checkinandoutlog.getRecordIdentifier();

        model.addAttribute("recordIdentifier", recordIdentifier);

        String borrowerUsername = staffdetails.getUsername();

        model.addAttribute("borrowerUsername", borrowerUsername);


        return new ModelAndView("LibrarianCheckOutConfirm", model);
    }

    @RequestMapping("/LibrarianCheckOutConfirmSuccess.htm")
    public ModelAndView LibrarianCheckOutConfirmSuccess(ModelMap model,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog,
            HttpServletRequest request) {

        List<Staff> staffDetailsList = staffService.findStaffByUserid(checkinandoutlog.getBorrowerUsername());

        List<Catalogue> catalogueDetailsList = libraryService.findCatalogueByRecordIdentifier(checkinandoutlog.getRecordIdentifier());

        Catalogue catalogueDetails = catalogueDetailsList.get(0);
        String bookdetails;

        bookdetails = catalogueDetails.getTitle() + "," + catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                + "," + catalogueDetails.getPublishers();

        Staff staffdetails = staffDetailsList.get(0);

        String borrowerdetails;
        borrowerdetails = staffdetails.getFirstname() + "," + staffdetails.getLastname() + ","
                + staffdetails.getCurrentDesignation() + "," + staffdetails.getDepartment();

        Date currentDate = new Date();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

        checkinandoutlog.setIssuedDate(dateFormat.format(currentDate).toString());
        checkinandoutlog.setIssuedTime(currentTime.format(currentDate).toString());
        checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());
        checkinandoutlog.setStatus("CheckOut");
        checkinandoutlog.setFinePaid("");

        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");

        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        //   else {
        if (!isResponseCorrect) { //Capatcha is not correct
            libraryService.formAddOptionvalues(model);
            model.addAttribute("formerror", "Capacth is Invalid");
            return new ModelAndView("LibrarianCheckOutConfirm", model);
        } else {

            libraryService.saveCheckinandoutlog(checkinandoutlog);

            model.addAttribute("checkinandoutlog", checkinandoutlog);
            model.addAttribute("bookdetails", bookdetails);
            model.addAttribute("borrowerdetails", borrowerdetails);

            String recordIdentifier = checkinandoutlog.getRecordIdentifier();
            model.addAttribute("recordIdentifier", recordIdentifier);

            String borrowerUsername = staffdetails.getUsername();
            model.addAttribute("borrowerUsername", borrowerUsername);

            return new ModelAndView("LibrarianCheckOutConfirmSuccess", model);
        }
    }

    @RequestMapping(value = "/LibrarianCheckOutConfirmCancel.htm")
    public ModelAndView LibrarianCheckOutConfirmCancel(ModelMap modelMap) {
        Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
        modelMap.addAttribute("checkinandoutlog", checkinandoutlog);

        return new ModelAndView("LibrarianCheckOut", modelMap);

    }

    @RequestMapping("/LibrarianCheckIn.htm")
    public ModelAndView LibrarianCheckIn(ModelMap model) {

        Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
        model.addAttribute("checkinandoutlog", checkinandoutlog);
        return new ModelAndView("LibrarianCheckIn", model);
    }

    @RequestMapping("/LibrarianCheckInConfirm.htm")
    public ModelAndView LibrarianCheckInConfirm(ModelMap model,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog,
            HttpServletRequest request) {

        List<Catalogue> catalogueDetailsList = libraryService.findCatalogueByRecordIdentifier(checkinandoutlog.getRecordIdentifier());

        Catalogue catalogueDetails = catalogueDetailsList.get(0);
        String booktitle;
        booktitle = catalogueDetails.getTitle();

        String bookdetails;

        bookdetails = catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                + "," + catalogueDetails.getPublishers();

        List<Checkinandoutlog> checkinandoutlogDetailsList = libraryService.findCheckinandoutlogByRecordIdentifier(catalogueDetails.getRecordIdentifier());

        Checkinandoutlog checkinandoutlogDetails = checkinandoutlogDetailsList.get(0);

        List<Staff> staffDetailsList = staffService.findStaffByUserid(checkinandoutlogDetails.getBorrowerUsername());

        Staff staffdetails = staffDetailsList.get(0);

        String borrowerdetails;
        borrowerdetails = staffdetails.getFirstname() + "," + staffdetails.getLastname() + ","
                + staffdetails.getCurrentDesignation() + "," + staffdetails.getDepartment();

        String IssuedDate = checkinandoutlogDetails.getIssuedDate();

        Calendar c1 = Calendar.getInstance();
        // roll down the month
        c1.set(Integer.parseInt(IssuedDate.split("/")[2]),
                Integer.parseInt(IssuedDate.split("/")[1]) - 1,
                Integer.parseInt(IssuedDate.split("/")[0])); // 1999 jan 20

        c1.add(Calendar.DAY_OF_MONTH, 15);
        //c1.getTime()

        String DueDate = Integer.toString(c1.get(Calendar.DAY_OF_MONTH)) + "/"
                + Integer.toString(c1.get(Calendar.MONTH) + 1) + "/"
                + Integer.toString(c1.get(Calendar.YEAR));

        Date duedate = c1.getTime();
        Date today = new Date();
        // Get msec from each, and subtract.
        long diff = today.getTime() - duedate.getTime();
        double lateness;
        if (diff > 0) {
            lateness = Math.rint((double) diff / (1000 * 60 * 60 * 24));
        } else {
            lateness = 0;
        }

        Date currentDate = new Date();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

        String TotalFine = Double.toString(lateness * 4.0);

        model.addAttribute("checkinandoutlog", checkinandoutlog);
        model.addAttribute("booktitle", booktitle);
        model.addAttribute("bookdetails", bookdetails);
        model.addAttribute("borrowerdetails", borrowerdetails);
        model.addAttribute("IssuedDate", IssuedDate);
        model.addAttribute("DueDate", DueDate);
        model.addAttribute("TotalFine", TotalFine);

        String recordIdentifier = checkinandoutlog.getRecordIdentifier();

        model.addAttribute("recordIdentifier", recordIdentifier);

        String borrowerUsername = staffdetails.getUsername();

        model.addAttribute("borrowerUsername", borrowerUsername);


        return new ModelAndView("LibrarianCheckInConfirm", model);
    }

    @RequestMapping("/LibrariancheckInConfirmSuccess.htm")
    public ModelAndView LibrariancheckInConfirmSuccess(ModelMap model,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog,
            HttpServletRequest request) {

        List<Catalogue> catalogueDetailsList = libraryService.findCatalogueByRecordIdentifier(checkinandoutlog.getRecordIdentifier());

        Catalogue catalogueDetails = catalogueDetailsList.get(0);
        String booktitle;
        booktitle = catalogueDetails.getTitle();

        String bookdetails;

        bookdetails = catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                + "," + catalogueDetails.getPublishers();

        List<Checkinandoutlog> checkinandoutlogDetailsList = libraryService.findCheckinandoutlogByRecordIdentifier(catalogueDetails.getRecordIdentifier());

        Checkinandoutlog checkinandoutlogDetails = checkinandoutlogDetailsList.get(0);

        List<Staff> staffDetailsList = staffService.findStaffByUserid(checkinandoutlogDetails.getBorrowerUsername());

        Staff staffdetails = staffDetailsList.get(0);

        String borrowerdetails;
        borrowerdetails = staffdetails.getFirstname() + "," + staffdetails.getLastname() + ","
                + staffdetails.getCurrentDesignation() + "," + staffdetails.getDepartment();

        String IssuedDate = checkinandoutlogDetails.getIssuedDate();

        Calendar c1 = Calendar.getInstance();
        // roll down the month
        c1.set(Integer.parseInt(IssuedDate.split("/")[2]),
                Integer.parseInt(IssuedDate.split("/")[1]) - 1,
                Integer.parseInt(IssuedDate.split("/")[0])); // 1999 jan 20

        c1.add(Calendar.DAY_OF_MONTH, 15);
        //c1.getTime()

        String DueDate = Integer.toString(c1.get(Calendar.DAY_OF_MONTH)) + "/"
                + Integer.toString(c1.get(Calendar.MONTH) + 1) + "/"
                + Integer.toString(c1.get(Calendar.YEAR));

        Date duedate = c1.getTime();
        Date today = new Date();
        // Get msec from each, and subtract.
        long diff = today.getTime() - duedate.getTime();
        double lateness;
        if (diff > 0) {
            lateness = Math.rint((double) diff / (1000 * 60 * 60 * 24));
        } else {
            lateness = 0;
        }

        Date currentDate = new Date();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

        String TotalFine = Double.toString(lateness * 4.0);

        //Date OrigainalDate = new Date(2010,5,18);
        checkinandoutlog.setBorrowerUsername(checkinandoutlogDetails.getBorrowerUsername());
        checkinandoutlog.setIssuedDate(checkinandoutlogDetails.getIssuedDate());
        checkinandoutlog.setIssuedTime(checkinandoutlogDetails.getIssuedTime());
        checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());
        checkinandoutlog.setStatus("CheckIn");
        checkinandoutlog.setFinePaid(TotalFine);
        checkinandoutlog.setId(checkinandoutlogDetails.getId());

        libraryService.saveCheckinandoutlog(checkinandoutlog);
        model.addAttribute("checkinandoutlog", checkinandoutlog);
        model.addAttribute("booktitle", booktitle);
        model.addAttribute("bookdetails", bookdetails);
        model.addAttribute("borrowerdetails", borrowerdetails);
        model.addAttribute("IssuedDate", IssuedDate);
        model.addAttribute("DueDate", DueDate);
        model.addAttribute("TotalFine", TotalFine);

        String recordIdentifier = checkinandoutlog.getRecordIdentifier();

        model.addAttribute("recordIdentifier", recordIdentifier);

        String borrowerUsername = staffdetails.getUsername();

        model.addAttribute("borrowerUsername", borrowerUsername);


        return new ModelAndView("LibrariancheckInConfirmSuccess", model);
    }

    @RequestMapping(value = "/LibrariancheckInConfirmCancel.htm")
    public ModelAndView LibrariancheckInConfirmCancel(ModelMap modelMap) {
        Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
        modelMap.addAttribute("checkinandoutlog", checkinandoutlog);

        return new ModelAndView("LibrarianCheckIn", modelMap);

    }

    @RequestMapping("/LibrarianCheckInSearch.htm")
    public ModelAndView LibrarianCheckInSearch(ModelMap modelMap) {

        modelMap.addAttribute("checkinandoutlog", new Checkinandoutlog());

        return new ModelAndView("LibrarianCheckInSearch", modelMap);

    }

    @RequestMapping(value = "/LibrarianCheckInSearchResult.htm")
    public ModelAndView LibrarianCheckInSearchResult(HttpServletRequest request, ModelMap modelMap,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog) {

        request.getSession().setAttribute("checkinandoutlog_session", checkinandoutlog);
        modelMap.addAttribute("checkinandoutlog", new Checkinandoutlog());
        List<Checkinandoutlog> searchCheckinandoutlog = libraryService.searchCheckinandoutlog(checkinandoutlog.getBorrowerUsername());
        modelMap.addAttribute("searchCheckinandoutlog", searchCheckinandoutlog);


        return new ModelAndView("LibrarianCheckInSearchResult", modelMap);

    }

    @RequestMapping(value = "/LibrarianCheckInSearchResultCheckin.htm")
    public ModelAndView LibrarianCheckInSearchResultCheckin(
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog,
            BindingResult result, ModelMap model,
            HttpServletRequest request,
            @RequestParam("selection") int selection) throws Exception {

        if (selection != 0) {

            checkinandoutlog.setId(selection);


            List<Checkinandoutlog> checkinandoutlogDetailsList = libraryService.findCheckinandoutlogById(selection);

            Checkinandoutlog checkinandoutlogDetails = checkinandoutlogDetailsList.get(0);


            List<Catalogue> catalogueDetailsList = libraryService.findCatalogueByRecordIdentifier(checkinandoutlogDetails.getRecordIdentifier());

            Catalogue catalogueDetails = catalogueDetailsList.get(0);
            String booktitle;
            booktitle = catalogueDetails.getTitle();

            String bookdetails;

            bookdetails = catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                    + "," + catalogueDetails.getPublishers();


            List<Staff> staffDetailsList = staffService.findStaffByUserid(checkinandoutlogDetails.getBorrowerUsername());

            Staff staffdetails = staffDetailsList.get(0);

            String borrowerdetails;
            borrowerdetails = staffdetails.getFirstname() + "," + staffdetails.getLastname() + ","
                    + staffdetails.getCurrentDesignation() + "," + staffdetails.getDepartment();

            String IssuedDate = checkinandoutlogDetails.getIssuedDate();

            Calendar c1 = Calendar.getInstance();
            // roll down the month
            c1.set(Integer.parseInt(IssuedDate.split("/")[2]),
                    Integer.parseInt(IssuedDate.split("/")[1]) - 1,
                    Integer.parseInt(IssuedDate.split("/")[0])); // 1999 jan 20

            c1.add(Calendar.DAY_OF_MONTH, 15);
            //c1.getTime()

            String DueDate = Integer.toString(c1.get(Calendar.DAY_OF_MONTH)) + "/"
                    + Integer.toString(c1.get(Calendar.MONTH) + 1) + "/"
                    + Integer.toString(c1.get(Calendar.YEAR));

            Date duedate = c1.getTime();
            Date today = new Date();
            // Get msec from each, and subtract.
            long diff = today.getTime() - duedate.getTime();
            double lateness;
            if (diff > 0) {
                lateness = Math.rint((double) diff / (1000 * 60 * 60 * 24));
            } else {
                lateness = 0;
            }

            Date currentDate = new Date();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

            String TotalFine = Double.toString(lateness * 4.0);

            model.addAttribute("booktitle", booktitle);
            model.addAttribute("bookdetails", bookdetails);
            model.addAttribute("borrowerdetails", borrowerdetails);
            model.addAttribute("IssuedDate", IssuedDate);
            model.addAttribute("DueDate", DueDate);
            model.addAttribute("TotalFine", TotalFine);

            String recordIdentifier = checkinandoutlog.getRecordIdentifier();

            model.addAttribute("recordIdentifier", recordIdentifier);

            String borrowerUsername = staffdetails.getUsername();

            model.addAttribute("borrowerUsername", borrowerUsername);



        }

        return new ModelAndView("LibrarianCheckInSearchResultCheckin", model);
    }



    @RequestMapping(value = "/LibrarianCheckInSearchResultCancel.htm")
    public ModelAndView LibrarianCheckInSearchResultCancel(ModelMap modelMap) {
        Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
        modelMap.addAttribute("checkinandoutlog", checkinandoutlog);

        return new ModelAndView("LibrarianCheckInSearch", modelMap);

    }








    @RequestMapping(value = "/LibrarianCheckInSearchResultCheckinConfirm.htm")
    public ModelAndView LibrarianCheckInSearchResultCheckinConfirm(
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog,
            BindingResult result, ModelMap model,
            HttpServletRequest request,
            @RequestParam("selection") int selection) throws Exception {

        if (selection != 0) {

            checkinandoutlog.setId(selection);


            List<Checkinandoutlog> checkinandoutlogDetailsList = libraryService.findCheckinandoutlogById(selection);

            Checkinandoutlog checkinandoutlogDetails = checkinandoutlogDetailsList.get(0);


            List<Catalogue> catalogueDetailsList = libraryService.findCatalogueByRecordIdentifier(checkinandoutlogDetails.getRecordIdentifier());

            Catalogue catalogueDetails = catalogueDetailsList.get(0);
            String booktitle;
            booktitle = catalogueDetails.getTitle();

            String bookdetails;

            bookdetails = catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                    + "," + catalogueDetails.getPublishers();


            List<Staff> staffDetailsList = staffService.findStaffByUserid(checkinandoutlogDetails.getBorrowerUsername());

            Staff staffdetails = staffDetailsList.get(0);

            String borrowerdetails;
            borrowerdetails = staffdetails.getFirstname() + "," + staffdetails.getLastname() + ","
                    + staffdetails.getCurrentDesignation() + "," + staffdetails.getDepartment();

            String IssuedDate = checkinandoutlogDetails.getIssuedDate();

            Calendar c1 = Calendar.getInstance();
            // roll down the month
            c1.set(Integer.parseInt(IssuedDate.split("/")[2]),
                    Integer.parseInt(IssuedDate.split("/")[1]) - 1,
                    Integer.parseInt(IssuedDate.split("/")[0])); // 1999 jan 20

            c1.add(Calendar.DAY_OF_MONTH, 15);
            //c1.getTime()

            String DueDate = Integer.toString(c1.get(Calendar.DAY_OF_MONTH)) + "/"
                    + Integer.toString(c1.get(Calendar.MONTH) + 1) + "/"
                    + Integer.toString(c1.get(Calendar.YEAR));

            Date duedate = c1.getTime();
            Date today = new Date();
            // Get msec from each, and subtract.
            long diff = today.getTime() - duedate.getTime();
            double lateness;
            if (diff > 0) {
                lateness = Math.rint((double) diff / (1000 * 60 * 60 * 24));
            } else {
                lateness = 0;
            }

            Date currentDate = new Date();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

            String TotalFine = Double.toString(lateness * 4.0);

            //Date OrigainalDate = new Date(2010,5,18);
            checkinandoutlog.setBorrowerUsername(checkinandoutlogDetails.getBorrowerUsername());
            checkinandoutlog.setIssuedDate(checkinandoutlogDetails.getIssuedDate());
            checkinandoutlog.setIssuedTime(checkinandoutlogDetails.getIssuedTime());
            checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());
            checkinandoutlog.setStatus("CheckIn");
            checkinandoutlog.setFinePaid(TotalFine);
            checkinandoutlog.setId(checkinandoutlogDetails.getId());
            checkinandoutlog.setRecordIdentifier(checkinandoutlogDetails.getRecordIdentifier());

            //libraryService.saveCheckinandoutlog(checkinandoutlog);
            model.addAttribute("checkinandoutlog", checkinandoutlog);
            model.addAttribute("booktitle", booktitle);
            model.addAttribute("bookdetails", bookdetails);
            model.addAttribute("borrowerdetails", borrowerdetails);
            model.addAttribute("IssuedDate", IssuedDate);
            model.addAttribute("DueDate", DueDate);
            model.addAttribute("TotalFine", TotalFine);

            String recordIdentifier = checkinandoutlog.getRecordIdentifier();

            model.addAttribute("recordIdentifier", recordIdentifier);

            String borrowerUsername = staffdetails.getUsername();

            model.addAttribute("borrowerUsername", borrowerUsername);



        }

        return new ModelAndView("LibrarianCheckInSearchResultCheckinConfirm", model);
    }






}






