package com.suman.service;
import java.util.List;
import java.util.ArrayList;
import org.springframework.ui.ModelMap;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.suman.domain.Catalogue;
import com.suman.domain.Checkinandoutlog;
import com.suman.domain.LibraryRuleSet;
import org.hibernate.LockMode;
import java.text.DateFormat;
import java.util.Calendar;


public class LibraryServiceImp implements LibraryService {

    private HibernateTemplate hibernateTemplate;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.hibernateTemplate = new HibernateTemplate(sessionFactory);
    }

    public void formAddOptionvalues(ModelMap modelMap) {


        String[] Typeofrecord = {"", "Book", "Journal", "Magazine"};// "Assam", "Bihar", "Chandigarh", "Chhattisgarh", "Dadra and Nagar Haveli", "Daman and Diu", "Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka", "Kerala", "Lakshadweep", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Orissa", "Puducherry", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal", "Other"};
        modelMap.addAttribute("Typeofrecord", Typeofrecord);

        int i;

        List<Object> year = new ArrayList();
        for (i = 1899; i < 2051; i++) {
            if (i == 1899) {
                year.add((Object) (""));
            } else {
                year.add((Object) i);
            }
        }

        modelMap.addAttribute("year", year);

    }

    @Override
    public void saveCatalogue(Catalogue catalogue) {
        System.out.println("Hello--->");
       hibernateTemplate.saveOrUpdate(catalogue);
    }


     @Override
    @SuppressWarnings("unchecked")
    public List<Catalogue> searchCatalogue(Catalogue catalogue1) {

        Object row[] = new Object[6];
        row[0] = (Object) ('%' + catalogue1.getTypeofrecord() + '%');
        row[1] = (Object) ('%' + catalogue1.getAuthor() + '%');
        row[2] = (Object) ('%' + catalogue1.getYearofPublication() + '%');
        row[3] = (Object) ('%' + catalogue1.getTitle() + '%');
        row[4] = (Object) ('%' + catalogue1.getSubjectCategory() + '%');
        row[5] = (Object) ('%' + catalogue1.getKeywords() + '%');

        return hibernateTemplate.find("from Catalogue where TypeofRecord like ? AND Author like ? AND YearofPublication like ? AND Title like ? AND SubjectCategory like ? AND Keywords like ?", row);
    }


    @Override
    @SuppressWarnings("unchecked")
    public List<Catalogue> findCatalogueById(int id) {
        return hibernateTemplate.find("from Catalogue where ID = ?",id);
    }



    @Override
    public void deleteCatalogueRecord(Catalogue catalogue) {
        System.out.println("Hello--->");
        hibernateTemplate.delete(catalogue);
    }



    @Override
    @SuppressWarnings("unchecked")
    public List<Catalogue> findCatalogueByRecordIdentifier(String recordIdentifier) {
        return hibernateTemplate.find("from Catalogue where RecordIdentifier = ?",recordIdentifier);
    }


    @Override
    public void saveCheckinandoutlog(Checkinandoutlog checkinandoutlog) {
        System.out.println("Hello--->");
       hibernateTemplate.saveOrUpdate(checkinandoutlog);;
    }


    @Override
    @SuppressWarnings("unchecked")
    public List<Checkinandoutlog> findCheckinandoutlogByRecordIdentifier(String recordIdentifier) {

        return hibernateTemplate.find("from Checkinandoutlog where RecordIdentifier = ?",recordIdentifier);
    }



     @Override
    @SuppressWarnings("unchecked")
    public List<Checkinandoutlog> searchCheckinandoutlog(String borrowerUsername) {
         Object row[] = new Object[2];
         row[0] = (Object) borrowerUsername;
         row[1] = (Object) ("CheckOut");

        return hibernateTemplate.find("from Checkinandoutlog where BorrowerUsername = ? AND status = ? ",row);
    }


       @Override
    @SuppressWarnings("unchecked")
    public  int findCheckOutsByUserprimkey(long userprimkey) {


           Object row[] = new Object[2];
         row[0] = (Object) userprimkey;
         row[1] = (Object) ("CheckOut");
         List<Checkinandoutlog>  checkedoutDetails =hibernateTemplate.find("from Checkinandoutlog where Userprimkey = ? AND status = ? ",row);

         return checkedoutDetails.size();
    }

      @Override
    @SuppressWarnings("unchecked")
    public List<Checkinandoutlog> findCheckinandoutlogById(int id) {
        return hibernateTemplate.find("from Checkinandoutlog where ID = ?",id);
    }

    @Override
    @SuppressWarnings("unchecked")
    public  List<Checkinandoutlog> findCheckinandoutlogByRIwithCheckout(String recordIdentifier) {


        Object row[] = new Object[2];
        row[0] = (Object) recordIdentifier;
        row[1] = (Object) ("CheckOut");
       return  hibernateTemplate.find("from Checkinandoutlog where RecordIdentifier = ? AND status = ? ", row);

        
    }


     @Override
    @SuppressWarnings("unchecked")
    public List<Checkinandoutlog> findReservedItemsByRI(String recordIdentifier) {
           Object row[] = new Object[2];
         row[0] = (Object) recordIdentifier;
         row[1] = (Object) ("Reserved");
        return hibernateTemplate.find("from Checkinandoutlog where RecordIdentifier = ? AND status = ? ",row);
    }

      @Override
    @SuppressWarnings("unchecked")
    public String DateConversion(Calendar c)
      {
          String DueDate;


          //if(c.get(Calendar.DAY_OF_MONTH)<10)
          String Day;
          if(c.get(Calendar.DAY_OF_MONTH)<10)
          {
          Day= "0" + Integer.toString(c.get(Calendar.DAY_OF_MONTH));
          }
          else
          {
              Day= Integer.toString(c.get(Calendar.DAY_OF_MONTH));
          }

          String Month;
          if(c.get(Calendar.MONTH)<10)
          {
              Month  = "0" +Integer.toString(c.get(Calendar.MONTH) + 1);
              
          }else
          {
              Month  = Integer.toString(c.get(Calendar.MONTH) + 1);
          }

          
          String Year = Integer.toString(c.get(Calendar.YEAR));

          DueDate = Day +"/"+Month+"/"+Year;


          return DueDate;

      }


      @Override
    public void saveLibraryRuleSet(LibraryRuleSet libraryRuleSet) {
       
       hibernateTemplate.saveOrUpdate(libraryRuleSet);
    }


        @Override
    public List<LibraryRuleSet> LibraryRuleSetResults() {
       
       return hibernateTemplate.find("from LibraryRuleSet");

    }

          @Override
    @SuppressWarnings("unchecked")
    public List<Checkinandoutlog> findCheckinandoutlogByUserprimkey(long userprimkey) {
        return hibernateTemplate.find("from Checkinandoutlog where Userprimkey = ?",userprimkey);
    }


          @Override
    @SuppressWarnings("unchecked")
    public  List<Checkinandoutlog> findCheckoutListByUserprimkey(long userprimkey) {


        Object row[] = new Object[2];
        row[0] = (Object) userprimkey;
        row[1] = (Object) ("CheckOut");
       return  hibernateTemplate.find("from Checkinandoutlog where userprimkey = ? AND status = ? ", row);


    }

}
