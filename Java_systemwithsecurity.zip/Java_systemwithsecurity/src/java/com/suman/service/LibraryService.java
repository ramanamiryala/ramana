package com.suman.service;
import java.util.List;
import org.springframework.ui.ModelMap;

import com.suman.domain.Catalogue;
import com.suman.domain.Checkinandoutlog;
public interface LibraryService {

    public void saveCatalogue(Catalogue catalogue);

     public void formAddOptionvalues(ModelMap modelMap);

     public List<Catalogue> searchCatalogue(Catalogue catalogue1);

     public List<Catalogue> findCatalogueById(int id);

     public void deleteCatalogueRecord(Catalogue catalogue);

     public List<Catalogue> findCatalogueByRecordIdentifier(String recordIdentifier);

     public void saveCheckinandoutlog(Checkinandoutlog checkinandoutlog);

     public List<Checkinandoutlog> findCheckinandoutlogByRecordIdentifier(String recordIdentifier);

     public List<Checkinandoutlog> searchCheckinandoutlog(String borrowerUsername);

     public List<Checkinandoutlog> findCheckinandoutlogById(int id);

}
