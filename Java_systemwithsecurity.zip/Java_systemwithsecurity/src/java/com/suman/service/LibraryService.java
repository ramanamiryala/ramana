package com.suman.service;

import java.util.List;
import org.springframework.ui.ModelMap;
import java.util.Calendar;


import com.suman.domain.Catalogue;
import com.suman.domain.Checkinandoutlog;
import com.suman.domain.LibraryRuleSet;

public interface LibraryService {

    public void saveCatalogue(Catalogue catalogue);

    public void formAddOptionvalues(ModelMap modelMap);

    public List<Catalogue> searchCatalogue(Catalogue catalogue1);

    public List<Catalogue> findCatalogueById(int id);

    public void deleteCatalogueRecord(Catalogue catalogue);

    public List<Catalogue> findCatalogueByRecordIdentifier(String recordIdentifier);

    public void saveCheckinandoutlog(Checkinandoutlog checkinandoutlog);

    public List<Checkinandoutlog> findCheckinandoutlogByRecordIdentifier(String recordIdentifier);

    public List<Checkinandoutlog> searchCheckinandoutlog(String borrowerUsername);

    public List<Checkinandoutlog> findCheckinandoutlogById(int id);

     public int findCheckOutsByUserprimkey(long userprimkey);

    public List<Checkinandoutlog> findCheckinandoutlogByRIwithCheckout(String recordIdentifier);

    public List<Checkinandoutlog> findReservedItemsByRI(String recordIdentifier);

    public String DateConversion(Calendar c);

    public void saveLibraryRuleSet(LibraryRuleSet libraryRuleSet);

     public List<LibraryRuleSet> LibraryRuleSetResults();

     public List<Checkinandoutlog> findCheckinandoutlogByUserprimkey(long userprimkey);

     public  List<Checkinandoutlog> findCheckoutListByUserprimkey(long userprimkey);


}
