
package com.suman.service;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;
import com.suman.domain.Student;
import com.suman.domain.Marks;
import com.suman.domain.Attendence;
import com.suman.domain.Library;



public class StudentServiceImp implements StudentService {

        private HibernateTemplate hibernateTemplate;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.hibernateTemplate = new HibernateTemplate(sessionFactory);
	}


        @Override
    public void setStudentDetails(Student student, List<Student> studentDetails) {

            student.setBranch(studentDetails.get(0).getBranch());
               student.setEmailid(studentDetails.get(0).getEmailid());
               student.setId(studentDetails.get(0).getId());
               student.setYear1(studentDetails.get(0).getYear1());
               student.setRno(studentDetails.get(0).getRno());
               student.setPhno(studentDetails.get(0).getPhno());
               student.setStudentAddress(studentDetails.get(0).getStudentAddress());
               student.setParentAddress(studentDetails.get(0).getParentAddress());


        }



        @Override
        public void retrieveStudent(Student student){

            List<Student> studentDetails =null;

            if (student.getId() > 0) {
            studentDetails = (List<Student>) hibernateTemplate.find("from Student where st_id= ? ", student.getId());
        }


            else if(student.getName()!=null && student.getPassword()!=null)
            {
            Object row[] = new Object[2];
            row[0] = (Object)student.getName();
            row[1] = (Object)student.getPassword();
           studentDetails = (List<Student>) hibernateTemplate.find("from Student where st_name = ? AND st_password = ? ", row);
            }
            

           if(studentDetails.size() > 0){
                setStudentDetails(student,studentDetails);
           
               
           }
           else
           {
               System.out.println("This student is not added in the Stduent Database");
           }


        }



        @Override
        public boolean studentLoginCheck(Student student){

            List<Student> studentDetails;

             //List<Marks> studentDetails;
            Object row[] = new Object[2];
            row[0] = (Object)student.getName();
            row[1] = (Object)student.getPassword();
           studentDetails = (List<Student>) hibernateTemplate.find("from Student where st_name = ? AND st_password = ? ", row);



           if(studentDetails.size() != 0)
           {
               //student.setBranch(studentDetails.get(0).getBranch());
               //student.setEmailid(studentDetails.get(0).getEmailid());
               //student.setId(studentDetails.get(0).getId());
              // student.setYear1(studentDetails.get(0).getYear1());
               //student.setRno(studentDetails.get(0).getRno());
               //student.setPhno(studentDetails.get(0).getPhno());
               return true;
           }
           else
                return false;
        }







        @Override
	public void updateStudent(Student student) {
           System.out.println("Hello--->");
            hibernateTemplate.update(student);
        }



	@Override
	public void saveStudent(Student student) {
           System.out.println("Hello--->");
            hibernateTemplate.saveOrUpdate(student);
        }

       	@Override
	@SuppressWarnings("unchecked")
	public List<Student> listStudent(Student student) {
		return hibernateTemplate.find("from Student where st_Rno = ? ",student.getRno());
	}

        @Override
	@SuppressWarnings("unchecked")

	public List<Marks> listMarks(Student student ){

            return hibernateTemplate.find("from Marks where mr_Rno = ? ",student.getRno());

	}
        @Override
	@SuppressWarnings("unchecked")

        public List<Attendence> listAttendence(Student student){
         return hibernateTemplate.find("from Attendence where at_Rno = ? ",student.getRno());
	}

        @Override
	@SuppressWarnings("unchecked")

        public List<Library> listLibrary(Student student){
         return hibernateTemplate.find("from Library where lib_Rno = ? ",student.getRno());
	}

        @Override
	@SuppressWarnings("unchecked")
        public List<Library> searchLibrary(Library library1){

              Object row[] = new Object[2];
            row[0] = (Object)('%'+ library1.getBook_name()+'%');
            row[1] = (Object)('%'+ library1.getSubject()+'%');
         return hibernateTemplate.find("from Library where lib_book_name like ? AND lib_subject like ?",row);
	}

        @Override
	@SuppressWarnings("unchecked")
        public List<Student> searchStudent(Student student1){

              Object row[] = new Object[2];
            row[0] = (Object)('%'+ student1.getName()+'%');
            row[1] = (Object)('%'+ student1.getRno()+'%');

         return hibernateTemplate.find("from Student where st_name like ? AND st_Rno like ? ", row);
	}



}
