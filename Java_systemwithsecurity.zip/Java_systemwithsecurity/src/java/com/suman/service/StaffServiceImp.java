package com.suman.service;

import java.util.List;
import java.util.ArrayList;
import org.springframework.ui.ModelMap;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;
import com.suman.domain.Staff;
import com.suman.domain.LeaveApplication;
import com.suman.domain.LeaveSummary;

public class StaffServiceImp implements StaffService {

    private HibernateTemplate hibernateTemplate;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.hibernateTemplate = new HibernateTemplate(sessionFactory);
    }

    public void formAddOptionvalues(ModelMap modelMap) {
        List<String> sex = new ArrayList();
        sex.add("SELECT");
        sex.add("FEMALE");
        sex.add("MALE");
        modelMap.addAttribute("sex", sex);

        List<String> religion = new ArrayList();
        religion.add("SELECT");
        religion.add("Hindu");
        religion.add("Muslim");
        religion.add("Christian");
        religion.add("Others");
        modelMap.addAttribute("religion", religion);

        int i;
        List<Object> day = new ArrayList();

        for (i = 0; i < 32; i++) {
            if (i == 0) {
                day.add((Object) (""));
            } else {
                if(i>=10)
                {
                day.add((Object) i);
                }
                else
                {
                    day.add((Object)("0"+ Integer.toString(i)));
                }
            }
        }

        modelMap.addAttribute("day", day);

        List<Object> month = new ArrayList();
        for (i = 0; i < 13; i++) {
            if (i == 0) {
                month.add((Object) (""));
            } else {
                if(i>=10)
                {
                month.add((Object) i);
                }
                else
                {
                    month.add((Object)("0"+ Integer.toString(i)));
                }
            }
        }

        modelMap.addAttribute("month", month);

        String[] months = {"", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};
        modelMap.addAttribute("months", months);

        List<Object> year = new ArrayList();
        for (i = 1899; i < 2051; i++) {
            if (i == 1899) {
                year.add((Object) (""));
            } else {
                year.add((Object) i);
            }
        }

        modelMap.addAttribute("year", year);

        String[] states = {"", "Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chandigarh", "Chhattisgarh", "Dadra and Nagar Haveli", "Daman and Diu", "Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka", "Kerala", "Lakshadweep", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Orissa", "Puducherry", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal", "Other"};
        modelMap.addAttribute("states", states);


        String[] countries = {"", "Australia", "Bahrain", "Bangladesh", "Belgium", "Canada", "Doha", "Dubai", "France", "Germany", "Hong Kong", "INDIA", "Indonesia", "Ireland", "Italy", "Japan", "Kenya", "Kuwait", "Lebanon", "Libya", "Malaysia", "Maldives", "Mauritius", "Mexico", "Nepal", "Netherlands", "New Zealand", "Norway", "Oman", "Pakistan", "Qatar", "Quilon", "Russia", "Saudi Arabia", "Singapore", "South Africa", "South Korea", "Spain", "Sri Lanka", "Sweden", "Switzerland", "Thailand", "UAE", "UK", "US", "Yemen", "Zimbabwe", "Other"};
        modelMap.addAttribute("countries", countries);


        String[] courses = {"", "BDS", "B.Sc.(MLT)", "B.Sc.(Nursing)", "DM/M.Ch (Super Speciality)", "MBBS", "MD/MS (Med)", "MDS", "M.Sc. (Medical)", "M.Sc. (Nursing)", "PhD"};
        modelMap.addAttribute("courses", courses);

        String[] designations ={"","Professor&HOD","Professor","Associate Professor","Asst. Professor","Tutor","Sr.Resident","Jr.Resident","Lab Incharge","Lab Assistant","Lab Technician","","Adminstrative Officer","Superintendent","Sr.Assistant","Jr.Assistant","Record Assistant","Computer Operator"};
        modelMap.addAttribute("designations", designations);

        String[] department ={"","Head of the Institute","Anatomy","Physiology","Biochemistry","Pharmacology","Microbiology","Pathology","Forensic Medicine","Community Medicine","General Medicine","Pulmonary Medicine","D.V.L.","Psychiatry ","Paediatrics","General Surgery","E.N.T.","Opthalmology","Orthopaedics","Anaesthesiology","Radio-Diagnosis","Obstetrics and Gynaecology"};
        modelMap.addAttribute("department", department);


        List<String> leave = new ArrayList();
        leave.add("");
        leave.add("CL");
        leave.add("SL");
        leave.add("EL");
        leave.add("CCL");
        leave.add("SPCL");
        leave.add("others");
        modelMap.addAttribute("leave", leave);


        List<String> fromtimevalues = new ArrayList();
        fromtimevalues.add("");
        fromtimevalues.add("9:00 AM");
        fromtimevalues.add("1:00 PM");

        modelMap.addAttribute("fromtimevalues", fromtimevalues);

        List<String> totimevalues = new ArrayList();
        totimevalues.add("");

        totimevalues.add("1:00 PM");
        totimevalues.add("6:00 PM");
        modelMap.addAttribute("totimevalues", totimevalues);


    }

    @Override
    public void setStaffDetails(Staff staff, List<Staff> staffDetails) {

        staff.setProfilePhotoFileName(staffDetails.get(0).getProfilePhotoFileName());
        staff.setUsername(staffDetails.get(0).getUsername());
        staff.setPassword(staffDetails.get(0).getPassword());
        staff.setDepartment(staffDetails.get(0).getDepartment());
        //staff.setRaUserprimkey(staffDetails.get(0).getRaUserprimkey());
        staff.setCurrentDesignation(staffDetails.get(0).getCurrentDesignation());
        staff.setJoiningDate(staffDetails.get(0).getJoiningDate());
        
        staff.setFirstname(staffDetails.get(0).getFirstname());
        staff.setLastname(staffDetails.get(0).getLastname());
        staff.setSex(staffDetails.get(0).getSex());
        staff.setDateofbirth(staffDetails.get(0).getDateofbirth());
        staff.setEmailid(staffDetails.get(0).getEmailid());
        staff.setMobile(staffDetails.get(0).getMobile());
        staff.setNationality(staffDetails.get(0).getNationality());

        staff.setResidentialaddress(staffDetails.get(0).getResidentialaddress());
        staff.setResidentialcity(staffDetails.get(0).getResidentialcity());
        staff.setResidentialcountry(staffDetails.get(0).getResidentialcountry());
        staff.setResidentialoptional1(staffDetails.get(0).getResidentialoptional1());
        staff.setResidentialoptional2(staffDetails.get(0).getResidentialoptional2());
        staff.setResidentialphone(staffDetails.get(0).getResidentialphone());
        staff.setResidentialpin(staffDetails.get(0).getResidentialpin());
        staff.setResidentialstate1(staffDetails.get(0).getResidentialstate1());

        staff.setPermanentaddress(staffDetails.get(0).getPermanentaddress());
        staff.setPermanentcity(staffDetails.get(0).getPermanentcity());
        staff.setPermanentcountry(staffDetails.get(0).getPermanentcountry());
        staff.setPermanentoptional1(staffDetails.get(0).getPermanentoptional1());
        staff.setPermanentoptional2(staffDetails.get(0).getPermanentoptional2());
        staff.setPermanentphone(staffDetails.get(0).getPermanentphone());
        staff.setPermanentpin(staffDetails.get(0).getPermanentpin());
        staff.setPermanentstate1(staffDetails.get(0).getPermanentstate1());

        staff.setCoursename(staffDetails.get(0).getCoursename());
        staff.setSpecialization(staffDetails.get(0).getSpecialization());
        staff.setInstitute1(staffDetails.get(0).getInstitute1());
        staff.setUniversity(staffDetails.get(0).getUniversity());
        staff.setAcademicYear1(staffDetails.get(0).getAcademicYear1());

        staff.setCoursename2(staffDetails.get(0).getCoursename2());
        staff.setSpecialization2(staffDetails.get(0).getSpecialization2());
        staff.setInstitute2(staffDetails.get(0).getInstitute2());
        staff.setUniversity2(staffDetails.get(0).getUniversity2());
        staff.setAcademicYear2(staffDetails.get(0).getAcademicYear2());

        staff.setCoursename3(staffDetails.get(0).getCoursename3());
        staff.setSpecialization3(staffDetails.get(0).getSpecialization3());
        staff.setInstitute3(staffDetails.get(0).getInstitute3());
        staff.setUniversity3(staffDetails.get(0).getUniversity3());
        staff.setAcademicYear3(staffDetails.get(0).getAcademicYear3());

        staff.setPreviousempolyer(staffDetails.get(0).getPreviousempolyer());
        staff.setDuration1(staffDetails.get(0).getDuration1());
        staff.setDesignation(staffDetails.get(0).getDesignation());
        staff.setOrganization(staffDetails.get(0).getOrganization());

        staff.setPreviousempolyer2(staffDetails.get(0).getPreviousempolyer2());
        staff.setDuration2(staffDetails.get(0).getDuration2());
        staff.setDesignation2(staffDetails.get(0).getDesignation2());
        staff.setOrganization2(staffDetails.get(0).getOrganization2());

    }

    @Override
    public void retrieveStaff(Staff staff) {

        List<Staff> staffDetails = null;

        if (staff.getId() > 0) {
            staffDetails = (List<Staff>) hibernateTemplate.find("from Staff where ID= ? ", staff.getId());
        } else if (staff.getUsername() != null && staff.getPassword() != null) {
            Object row[] = new Object[2];
            row[0] = (Object) staff.getUsername();
            row[1] = (Object) staff.getPassword();
            staffDetails = (List<Staff>) hibernateTemplate.find("from Staff where UserName= ? AND Password=?", row);
        }


        if (staffDetails.size() > 0) {
            setStaffDetails(staff, staffDetails);
        } else {
            System.out.println("Please contact System Admin");
        }
    }


    @Override
    @SuppressWarnings("unchecked")
    public List<Staff> findStaffByUserprimkey(long userprimkey) {
        return hibernateTemplate.find("from Staff where Userprimkey = ? ", userprimkey);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Staff> findStaffByID(int id) {
        return hibernateTemplate.find("from Staff where ID = ? ", id);
    }
    
    @Override
    public boolean staffLoginCheck(Staff staff) {

        List<Staff> staffDetails;
        //List<Marks> studentDetails;
        Object row[] = new Object[2];
        row[0] = (Object) staff.getUsername();
        row[1] = (Object) staff.getPassword();
        staffDetails = (List<Staff>) hibernateTemplate.find("from Staff where UserName = ? AND Password = ? ", row);

        if (staffDetails.size() != 0) {            
            return true;
        } else {
            return false;
        }
    }

    @Override
    public void saveStaff(Staff staff) {
        System.out.println("Hello--->");
        hibernateTemplate.saveOrUpdate(staff);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Staff> listStaff(Staff staff) {
        return hibernateTemplate.find("from Staff where UserName = ? ", staff.getUsername());
    }

    @Override
    public void updateStaff(Staff staff) {
        System.out.println("Hello--->");
        hibernateTemplate.update(staff);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Staff> searchStaff(Staff staff1) {

        Object row[] = new Object[2];
        row[0] = (Object) ('%' + staff1.getFirstname() + '%');
        row[1] = (Object) ('%' + staff1.getLastname() + '%');

        return hibernateTemplate.find("from Staff where FirstName like ? AND LastName like ? ", row);
    }

    @Override
    public void saveLeaveApplication(LeaveApplication leaveApplication) {
        System.out.println("Hello--->");
        hibernateTemplate.saveOrUpdate(leaveApplication);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<LeaveSummary> findleaveSummaryByUserprimkey(long userprimkey) {
        return hibernateTemplate.find("from LeaveSummary where Userprimkey = ?",userprimkey );

    }

    public void saveLeaveSummary(LeaveSummary leaveSummary) {
        hibernateTemplate.saveOrUpdate(leaveSummary);
    }


    @Override
    @SuppressWarnings("unchecked")
    public List<LeaveApplication> findLeaveApplicationByUserprimkey(long userprimkey) {
        return hibernateTemplate.find("from LeaveApplication where Userprimkey = ?",userprimkey);
    }


    @Override
    @SuppressWarnings("unchecked")
    public List<LeaveApplication> findLeaveApplicationById(int id) {
        return hibernateTemplate.find("from LeaveApplication where ID = ?",id);
    }


    @Override
    @SuppressWarnings("unchecked")
    public List<LeaveApplication> findLeaveApplicationForUpdate(long userprimkey) {
        Object row[] = new Object[3];
        row[0] = (Object) userprimkey;
        row[1] = (Object) ("In Process");
        row[2] = (Object) ("Accepted");

        return hibernateTemplate.find("from LeaveApplication where Userprimkey = ? AND (status = ? OR status = ?)",row);
    }


    @Override
    @SuppressWarnings("unchecked")
    public List<LeaveApplication> findLeaveApplicationByRAUserprimkey(long  raUserprimkey) {
        Object row[] = new Object[4];
        row[0] = (Object) raUserprimkey;
        row[1] = (Object) ("In Process");
        row[2] = (Object) ("Accepted");
        row[3] = (Object) ("Rejected");

        return hibernateTemplate.find("from LeaveApplication where RAUserprimkey = ? AND (status = ? OR status = ? OR status = ?)",row);
    }



    @Override
    @SuppressWarnings("unchecked")
    public List<LeaveApplication> LMSearchLeaves(LeaveApplication leaveApplication1) {


         if(!leaveApplication1.getTypeOfLeave().toString().equals("") && leaveApplication1.getUserprimkey()!=0)
         {
           Object row[] = new Object[2];
           row[0]=(Object)(leaveApplication1.getTypeOfLeave());
           row[1]=(Object)(leaveApplication1.getUserprimkey());
           return hibernateTemplate.find("from LeaveApplication where typeOfLeave = ? AND Userprimkey = ?",row);
         }
         else if(!leaveApplication1.getAppliedDate().toString().equals("//") && leaveApplication1.getTypeOfLeave().toString().equals(""))
         {
                     Object row[] = new Object[2];

         row[0]=(Object)(leaveApplication1.getAppliedDate());
         row[1]=(Object)(leaveApplication1.getUserprimkey());


             return hibernateTemplate.find("from LeaveApplication where APPLIEDDATE = ? AND Userprimkey = ?",row);
         }else if(!leaveApplication1.getAppliedDate().toString().equals("//") && !leaveApplication1.getTypeOfLeave().toString().equals("")&&leaveApplication1.getUserprimkey()!=0)
         {
                     Object row[] = new Object[3];
                     row[0]=(Object)(leaveApplication1.getTypeOfLeave());
                     row[1]=(Object)(leaveApplication1.getAppliedDate());
                     row[2]=(Object)(leaveApplication1.getUserprimkey());

             return hibernateTemplate.find("from LeaveApplication where TYPEOFLEAVE = ? AND APPLIEDDATE = ? AND Userprimkey = ?",row);
         }
         else
         {
             return hibernateTemplate.find("from LeaveApplication where Userprimkey = ?",leaveApplication1.getUserprimkey());
         }
    }


    @Override
    public void deleteLeaveApplication(LeaveApplication leaveApplication) {
        System.out.println("Hello--->");
        hibernateTemplate.delete(leaveApplication);
    }




}

