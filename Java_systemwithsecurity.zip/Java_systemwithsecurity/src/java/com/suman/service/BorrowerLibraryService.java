package com.suman.service;

import java.util.List;
import org.springframework.ui.ModelMap;
import java.util.Calendar;

import com.suman.domain.Catalogue;
import com.suman.domain.Checkinandoutlog;
import com.suman.domain.LibraryRuleSet;

public interface BorrowerLibraryService {

    public void formAddOptionvalues(ModelMap modelMap);

    public List<Catalogue> searchCatalogue(Catalogue catalogue1);

    public List<Checkinandoutlog> searchCheckinandoutlog(long userprimkey);

    public List<Catalogue> findCatalogueByRecordIdentifier(String recordIdentifier);

    public List<Checkinandoutlog> findCheckinandoutlogByRecordIdentifier(String recordIdentifier);

    public List<Checkinandoutlog> findCheckinandoutlogById(int id);

    public void saveCheckinandoutlog(Checkinandoutlog checkinandoutlog);

    public List<Catalogue> findCatalogueByID(int id);

    public List<Checkinandoutlog> findReservedItemsByRI(String recordIdentifier);

    public List<Checkinandoutlog> NoOfReservedItemsOfCurrentUser(long userprimkey);

    public String DateConversion(Calendar c);

    public List<LibraryRuleSet> LibraryRuleSetResults();
}
