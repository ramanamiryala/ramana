package com.suman.service;
import java.util.List;
import org.springframework.ui.ModelMap;

import com.suman.domain.Catalogue;
import com.suman.domain.Checkinandoutlog;

public interface BorrowerLibraryService {

    public void formAddOptionvalues(ModelMap modelMap);
    
    public List<Catalogue> searchCatalogue(Catalogue catalogue1);

    public List<Checkinandoutlog> searchCheckinandoutlog(String borrowerUsername);

     public List<Catalogue> findCatalogueByRecordIdentifier(String recordIdentifier);



}
