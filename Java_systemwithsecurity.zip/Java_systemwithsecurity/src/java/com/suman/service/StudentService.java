package com.suman.service;

import com.suman.domain.Student;
import com.suman.domain.Marks;
import com.suman.domain.Attendence;
import com.suman.domain.Library;


import java.util.List;

public interface StudentService {
    public void retrieveStudent(Student student);
    public void saveStudent(Student student);
    public boolean studentLoginCheck(Student student);
    public List<Student> listStudent(Student student);
    public List<Marks> listMarks(Student student);
    public List<Attendence> listAttendence(Student student);
    public List<Library> listLibrary(Student student);
    public List<Library> searchLibrary(Library library1);
    //public boolean studentRegLoginCheck(Student student);
    public void updateStudent(Student student);
     public List<Student> searchStudent(Student student1);
     public void setStudentDetails(Student student, List<Student> studentDetails);
     

    

}
