package com.suman.service;

import com.suman.domain.Staff;
import com.suman.domain.LeaveApplication;
import com.suman.domain.LeaveSummary;
import java.util.List;
import org.springframework.ui.ModelMap;

public interface StaffService {

    public boolean staffLoginCheck(Staff staff);

    public void saveStaff(Staff staff);

    public List<Staff> listStaff(Staff staff);

    public void updateStaff(Staff staff);

    public List<Staff> searchStaff(Staff staff1);

    public void retrieveStaff(Staff staff);

    public void setStaffDetails(Staff staff, List<Staff> staffDetails);

    public void formAddOptionvalues(ModelMap modelMap);

   // public List<Staff> findStaffByUserid(String username);

    public void saveLeaveApplication(LeaveApplication leaveApplication);

    public List<LeaveSummary> findleaveSummaryByUserprimkey(long userprimkey);

    public void saveLeaveSummary(LeaveSummary leaveSummary);

    public List<LeaveApplication> findLeaveApplicationByUserprimkey(long userprimkey);

    public List<LeaveApplication> findLeaveApplicationById(int id);

    public List<LeaveApplication> findLeaveApplicationForUpdate(long userprimkey);

    public List<LeaveApplication> findLeaveApplicationByRAUserprimkey(long raUserprimkey);

    public List<LeaveApplication> LMSearchLeaves(LeaveApplication leaveApplication1);

    public void deleteLeaveApplication(LeaveApplication leaveApplication);
     public List<Staff> findStaffByID(int id);
     public List<Staff> findStaffByUserprimkey(long userprimkey);



}
