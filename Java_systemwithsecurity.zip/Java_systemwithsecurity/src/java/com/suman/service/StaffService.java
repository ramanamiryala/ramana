package com.suman.service;

import com.suman.domain.Staff;
import com.suman.domain.LeaveApplication;
import com.suman.domain.LeaveSummary;
import java.util.List;
import org.springframework.ui.ModelMap;

public interface StaffService {

    public boolean staffLoginCheck(Staff staff);

    public void saveStaff(Staff staff);

    public List<Staff> listStaff(Staff staff);

    public void updateStaff(Staff staff);

    public List<Staff> searchStaff(Staff staff1);

    public void retrieveStaff(Staff staff);

    public void setStaffDetails(Staff staff, List<Staff> staffDetails);

    public void formAddOptionvalues(ModelMap modelMap);

    public List<Staff> findStaffByUserid(String userid);

    public void saveLeaveApplication(LeaveApplication leaveApplication);

    public List<LeaveSummary> findleaveSummaryByUsername(String username);

    public void saveLeaveSummary(LeaveSummary leaveSummary);

    public List<LeaveApplication> findLeaveApplicationByUsername(String username);

    public List<LeaveApplication> findLeaveApplicationById(int id);

    public List<LeaveApplication> findLeaveApplicationForUpdate(String username);

    public List<LeaveApplication> findLeaveApplicationByRAusername(String username);


}
