package com.suman.service;

import java.util.List;
import java.util.ArrayList;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;
import com.suman.biometric.AtdRecord;
import com.suman.biometric.AtdRecordId;
import com.suman.biometric.HrEmployee;


import org.springframework.ui.ModelMap;
import javax.servlet.http.HttpServletRequest;
import java.util.regex.Pattern;

public class AttendenceServiceImp implements AttendenceService {

    private HibernateTemplate hibernateTemplate;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.hibernateTemplate = new HibernateTemplate(sessionFactory);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<AtdRecord> findAttendence(String dateofAttendence) {
        return hibernateTemplate.find("from AtdRecord where RecDate = ?", dateofAttendence);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<HrEmployee> findEmployeesList() {
        return hibernateTemplate.find("from HrEmployee");
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<HrEmployee> searchEmployeesList(HrEmployee employee) {


        Object row[] = new Object[4];

        row[0] = (Object) ('%' + employee.getCardId() + '%');
        row[1] = (Object) ('%' + employee.getDeptId() + '%');
        row[2] = (Object) ('%' + employee.getEmplName() + '%');
        row[3] = (Object) ('%' + employee.getIdentityId() + '%');

        return hibernateTemplate.find("from HrEmployee where CardId like ? AND DeptId like ? AND EmplName like ? AND IdentityId like ?", row);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<HrEmployee> findEmployeeByEmplId(String EmplId) {

        return hibernateTemplate.find("from HrEmployee where EmplId = ?", EmplId);
    }

    @Override
    @SuppressWarnings("unchecked")
    public void updateEmployee(HrEmployee employee) {

        HrEmployee OldEmpDetails = findEmployeeByEmplId(employee.getEmplId()).get(0);

        OldEmpDetails.setCardId(employee.getCardId());
        OldEmpDetails.setIdentityId(employee.getIdentityId());
        OldEmpDetails.setDeptId(employee.getDeptId());
        OldEmpDetails.setEmplName(employee.getEmplName());

        hibernateTemplate.update(OldEmpDetails);

    }
    



}

