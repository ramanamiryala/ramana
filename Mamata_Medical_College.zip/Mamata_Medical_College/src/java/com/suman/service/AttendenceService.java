package com.suman.service;

import javax.servlet.http.HttpServletRequest;
import com.suman.domain.Student;
import org.springframework.ui.ModelMap;
import com.suman.biometric.AtdRecord;
import com.suman.biometric.AtdRecordId;
import com.suman.biometric.HrEmployee;

import java.util.List;

public interface AttendenceService {

    public List<AtdRecord> findAttendence(String dateofAttendence);
    public List<HrEmployee> findEmployeesList();
    public List<HrEmployee> searchEmployeesList(HrEmployee employee);
    public List<HrEmployee> findEmployeeByEmplId(String EmplId);
    public void updateEmployee(HrEmployee employee);


}
