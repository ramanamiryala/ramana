package com.suman.service;

import java.util.List;
import java.util.ArrayList;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.suman.domain.Student;
import com.suman.domain.StdBaseProfile;

import org.springframework.ui.ModelMap;
import javax.servlet.http.HttpServletRequest;
import java.util.regex.Pattern;

public class StudentServiceImp implements StudentService {

    private HibernateTemplate hibernateTemplate;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.hibernateTemplate = new HibernateTemplate(sessionFactory);
    }

    @Override
    public void formAddOptionvalues(ModelMap modelMap) {
        List<String> yesno = new ArrayList();
        yesno.add("YES");
        yesno.add("NO");
        modelMap.addAttribute("yesno", yesno);


        List<String> yesnoempty = new ArrayList();
        yesnoempty.add("");
        yesnoempty.add("YES");
        yesnoempty.add("NO");
        modelMap.addAttribute("yesnoempty", yesnoempty);

        List<String> courseYears = new ArrayList();

        courseYears.add("");        
        courseYears.add("I MBBS");
        courseYears.add("II MBBS");
        courseYears.add("Final MBBS Part-I");
        courseYears.add("Final MBBS Part-II");
        courseYears.add("Internship");
        courseYears.add("I Year");
        courseYears.add("II Year");
        courseYears.add("III Year");
        courseYears.add("IV Year");
        courseYears.add("V Year");

        modelMap.addAttribute("courseYears", courseYears);

        List<String> sex = new ArrayList();
        sex.add("");
        sex.add("FEMALE");
        sex.add("MALE");
        modelMap.addAttribute("sex", sex);

        List<String> religion = new ArrayList();
        religion.add("");
        religion.add("Hindu");
        religion.add("Muslim");
        religion.add("Christian");
        religion.add("Others");
        modelMap.addAttribute("religion", religion);

        int i;
        List<Object> day = new ArrayList();

        for (i = 0; i < 32; i++) {
            if (i == 0) {
                day.add((Object) (""));
            } else {
                day.add((Object) i);
            }
        }

        modelMap.addAttribute("day", day);

        List<Object> month = new ArrayList();
        for (i = 0; i < 13; i++) {
            if (i == 0) {
                month.add((Object) (""));
            } else {
                month.add((Object) i);
            }
        }

        modelMap.addAttribute("month", month);

        String[] months = {"", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};
        modelMap.addAttribute("months", months);

        List<Object> year = new ArrayList();
        for (i = 1899; i < 2051; i++) {
            if (i == 1899) {
                year.add((Object) (""));
            } else {
                year.add((Object) i);
            }
        }

        modelMap.addAttribute("year", year);

        String[] states = {"", "Andaman and Nicobar Islands", "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chandigarh", "Chhattisgarh", "Dadra and Nagar Haveli", "Daman and Diu", "Delhi", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jammu and Kashmir", "Jharkhand", "Karnataka", "Kerala", "Lakshadweep", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Orissa", "Puducherry", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal", "Other"};
        modelMap.addAttribute("states", states);


        String[] countries = {"", "Australia", "Bahrain", "Bangladesh", "Belgium", "Canada", "Doha", "Dubai", "France", "Germany", "Hong Kong", "INDIA", "Indonesia", "Ireland", "Italy", "Japan", "Kenya", "Kuwait", "Lebanon", "Libya", "Malaysia", "Maldives", "Mauritius", "Mexico", "Nepal", "Netherlands", "New Zealand", "Norway", "Oman", "Pakistan", "Qatar", "Quilon", "Russia", "Saudi Arabia", "Singapore", "South Africa", "South Korea", "Spain", "Sri Lanka", "Sweden", "Switzerland", "Thailand", "UAE", "UK", "US", "Yemen", "Zimbabwe", "Other"};
        modelMap.addAttribute("countries", countries);


        String[] courses = {"", "BDS", "B.Sc.(MLT)", "B.Sc.(Nursing)", "DM/M.Ch (Super Speciality)", "MBBS", "MD/MS (Med)", "MDS", "M.Sc. (Medical)", "M.Sc. (Nursing)", "PhD"};
        modelMap.addAttribute("courses", courses);

    }


    @Override
    @SuppressWarnings("unchecked")
    public List<StdBaseProfile> searchStdBaseProfile(StdBaseProfile stdBaseProfile) {

        Object row[] = new Object[3];
        row[0] = (Object) ('%' + stdBaseProfile.getFirstName() + '%');
        row[1] = (Object) ('%' + stdBaseProfile.getLastName() + '%');
        row[2] = (Object) ('%' + stdBaseProfile.getSex() + '%');

        return hibernateTemplate.find("from StdBaseProfile where FirstName like ? AND LastName like ? AND Sex like ? ", row);
    }

        @Override
    public List<StdBaseProfile>  findStdBaseProfileByPrimaryKey(Long primkeyid){

        return hibernateTemplate.find("from StdBaseProfile where id = ? ", primkeyid);
    }

    
    @Override
    public List<Student>  findStudentByPrimaryKey(Long primkeyid){

        List<Student> studentDetails;
        studentDetails = (List<Student>) hibernateTemplate.find("from Student where id = ? ", primkeyid);

        return studentDetails;

    }


    @Override
    public void retrieveStudent(Student student) {

        List<Student> studentDetails;
        if (student.getUsername() != null) {
            studentDetails = (List<Student>) hibernateTemplate.find("from Student where username = ? ", student.getUsername());
            if (studentDetails.size() != 0) {

                student.setFirstName(studentDetails.get(0).getFirstName());
                student.setLastName(studentDetails.get(0).getLastName());
                student.setSex(studentDetails.get(0).getSex());
                student.setParentsName(studentDetails.get(0).getParentsName());
                student.setCourseJoined(studentDetails.get(0).getCourseJoined());
                student.setDateofBirth(studentDetails.get(0).getDateofBirth());
                student.setMotherTounge(studentDetails.get(0).getMotherTounge());
                student.setNationality(studentDetails.get(0).getNationality());
                student.setReligion(studentDetails.get(0).getReligion());
                student.setMobileNumber(studentDetails.get(0).getMobileNumber());
                student.setEmailId(studentDetails.get(0).getEmailId());
                student.setProfilePhotoFileName(studentDetails.get(0).getProfilePhotoFileName());

            } else {
                System.out.println("This student is not added in the Stduent Database");
            }


        } else {
            System.out.println("No Student Details given ");
            return;
        }


    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Student> searchStudent(Student student1) {

        Object row[] = new Object[3];
        row[0] = (Object) ('%' + student1.getFirstName() + '%');
        row[1] = (Object) ('%' + student1.getLastName() + '%');
        row[2] = (Object) ('%' + student1.getSex() + '%');

        return hibernateTemplate.find("from Student where FirstName like ? AND LastName like ? AND Sex like ? ", row);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Student> findStudentByUsername(String username) {
        return hibernateTemplate.find("from Student where username = ? ", username);
    }

    @Override
    public boolean studentLoginCheck(Student student) {

        List<Student> studentDetails;
        studentDetails = (List<Student>) hibernateTemplate.find("from Student where username = ? ", student.getUsername());

        if (studentDetails.size() != 0) {

            student = studentDetails.get(0);

            return true;
        } else {
            return false;
        }
    }

    @Override
    public void updateStudent(Student student) {
        System.out.println("Hello--->");
        //By R.no: we r getting the student Detials -->
        //List<Student> dbStdDetails=hibernateTemplate.find("from Student where st_Rno = ?", student.getRno());
        //student.setId(dbStdDetails.get(0).getId());
        //as We r getting Student data by Id so we dont require above

        hibernateTemplate.update(student);
    }

    @Override
    public void saveStudent(Student student) {
        System.out.println("Hello--->");
        hibernateTemplate.save(student);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Student> listStudent(Student student) {
        return hibernateTemplate.find("from Student where collegeRegistrationNumber = ? ", student.getCollegeRegistrationNumber());
    }


    @Override
    @SuppressWarnings("unchecked")
    public List<StdBaseProfile> listStdBaseProfileByRegistraionNo(String registrationNumber) {
        return hibernateTemplate.find("from StdBaseProfile where collegeRegistrationNumber = ? ", registrationNumber);
    }

    @Override
    @SuppressWarnings("unchecked")
   public void saveStdBaseProfile(StdBaseProfile stdBaseProfile)
    {
        hibernateTemplate.save(stdBaseProfile);
    }

        @Override
    @SuppressWarnings("unchecked")
   public void  updateStdBaseProfile(StdBaseProfile stdBaseProfile)
    {
        hibernateTemplate.update(stdBaseProfile);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<StdBaseProfile> findStdBaseProfileByUsername(String username) {
        return hibernateTemplate.find("from StdBaseProfile where username = ? ", username);
    }

        @Override
    @SuppressWarnings("unchecked")
        public List<StdBaseProfile> stdBaseProfileCheck(String userattribute, String userattributename, Long stdBaseProfileId) {

        Object row[] = new Object[2];
        row[0] = (Object) (userattribute);
        row[1] = (Object) (stdBaseProfileId);

            return (List<StdBaseProfile>) hibernateTemplate.find("from StdBaseProfile where "+ userattributename + " = ?  AND id <> ?", row);

    }

    




    @Override
    @SuppressWarnings("unchecked")
    public void specialStdBaseProfileAtrributesMapping(ModelMap modelMap, HttpServletRequest request, StdBaseProfile stdBaseProfile) {

        if (stdBaseProfile.getJoiningAcademicYear() != null) {
            if (AcademicYearCheck(stdBaseProfile.getJoiningAcademicYear())) {
                modelMap.addAttribute("currentyear", stdBaseProfile.getJoiningAcademicYear().split("-")[0].toString());
                modelMap.addAttribute("nextyear", stdBaseProfile.getJoiningAcademicYear().split("-")[1].toString());
            } else {
                modelMap.addAttribute("currentyear", request.getParameter("fromYearAcademicYear"));
                modelMap.addAttribute("nextyear", request.getParameter("toYearAcademicYear"));
            }
        }

    }
    @Override
    @SuppressWarnings("unchecked")
    public void specialStudentAtrributesMapping(ModelMap modelMap, HttpServletRequest request, Student student) {



        if (student.getAdmissionDate() != null) {
            if (DateCheck(student.getAdmissionDate())) // means its already checked & put in session
            {
                modelMap.addAttribute("valadmday", student.getAdmissionDate().split("/")[0].toString());
                modelMap.addAttribute("valadmmonth", student.getAdmissionDate().split("/")[1].toString());
                modelMap.addAttribute("valadmyear", student.getAdmissionDate().split("/")[2].toString());
            } else // means its from the current context
            {
                modelMap.addAttribute("valadmday", request.getParameter("admday"));
                modelMap.addAttribute("valadmmonth", request.getParameter("admmonth"));
                modelMap.addAttribute("valadmyear", request.getParameter("admyear"));
            }

        }

        if (student.getDateofBirth() != null) {

            if (DateCheck(student.getDateofBirth())) // means its already checked & put in session
            {
                modelMap.addAttribute("valbday", student.getDateofBirth().split("/")[0].toString());
                modelMap.addAttribute("valbmonth", student.getDateofBirth().split("/")[1].toString());
                modelMap.addAttribute("valbyear", student.getDateofBirth().split("/")[2].toString());
            } else {


                modelMap.addAttribute("valbday", request.getParameter("bday"));
                modelMap.addAttribute("valbmonth", request.getParameter("bmonth"));
                modelMap.addAttribute("valbyear", request.getParameter("byear"));
            }
        }

        if (student.getCurrentAddress() != null) {
            if (AddressCheck(student.getCurrentAddress())) {
                modelMap.addAttribute("valstc_line1", student.getCurrentAddress().split(";")[0].toString());
                modelMap.addAttribute("valstc_line2", student.getCurrentAddress().split(";")[1].toString());
                modelMap.addAttribute("valstc_line3", student.getCurrentAddress().split(";")[2].toString());
            } else {


                modelMap.addAttribute("valstc_line1", request.getParameter("stc_line1"));
                modelMap.addAttribute("valstc_line2", request.getParameter("stc_line2"));
                modelMap.addAttribute("valstc_line3", request.getParameter("stc_line3"));
            }
        }

        if (student.getPermanentAddress() != null) {
            if (AddressCheck(student.getPermanentAddress())) {
                modelMap.addAttribute("valstp_line1", student.getPermanentAddress().split(";")[0].toString());
                modelMap.addAttribute("valstp_line2", student.getPermanentAddress().split(";")[1].toString());
                modelMap.addAttribute("valstp_line3", student.getPermanentAddress().split(";")[2].toString());
            } else {
                modelMap.addAttribute("valstp_line1", request.getParameter("stp_line1"));
                modelMap.addAttribute("valstp_line2", request.getParameter("stp_line2"));
                modelMap.addAttribute("valstp_line3", request.getParameter("stp_line3"));
            }
        }



        if (student.getParentsCorrespondenceAddress() != null) {
            if (AddressCheck(student.getParentsCorrespondenceAddress())) {
                modelMap.addAttribute("valpc_line1", student.getParentsCorrespondenceAddress().split(";")[0].toString());
                modelMap.addAttribute("valpc_line2", student.getParentsCorrespondenceAddress().split(";")[1].toString());
                modelMap.addAttribute("valpc_line3", student.getParentsCorrespondenceAddress().split(";")[2].toString());
            } else {
                modelMap.addAttribute("valpc_line1", request.getParameter("pc_line1"));
                modelMap.addAttribute("valpc_line2", request.getParameter("pc_line2"));
                modelMap.addAttribute("valpc_line3", request.getParameter("pc_line3"));
            }
        }


        if (student.getAcedamicYearStudiedQE() != null) {
            if (AcademicYearCheck(student.getAcedamicYearStudiedQE())) {
                modelMap.addAttribute("valqefromyear", student.getAcedamicYearStudiedQE().split("-")[0].toString());
                modelMap.addAttribute("valqetoyear", student.getAcedamicYearStudiedQE().split("-")[1].toString());
            } else {
                modelMap.addAttribute("valqefromyear", request.getParameter("qefromyear"));
                modelMap.addAttribute("valqetoyear", request.getParameter("qetoyear"));
            }
        }

        if (student.getClassVIAcademicYear() != null) {
            if (AcademicYearCheck(student.getClassVIAcademicYear())) {
                modelMap.addAttribute("valVIfromyear", student.getClassVIAcademicYear().split("-")[0].toString());
                modelMap.addAttribute("valVItoyear", student.getClassVIAcademicYear().split("-")[1].toString());
            } else {
                modelMap.addAttribute("valVIfromyear", request.getParameter("VIfromyear"));
                modelMap.addAttribute("valVItoyear", request.getParameter("VItoyear"));
            }
        }

        if (student.getClassVIIAcademicYear() != null) {
            if (AcademicYearCheck(student.getClassVIIAcademicYear())) {
                modelMap.addAttribute("valVIIfromyear", student.getClassVIIAcademicYear().split("-")[0].toString());
                modelMap.addAttribute("valVIItoyear", student.getClassVIIAcademicYear().split("-")[1].toString());
            } else {
                modelMap.addAttribute("valVIIfromyear", request.getParameter("VIIfromyear"));
                modelMap.addAttribute("valVIItoyear", request.getParameter("VIItoyear"));
            }
        }

        if (student.getClassVIIIAcademicYear() != null) {
            if (AcademicYearCheck(student.getClassVIIIAcademicYear())) {
                modelMap.addAttribute("valVIIIfromyear", student.getClassVIIIAcademicYear().split("-")[0].toString());
                modelMap.addAttribute("valVIIItoyear", student.getClassVIIIAcademicYear().split("-")[1].toString());
            } else {
                modelMap.addAttribute("valVIIIfromyear", request.getParameter("VIIIfromyear"));
                modelMap.addAttribute("valVIIItoyear", request.getParameter("VIIItoyear"));
            }
        }
        if (student.getClassIXAcademicYear() != null) {
            if (AcademicYearCheck(student.getClassIXAcademicYear())) {
                modelMap.addAttribute("valIXfromyear", student.getClassIXAcademicYear().split("-")[0].toString());
                modelMap.addAttribute("valIXtoyear", student.getClassIXAcademicYear().split("-")[1].toString());
            } else {
                modelMap.addAttribute("valIXfromyear", request.getParameter("IXfromyear"));
                modelMap.addAttribute("valIXtoyear", request.getParameter("IXtoyear"));
            }
        }

        if (student.getClassXAcademicYear() != null) {
            if (AcademicYearCheck(student.getClassXAcademicYear())) {
                modelMap.addAttribute("valXfromyear", student.getClassXAcademicYear().split("-")[0].toString());
                modelMap.addAttribute("valXtoyear", student.getClassXAcademicYear().split("-")[1].toString());
            } else {
                modelMap.addAttribute("valXfromyear", request.getParameter("Xfromyear"));
                modelMap.addAttribute("valXtoyear", request.getParameter("Xtoyear"));
            }
        }



        if (student.getClassXIAcademicYear() != null) {
            if (AcademicYearCheck(student.getClassXIAcademicYear())) {
                modelMap.addAttribute("valXIfromyear", student.getClassXIAcademicYear().split("-")[0].toString());
                modelMap.addAttribute("valXItoyear", student.getClassXIAcademicYear().split("-")[1].toString());
            } else {
                modelMap.addAttribute("valXIfromyear", request.getParameter("XIfromyear"));
                modelMap.addAttribute("valXItoyear", request.getParameter("XItoyear"));
            }
        }
        if (student.getClassXIIAcademicYear() != null) {
            if (AcademicYearCheck(student.getClassXIIAcademicYear())) {
                modelMap.addAttribute("valXIIfromyear", student.getClassXIIAcademicYear().split("-")[0].toString());
                modelMap.addAttribute("valXIItoyear", student.getClassXIIAcademicYear().split("-")[1].toString());
            } else {
                modelMap.addAttribute("valXIIfromyear", request.getParameter("XIIfromyear"));
                modelMap.addAttribute("valXIItoyear", request.getParameter("XIItoyear"));
            }
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public void backSpecialStudentAtrributesMapping(ModelMap modelMap, Student student) {


        if (student.getAdmissionDate() != null) {
            modelMap.addAttribute("valadmday", student.getAdmissionDate().split("/")[0].toString());
            modelMap.addAttribute("valadmmonth", student.getAdmissionDate().split("/")[1].toString());
            modelMap.addAttribute("valadmyear", student.getAdmissionDate().split("/")[2].toString());
        }


        if (student.getDateofBirth() != null) {
            modelMap.addAttribute("valbday", student.getDateofBirth().split("/")[0].toString());
            modelMap.addAttribute("valbmonth", student.getDateofBirth().split("/")[1].toString());
            modelMap.addAttribute("valbyear", student.getDateofBirth().split("/")[2].toString());
        }
        if (student.getCurrentAddress() != null) {
            modelMap.addAttribute("valstc_line1", student.getCurrentAddress().split(",")[0].toString());
            modelMap.addAttribute("valstc_line2", student.getCurrentAddress().split(",")[1].toString());
            modelMap.addAttribute("valstc_line3", student.getCurrentAddress().split(",")[2].toString());
        }

        if (student.getPermanentAddress() != null) {
            modelMap.addAttribute("valstp_line1", student.getPermanentAddress().split(",")[0].toString());
            modelMap.addAttribute("valstp_line2", student.getPermanentAddress().split(",")[1].toString());
            modelMap.addAttribute("valstp_line3", student.getPermanentAddress().split(",")[2].toString());
        }

        if (student.getParentsCorrespondenceAddress() != null) {
            modelMap.addAttribute("valpc_line1", student.getParentsCorrespondenceAddress().split(",")[0].toString());
            modelMap.addAttribute("valpc_line2", student.getParentsCorrespondenceAddress().split(",")[1].toString());
            modelMap.addAttribute("valpc_line3", student.getParentsCorrespondenceAddress().split(",")[2].toString());
        }
        if (student.getAcedamicYearStudiedQE() != null) {
            modelMap.addAttribute("valqefromyear", student.getAcedamicYearStudiedQE().split("-")[0].toString());
            modelMap.addAttribute("valqetoyear", student.getAcedamicYearStudiedQE().split("-")[1].toString());
        }


        if (student.getClassVIAcademicYear() != null) {
            if (!student.getClassVIAcademicYear().toString().equals("-")) {
                modelMap.addAttribute("valVIfromyear", student.getClassVIAcademicYear().split("-")[0].toString());
                modelMap.addAttribute("valVItoyear", student.getClassVIAcademicYear().split("-")[1].toString());
            }
        }


        if (student.getClassVIIAcademicYear() != null) {
            modelMap.addAttribute("valVIIfromyear", student.getClassVIIAcademicYear().split("-")[0].toString());
            modelMap.addAttribute("valVIItoyear", student.getClassVIIAcademicYear().split("-")[1].toString());
        }
        if (student.getClassVIIIAcademicYear() != null) {
            modelMap.addAttribute("valVIIIfromyear", student.getClassVIIIAcademicYear().split("-")[0].toString());
            modelMap.addAttribute("valVIIItoyear", student.getClassVIIIAcademicYear().split("-")[1].toString());
        }

        if (student.getClassIXAcademicYear() != null) {
            modelMap.addAttribute("valIXfromyear", student.getClassIXAcademicYear().split("-")[0].toString());
            modelMap.addAttribute("valIXtoyear", student.getClassIXAcademicYear().split("-")[1].toString());
        }

        if (student.getClassXAcademicYear() != null) {
            modelMap.addAttribute("valXfromyear", student.getClassXAcademicYear().split("-")[0].toString());
            modelMap.addAttribute("valXtoyear", student.getClassXAcademicYear().split("-")[1].toString());
        }
        if (student.getClassXIAcademicYear() != null) {
            modelMap.addAttribute("valXIfromyear", student.getClassXIAcademicYear().split("-")[0].toString());
            modelMap.addAttribute("valXItoyear", student.getClassXIAcademicYear().split("-")[1].toString());
        }

        if (student.getClassXIIAcademicYear() != null) {
            modelMap.addAttribute("valXIIfromyear", student.getClassXIIAcademicYear().split("-")[0].toString());
            modelMap.addAttribute("valXIItoyear", student.getClassXIIAcademicYear().split("-")[1].toString());
        }



    }

    @Override
    @SuppressWarnings("unchecked")
    public void combineStudentRegPage1withOldPageObjects(Student student, Student student_session) {
        student_session.setAdmissionNo(student.getAdmissionNo());
        student_session.setAdmissionDate(student.getAdmissionDate());
        student_session.setCourseJoined(student.getCourseJoined());
        student_session.setFirstName(student.getFirstName());
        student_session.setLastName(student.getLastName());
        student_session.setSex(student.getSex());
        student_session.setDateofBirth(student.getDateofBirth());
        student_session.setMotherTounge(student.getMotherTounge());
        student_session.setNationality(student.getNationality());
        student_session.setReligion(student.getReligion());
        student_session.setMobileNumber(student.getMobileNumber());
        student_session.setEmailId(student.getEmailId());
//////student_session.setfile1 (student.getfile1 ());
    }

    @Override
    @SuppressWarnings("unchecked")
    public void combineStudentRegPage2withOldPageObjects(Student student, Student student_session) {
////        student.setAdmissionNo(student_session.getAdmissionNo());
////        student.setAdmissionDate(student_session.getAdmissionDate());
////        student.setCourseJoined(student_session.getCourseJoined());
////        student.setFirstName(student_session.getFirstName());
////        student.setLastName(student_session.getLastName());
////        student.setSex(student_session.getSex());
////        student.setDateofBirth(student_session.getDateofBirth());
////        student.setMotherTounge(student_session.getMotherTounge());
////        student.setNationality(student_session.getNationality());
////        student.setReligion(student_session.getReligion());
////        student.setMobileNumber(student_session.getMobileNumber());
////        student.setEmailId(student_session.getEmailId());
//////student.setfile1 (student1.getfile1 ());

        student_session.setCurrentAddress(student.getCurrentAddress());
        student_session.setCurrentLocation(student.getCurrentLocation());
        student_session.setCurrentDistrict(student.getCurrentDistrict());
        student_session.setCurrentState(student.getCurrentState());
        student_session.setCurrentCountry(student.getCurrentCountry());
        student_session.setCurrentPincode(student.getCurrentPincode());
        student_session.setCurrentPhoneNumber(student.getCurrentPhoneNumber());
        student_session.setPermanentAddress(student.getPermanentAddress());
        student_session.setPermanentLocation(student.getPermanentLocation());
        student_session.setPermanentDistrict(student.getPermanentDistrict());
        student_session.setPermanentState(student.getPermanentState());
        student_session.setPermanentCountry(student.getPermanentCountry());
        student_session.setPermanentPincode(student.getPermanentPincode());
        student_session.setPermanentPhoneNumber(student.getPermanentPhoneNumber());
        student_session.setParentsCorrespondenceAddress(student.getParentsCorrespondenceAddress());
        student_session.setParentsCorrespondenceLocation(student.getParentsCorrespondenceLocation());
        student_session.setParentsCorrespondenceDistrict(student.getParentsCorrespondenceDistrict());
        student_session.setParentsCorrespondenceState(student.getParentsCorrespondenceState());
        student_session.setParentsCorrespondenceCountry(student.getParentsCorrespondenceCountry());
        student_session.setParentsCorrespondencePincode(student.getParentsCorrespondencePincode());
        student_session.setParentsCorrespondencePhoneNumber(student.getParentsCorrespondencePhoneNumber());
        student_session.setParentsName(student.getParentsName());
        student_session.setParentsOccupation(student.getParentsOccupation());
        student_session.setParentsAnnualIncome(student.getParentsAnnualIncome());
        student_session.setParentsEmailid(student.getParentsEmailid());

    }

    @Override
    @SuppressWarnings("unchecked")
    public void combineStudentRegPage3withOldPageObjects(Student student, Student student_session) {
        student_session.setNameQE(student.getNameQE());
        student_session.setAcedamicYearStudiedQE(student.getAcedamicYearStudiedQE());
        student_session.setHallTicketNoQE(student.getHallTicketNoQE());
        student_session.setPassingGradeQE(student.getPassingGradeQE());
        student_session.setSubjectsQE(student.getSubjectsQE());
        student_session.setEnglishMarksObtainedQE(student.getEnglishMarksObtainedQE());
        student_session.setSanskritMarksObtainedQE(student.getSanskritMarksObtainedQE());
        student_session.setBotanyMarksObtainedQE(student.getBotanyMarksObtainedQE());
        student_session.setZoologyMarksObtainedQE(student.getZoologyMarksObtainedQE());
        student_session.setPhysicsMarksObtainedQE(student.getPhysicsMarksObtainedQE());
        student_session.setChemistryMarksObtainedQE(student.getChemistryMarksObtainedQE());
        student_session.setMaxEnglishMarksQE(student.getMaxEnglishMarksQE());
        student_session.setMaxSanskritMarksQE(student.getMaxSanskritMarksQE());
        student_session.setMaxBotanyMarksQE(student.getMaxBotanyMarksQE());
        student_session.setMaxZoologyMarksQE(student.getMaxZoologyMarksQE());
        student_session.setMaxphysicsMarksQE(student.getMaxphysicsMarksQE());
        student_session.setMaxchemistryMarksQE(student.getMaxchemistryMarksQE());
        student_session.setHallTicketEntranceExam(student.getHallTicketEntranceExam());
        student_session.setRankEntranceExam(student.getRankEntranceExam());
        student_session.setClassVIAcademicYear(student.getClassVIAcademicYear());
        student_session.setClassVISchool(student.getClassVISchool());
        student_session.setClassVIRemarks(student.getClassVIRemarks());
        student_session.setClassVIIAcademicYear(student.getClassVIIAcademicYear());
        student_session.setClassVIISchool(student.getClassVIISchool());
        student_session.setClassVIIRemarks(student.getClassVIIRemarks());
        student_session.setClassVIIIAcademicYear(student.getClassVIIIAcademicYear());
        student_session.setClassVIIISchool(student.getClassVIIISchool());
        student_session.setClassVIIIRemarks(student.getClassVIIIRemarks());
        student_session.setClassIXAcademicYear(student.getClassIXAcademicYear());
        student_session.setClassIXSchool(student.getClassIXSchool());
        student_session.setClassIXRemarks(student.getClassIXRemarks());
        student_session.setClassXAcademicYear(student.getClassXAcademicYear());
        student_session.setClassXSchool(student.getClassXSchool());
        student_session.setClassXRemarks(student.getClassXRemarks());
        student_session.setClassXIAcademicYear(student.getClassXIAcademicYear());
        student_session.setClassXICollege(student.getClassXICollege());
        student_session.setClassXIRemarks(student.getClassXIRemarks());
        student_session.setClassXIIAcademicYear(student.getClassXIIAcademicYear());
        student_session.setClassXIICollege(student.getClassXIICollege());
        student_session.setClassXIIRemarks(student.getClassXIIRemarks());
        student_session.setDobCertificate(student.getDobCertificate());
        student_session.setInterMemoCertificate(student.getInterMemoCertificate());
        student_session.setStudyCertificate(student.getStudyCertificate());
        student_session.setTransferCertificate(student.getTransferCertificate());
        student_session.setConductCertificate(student.getConductCertificate());
        student_session.setCasteCertificate(student.getCasteCertificate());
        student_session.setEamcetRankCertificate(student.getEamcetRankCertificate());
        student_session.setEamcetHallTicketCertificate(student.getEamcetHallTicketCertificate());
        student_session.setPhotosCheck(student.getPhotosCheck());
        student_session.setOtherCertificate(student.getOtherCertificate());


    }

    public boolean AcademicYearCheck(String AcademicYear) {
        String ACADEMICYEAR_PATTERN = "^(19|20)[0-9][0-9]\\-(19|20)[0-9][0-9]$";

        if (AcademicYear.equals("-")) {
            return false;
        } else if (Pattern.compile(ACADEMICYEAR_PATTERN).matcher(AcademicYear).matches()) {
            if (Integer.parseInt(AcademicYear.split("-")[0].toString()) >= Integer.parseInt(AcademicYear.split("-")[1].toString())) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    public boolean DateCheck(String date) {
        String DATE_PATTERN = "^([1-9]|[12][0-9]|3[01])[- /.]([1-9]|1[012])[- /.](19|20)[0-9][0-9]$";
        if (date.equals("//")) {

            return false;
        } else if (!Pattern.compile(DATE_PATTERN).matcher(date).matches()) {

            return false;
        } else {
            return true;
        }
    }

    public boolean AddressCheck(String address) {
        String ADDRESS_PATTERN = "^[A-Za-z0-9 ]+;[A-Za-z0-9 ]+;[A-Za-z0-9 ]+$";
        if (address.equals(";;")) {
            return false;
        } else if (Pattern.compile(ADDRESS_PATTERN).matcher(address).matches()) {

            return true;
        } else {
            return false;
        }
    }
}

