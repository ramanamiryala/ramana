package com.suman.service;

import javax.servlet.http.HttpServletRequest;
import com.suman.domain.Student;
import org.springframework.ui.ModelMap;

import java.util.List;

public interface StudentService {

    public List<Student>  findStudentByPrimaryKey(Long primkeyid);
    public void retrieveStudent(Student student);
    public void saveStudent(Student student);
    public boolean studentLoginCheck(Student student);
    public List<Student> listStudent(Student student);
    //public boolean studentRegLoginCheck(Student student);
    public void updateStudent(Student student);
    public List<Student> searchStudent(Student student1);
    public void formAddOptionvalues (ModelMap modelMap);
    public List<Student> findStudentByUsername(String username);
//    public void specialStudentAtrributesMapping(ModelMap modelMap,Student student);
//    public void specialStudentAtrributesMapping(ModelMap modelMap,HttpServletRequest request);
    public void specialStudentAtrributesMapping(ModelMap modelMap,HttpServletRequest request,Student student);
    public void backSpecialStudentAtrributesMapping(ModelMap modelMap,Student student);
    public void combineStudentRegPage1withOldPageObjects(Student student, Student student_session);
    public void combineStudentRegPage2withOldPageObjects(Student student, Student student_session);
    public void combineStudentRegPage3withOldPageObjects(Student student, Student student_session);

    public boolean AcademicYearCheck(String AcademicYear) ;
    public boolean DateCheck(String date);


}
