package com.suman.email;

import java.util.HashMap;
import java.util.Map;



import java.io.File;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.ui.velocity.VelocityEngineUtils;
import javax.mail.internet.MimeMessage;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.mail.javamail.MimeMessageHelper;

import org.springframework.ui.ModelMap;
import org.springframework.core.io.ResourceLoader;
import org.springframework.util.ClassUtils;
import org.apache.log4j.Logger;


import org.springframework.core.io.FileSystemResource; //It includes the file from the system

public class EmailSenderImpl implements EmailSender{

    private JavaMailSender mailSender;
    private VelocityEngine velocityEngine;
    private ResourceLoader ctx;
    private Logger log = Logger.getLogger(EmailSenderImpl.class);



    public void setMailSender(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void setVelocityEngine(VelocityEngine velocityEngine) {
      this.velocityEngine = velocityEngine;
   }
    public void setResourceLoader (ResourceLoader ctx){
        this.ctx = ctx;
    }


   public void sendEmail(final ModelMap model, final EmailDetails emailDetails) {

        MimeMessagePreparator preparator = new MimeMessagePreparator() {

            public void prepare(MimeMessage mimeMessage) throws Exception {

                MimeMessageHelper message = new MimeMessageHelper(mimeMessage, true, "UTF-8");
                Map<String, Object> newmodel = new HashMap<String, Object>();

                newmodel.putAll(model);

                message.setFrom(emailDetails.getFrom());
                message.setTo(emailDetails.getTo());
                message.setSubject(emailDetails.getSubject());
                message.setCc(emailDetails.getCC());
               
                String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, emailDetails.getVMTemplate(), newmodel);
                message.setText(text, true);
                

                String fgf = ClassUtils.getDefaultClassLoader().toString();




                // I need to write a correct function so that the files can be loaded from Classpath

                //F:/Haritha_Tech_Project/SystemWithOutSecurity/web/WEB-INF/images/harithalogo.jpg
                //F:/Haritha_Tech_Project/SystemWithOutSecurity/web/WEB-INF/doc/springsecurity.pdf
//               message.addInline("myLogo", ctx.getResource("classpath:/images/harithalogo.jpg") );



                //message.addInline("myLogo", new FileSystemResource( new File("F:/Haritha_Tech_Project/SystemWithOutSecurity/web/WEB-INF/images/harithalogo.jpg")));

                if(emailDetails.getAddInline()[0]!= null)
                {
                    message.addInline("myLogo", new FileSystemResource( new File(emailDetails.getAddInline()[0])));
                }

               if(emailDetails.getAttachment()[0]!= null)
               {
                  message.addAttachment("myDocument.pdf", new FileSystemResource(new File(emailDetails.getAttachment()[0])));
               }

                 //message.addInline("myLogo", new ClassPathResource("/images/harithalogo.jpg"));
              //message.addAttachment("myDocument.pdf", new ClassPathResource("/doc/springsecurity.pdf"));

            }
        };
        try {
            this.mailSender.send(preparator);
        }
        catch (MailException ex) {
            log.error("Problem with Null values in Email Details class", ex);
        }
    }
}
