package com.suman.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "STUDENT")
public class Student implements Serializable {

    private String profilePhotoFileName;
    private String firstName;
    private String lastName;
    private String sex;
    private String parentsName; //if not alive Gaurdian
    private String parentsOccupation; // If in Govt. Services give Designation,Dept., Location
    private String parentsAnnualIncome;
    private String username;
    private String collegeRegistrationNumber; //Username & reg no can be same
    private String password;
    private String parentsUsername;
    private String parentsPassword;
    private long id;
    private String courseJoined;
    private String dateofBirth; // Proof to be enclosed
    private String motherTounge;
    private String nationality;
    private String religion;
    private String mobileNumber;
    private String emailId;
    private String currentAddress; //For communication Line 1, Line 2, Home,Strret
    private String currentLocation; //Village/Town/city
    private String currentDistrict;
    private String currentState;
    private String currentCountry;
    private String currentPincode;
    private String currentPhoneNumber;
    //assuming Prarent's permanent/Student's are same
    private String permanentAddress; //For Permanent Line 1, Line 2, Home,Strret
    private String permanentLocation; //Village/Town/city
    private String permanentDistrict;
    private String permanentState;
    private String permanentCountry;
    private String permanentPincode;
    private String permanentPhoneNumber;
    private String parentsCorrespondenceAddress; //For Permanent Line 1, Line 2, Home,Strret
    private String parentsCorrespondenceLocation; //Village/Town/city
    private String parentsCorrespondenceDistrict;
    private String parentsCorrespondenceState;
    private String parentsCorrespondenceCountry;
    private String parentsCorrespondencePincode;
    private String parentsCorrespondencePhoneNumber;
    private String parentsEmailid;
    private String nameQE; //Name of Qualifying Examination
    private String acedamicYearStudiedQE; //like june 2008-march 2010
    private String hallTicketNoQE;
    private String passingGradeQE; //First with Distiction/First/second/third or Pass
    private String subjectsQE; // String Combinations Possible like MBPC,BPC,
    private String englishMarksObtainedQE;
    private String sanskritMarksObtainedQE;
    private String botanyMarksObtainedQE;
    private String zoologyMarksObtainedQE;
    private String physicsMarksObtainedQE;
    private String chemistryMarksObtainedQE;
    private String maxEnglishMarksQE;
    private String maxSanskritMarksQE;
    private String maxBotanyMarksQE;
    private String maxZoologyMarksQE;
    private String maxphysicsMarksQE;
    private String maxchemistryMarksQE;
    //From this Automatically percnetage subject-wise, sciennce Subjectwise in Display
    // Generate a PDF doc with Specific Signature
    private String hallTicketEntranceExam;
    private String rankEntranceExam;
    private String admissionNo;
    private String admissionDate; //in day-month-Year Format
    private String classVIAcademicYear;
    private String classVISchool;
    private String classVIRemarks;
    private String classVIIAcademicYear;
    private String classVIISchool;
    private String classVIIRemarks;
    private String classVIIIAcademicYear;
    private String classVIIISchool;
    private String classVIIIRemarks;
    private String classIXAcademicYear;
    private String classIXSchool;
    private String classIXRemarks;
    private String classXAcademicYear;
    private String classXSchool;
    private String classXRemarks;
    private String classXIAcademicYear;
    private String classXICollege;
    private String classXIRemarks;
    private String classXIIAcademicYear;
    private String classXIICollege;
    private String classXIIRemarks;
    //Doc submitted Check List
    private String dobCertificate;
    private String interMemoCertificate;
    private String studyCertificate; //From 6th-12th
    private String transferCertificate;
    private String conductCertificate;
    private String casteCertificate;
    private String eamcetRankCertificate;
    private String eamcetHallTicketCertificate;
    private String photosCheck;
    private String otherCertificate;

    @Column(name = "CourseJoined", length = 10, nullable = true)
    public String getCourseJoined() {
        return courseJoined;
    }

    public void setCourseJoined(String courseJoined) {
        this.courseJoined = courseJoined;
    }

    @Id
    @GeneratedValue
    @Column(name = "id")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Column(name = "AcedamicYearStudiedQE", length = 9, nullable = true)
    public String getAcedamicYearStudiedQE() {
        return acedamicYearStudiedQE;
    }

    public void setAcedamicYearStudiedQE(String acedamicYearStudiedQE) {
        this.acedamicYearStudiedQE = acedamicYearStudiedQE;
    }

    @Column(name = "ProfilePhotoFileName", nullable = true)
    public String getProfilePhotoFileName() {
        return profilePhotoFileName;
    }

    public void setProfilePhotoFileName(String profilePhotoFileName) {
        this.profilePhotoFileName = profilePhotoFileName;
    }

    @Column(name = "AdmissionDate", length = 10, nullable = true)
    public String getAdmissionDate() {
        return admissionDate;
    }

    public void setAdmissionDate(String admissionDate) {
        this.admissionDate = admissionDate;
    }

    @Column(name = "AdmissionNo", length = 20, nullable = true)
    public String getAdmissionNo() {
        return admissionNo;
    }

    public void setAdmissionNo(String admissionNo) {
        this.admissionNo = admissionNo;
    }

    @Column(name = "BotanyMarksObtainedQE", nullable = true)
    public String getBotanyMarksObtainedQE() {
        return botanyMarksObtainedQE;
    }

    public void setBotanyMarksObtainedQE(String botanyMarksObtainedQE) {
        this.botanyMarksObtainedQE = botanyMarksObtainedQE;
    }

    @Column(name = "CasteCertificate", nullable = true)
    public String getCasteCertificate() {
        return casteCertificate;
    }

    public void setCasteCertificate(String casteCertificate) {
        this.casteCertificate = casteCertificate;
    }

    @Column(name = "ChemistryMarksObtainedQE", nullable = true)
    public String getChemistryMarksObtainedQE() {
        return chemistryMarksObtainedQE;
    }

    public void setChemistryMarksObtainedQE(String chemistryMarksObtainedQE) {
        this.chemistryMarksObtainedQE = chemistryMarksObtainedQE;
    }

    @Column(name = "ClassIXAcademicYear", length = 9, nullable = true)
    public String getClassIXAcademicYear() {
        return classIXAcademicYear;
    }

    public void setClassIXAcademicYear(String classIXAcademicYear) {
        this.classIXAcademicYear = classIXAcademicYear;
    }

    @Column(name = "ClassIXRemarks", nullable = true)
    public String getClassIXRemarks() {
        return classIXRemarks;
    }

    public void setClassIXRemarks(String classIXRemarks) {
        this.classIXRemarks = classIXRemarks;
    }

    @Column(name = "ClassIXSchool", nullable = true)
    public String getClassIXSchool() {
        return classIXSchool;
    }

    public void setClassIXSchool(String classIXSchool) {
        this.classIXSchool = classIXSchool;
    }

    @Column(name = "ClassVIAcademicYear", length = 9, nullable = true)
    public String getClassVIAcademicYear() {
        return classVIAcademicYear;
    }

    public void setClassVIAcademicYear(String classVIAcademicYear) {
        this.classVIAcademicYear = classVIAcademicYear;
    }

    @Column(name = "ClassVIIAcademicYear", length = 9, nullable = true)
    public String getClassVIIAcademicYear() {
        return classVIIAcademicYear;
    }

    public void setClassVIIAcademicYear(String classVIIAcademicYear) {
        this.classVIIAcademicYear = classVIIAcademicYear;
    }

    @Column(name = "ClassVIIIAcademicYear", length = 9, nullable = true)
    public String getClassVIIIAcademicYear() {
        return classVIIIAcademicYear;
    }

    public void setClassVIIIAcademicYear(String classVIIIAcademicYear) {
        this.classVIIIAcademicYear = classVIIIAcademicYear;
    }

    @Column(name = "ClassVIIIRemarks", nullable = true)
    public String getClassVIIIRemarks() {
        return classVIIIRemarks;
    }

    public void setClassVIIIRemarks(String classVIIIRemarks) {
        this.classVIIIRemarks = classVIIIRemarks;
    }

    @Column(name = "ClassVIIISchool", nullable = true)
    public String getClassVIIISchool() {
        return classVIIISchool;
    }

    public void setClassVIIISchool(String classVIIISchool) {
        this.classVIIISchool = classVIIISchool;
    }

    @Column(name = "ClassVIIRemarks", nullable = true)
    public String getClassVIIRemarks() {
        return classVIIRemarks;
    }

    public void setClassVIIRemarks(String classVIIRemarks) {
        this.classVIIRemarks = classVIIRemarks;
    }

    @Column(name = "ClassVIISchool", nullable = true)
    public String getClassVIISchool() {
        return classVIISchool;
    }

    public void setClassVIISchool(String classVIISchool) {
        this.classVIISchool = classVIISchool;
    }

    @Column(name = "ClassVIRemarks", nullable = true)
    public String getClassVIRemarks() {
        return classVIRemarks;
    }

    public void setClassVIRemarks(String classVIRemarks) {
        this.classVIRemarks = classVIRemarks;
    }

    @Column(name = "ClassVISchool", nullable = true)
    public String getClassVISchool() {
        return classVISchool;
    }

    public void setClassVISchool(String classVISchool) {
        this.classVISchool = classVISchool;
    }

    @Column(name = "ClassXAcademicYear", length = 9, nullable = true)
    public String getClassXAcademicYear() {
        return classXAcademicYear;
    }

    public void setClassXAcademicYear(String classXAcademicYear) {
        this.classXAcademicYear = classXAcademicYear;
    }

    @Column(name = "ClassXIAcademicYear", length = 9, nullable = true)
    public String getClassXIAcademicYear() {
        return classXIAcademicYear;
    }

    public void setClassXIAcademicYear(String classXIAcademicYear) {
        this.classXIAcademicYear = classXIAcademicYear;
    }

    @Column(name = "ClassXICollege", nullable = true)
    public String getClassXICollege() {
        return classXICollege;
    }

    public void setClassXICollege(String classXICollege) {
        this.classXICollege = classXICollege;
    }

    @Column(name = "ClassXIIAcademicYear", length = 9, nullable = true)
    public String getClassXIIAcademicYear() {
        return classXIIAcademicYear;
    }

    public void setClassXIIAcademicYear(String classXIIAcademicYear) {
        this.classXIIAcademicYear = classXIIAcademicYear;
    }

    @Column(name = "ClassXIICollege", nullable = true)
    public String getClassXIICollege() {
        return classXIICollege;
    }

    public void setClassXIICollege(String classXIICollege) {
        this.classXIICollege = classXIICollege;
    }

    @Column(name = "ClassXIIRemarks", nullable = true)
    public String getClassXIIRemarks() {
        return classXIIRemarks;
    }

    public void setClassXIIRemarks(String classXIIRemarks) {
        this.classXIIRemarks = classXIIRemarks;
    }

    @Column(name = "ClassXIRemarks", nullable = true)
    public String getClassXIRemarks() {
        return classXIRemarks;
    }

    public void setClassXIRemarks(String classXIRemarks) {
        this.classXIRemarks = classXIRemarks;
    }

    @Column(name = "ClassXRemarks", nullable = true)
    public String getClassXRemarks() {
        return classXRemarks;
    }

    public void setClassXRemarks(String classXRemarks) {
        this.classXRemarks = classXRemarks;
    }

    @Column(name = "ClassXSchool", nullable = true)
    public String getClassXSchool() {
        return classXSchool;
    }

    public void setClassXSchool(String classXSchool) {
        this.classXSchool = classXSchool;
    }

    @Column(name = "CollegeRegistrationNumber", length = 50, nullable = true)
    public String getCollegeRegistrationNumber() {
        return collegeRegistrationNumber;
    }

    public void setCollegeRegistrationNumber(String collegeRegistrationNumber) {
        this.collegeRegistrationNumber = collegeRegistrationNumber;
    }

    @Column(name = "ConductCertificate", nullable = true)
    public String getConductCertificate() {
        return conductCertificate;
    }

    public void setConductCertificate(String conductCertificate) {
        this.conductCertificate = conductCertificate;
    }

    @Column(name = "CurrentAddress", nullable = true)
    public String getCurrentAddress() {
        return currentAddress;
    }

    public void setCurrentAddress(String currentAddress) {
        this.currentAddress = currentAddress;
    }

    @Column(name = "CurrentCountry", length = 20, nullable = true)
    public String getCurrentCountry() {
        return currentCountry;
    }

    public void setCurrentCountry(String currentCountry) {
        this.currentCountry = currentCountry;
    }

    @Column(name = "CurrentDistrict", length = 20, nullable = true)
    public String getCurrentDistrict() {
        return currentDistrict;
    }

    public void setCurrentDistrict(String currentDistrict) {
        this.currentDistrict = currentDistrict;
    }

    @Column(name = "CurrentLocation", length = 20, nullable = true)
    public String getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(String currentLocation) {
        this.currentLocation = currentLocation;
    }

    @Column(name = "CurrentPhoneNumber", length = 20, nullable = true)
    public String getCurrentPhoneNumber() {
        return currentPhoneNumber;
    }

    public void setCurrentPhoneNumber(String currentPhoneNumber) {
        this.currentPhoneNumber = currentPhoneNumber;
    }

    @Column(name = "CurrentPincode", length = 10, nullable = true)
    public String getCurrentPincode() {
        return currentPincode;
    }

    public void setCurrentPincode(String currentPincode) {
        this.currentPincode = currentPincode;
    }

    @Column(name = "CurrentState", length = 50, nullable = true)
    public String getCurrentState() {
        return currentState;
    }

    public void setCurrentState(String currentState) {
        this.currentState = currentState;
    }

    @Column(name = "DateofBirth", length = 10, nullable = true)
    public String getDateofBirth() {
        return dateofBirth;
    }

    public void setDateofBirth(String dateofBirth) {
        this.dateofBirth = dateofBirth;
    }

    @Column(name = "dobCertificate", nullable = true)
    public String getDobCertificate() {
        return dobCertificate;
    }

    public void setDobCertificate(String dobCertificate) {
        this.dobCertificate = dobCertificate;
    }

    @Column(name = "EamcetHallTicketCertificate", nullable = true)
    public String getEamcetHallTicketCertificate() {
        return eamcetHallTicketCertificate;
    }

    public void setEamcetHallTicketCertificate(String eamcetHallTicketCertificate) {
        this.eamcetHallTicketCertificate = eamcetHallTicketCertificate;
    }

    @Column(name = "EamcetRankCertificate", nullable = true)
    public String getEamcetRankCertificate() {
        return eamcetRankCertificate;
    }

    public void setEamcetRankCertificate(String eamcetRankCertificate) {
        this.eamcetRankCertificate = eamcetRankCertificate;
    }

    @Column(name = "EmailId", length = 100, nullable = true)
    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    @Column(name = "EnglishMarksObtainedQE", nullable = true)
    public String getEnglishMarksObtainedQE() {
        return englishMarksObtainedQE;
    }

    public void setEnglishMarksObtainedQE(String englishMarksObtainedQE) {
        this.englishMarksObtainedQE = englishMarksObtainedQE;
    }

    @Column(name = "FirstName", length = 100, nullable = true)
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Column(name = "HallTicketEntranceExam", length = 50, nullable = true)
    public String getHallTicketEntranceExam() {
        return hallTicketEntranceExam;
    }

    public void setHallTicketEntranceExam(String hallTicketEntranceExam) {
        this.hallTicketEntranceExam = hallTicketEntranceExam;
    }

    @Column(name = "HallTicketNoQE", length = 50, nullable = true)
    public String getHallTicketNoQE() {
        return hallTicketNoQE;
    }

    public void setHallTicketNoQE(String hallTicketNoQE) {
        this.hallTicketNoQE = hallTicketNoQE;
    }

    @Column(name = "InterMemoCertificate", nullable = true)
    public String getInterMemoCertificate() {
        return interMemoCertificate;
    }

    public void setInterMemoCertificate(String interMemoCertificate) {
        this.interMemoCertificate = interMemoCertificate;
    }

    @Column(name = "LastName", length = 100, nullable = true)
    public String getLastName() {

        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Column(name = "MaxBotanyMarksQE", nullable = true)
    public String getMaxBotanyMarksQE() {
        return maxBotanyMarksQE;
    }

    public void setMaxBotanyMarksQE(String maxBotanyMarksQE) {
        this.maxBotanyMarksQE = maxBotanyMarksQE;
    }

    @Column(name = "MaxEnglishMarksQE", nullable = true)
    public String getMaxEnglishMarksQE() {
        return maxEnglishMarksQE;
    }

    public void setMaxEnglishMarksQE(String maxEnglishMarksQE) {
        this.maxEnglishMarksQE = maxEnglishMarksQE;
    }

    @Column(name = "MaxSanskritMarksQE", nullable = true)
    public String getMaxSanskritMarksQE() {
        return maxSanskritMarksQE;
    }

    public void setMaxSanskritMarksQE(String maxSanskritMarksQE) {
        this.maxSanskritMarksQE = maxSanskritMarksQE;
    }

    @Column(name = "MaxZoologyMarksQE", nullable = true)
    public String getMaxZoologyMarksQE() {
        return maxZoologyMarksQE;
    }

    public void setMaxZoologyMarksQE(String maxZoologyMarksQE) {
        this.maxZoologyMarksQE = maxZoologyMarksQE;
    }

    @Column(name = "MaxchemistryMarksQE", nullable = true)
    public String getMaxchemistryMarksQE() {
        return maxchemistryMarksQE;
    }

    public void setMaxchemistryMarksQE(String maxchemistryMarksQE) {
        this.maxchemistryMarksQE = maxchemistryMarksQE;
    }

    @Column(name = "MaxphysicsMarksQE", nullable = true)
    public String getMaxphysicsMarksQE() {
        return maxphysicsMarksQE;
    }

    public void setMaxphysicsMarksQE(String maxphysicsMarksQE) {
        this.maxphysicsMarksQE = maxphysicsMarksQE;
    }

    @Column(name = "MobileNumber", length = 20, nullable = true)
    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    @Column(name = "MotherTounge", length = 20, nullable = true)
    public String getMotherTounge() {
        return motherTounge;
    }

    public void setMotherTounge(String motherTounge) {
        this.motherTounge = motherTounge;
    }

    @Column(name = "NameQE", length = 30, nullable = true)
    public String getNameQE() {
        return nameQE;
    }

    public void setNameQE(String nameQE) {
        this.nameQE = nameQE;
    }

    @Column(name = "Nationality", length = 20, nullable = true)
    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    @Column(name = "OtherCertificate", nullable = true)
    public String getOtherCertificate() {
        return otherCertificate;
    }

    public void setOtherCertificate(String otherCertificate) {
        this.otherCertificate = otherCertificate;
    }

    @Column(name = "ParentsAnnualIncome", length = 20, nullable = true)
    public String getParentsAnnualIncome() {
        return parentsAnnualIncome;
    }

    public void setParentsAnnualIncome(String parentsAnnualIncome) {
        this.parentsAnnualIncome = parentsAnnualIncome;
    }

    @Column(name = "ParentsCorrespondenceAddress", nullable = true)
    public String getParentsCorrespondenceAddress() {
        return parentsCorrespondenceAddress;
    }

    public void setParentsCorrespondenceAddress(String parentsCorrespondenceAddress) {
        this.parentsCorrespondenceAddress = parentsCorrespondenceAddress;
    }

    @Column(name = "ParentsCorrespondenceCountry", length = 30, nullable = true)
    public String getParentsCorrespondenceCountry() {
        return parentsCorrespondenceCountry;
    }

    public void setParentsCorrespondenceCountry(String parentsCorrespondenceCountry) {
        this.parentsCorrespondenceCountry = parentsCorrespondenceCountry;
    }

    @Column(name = "ParentsCorrespondenceDistrict", length = 30, nullable = true)
    public String getParentsCorrespondenceDistrict() {
        return parentsCorrespondenceDistrict;
    }

    public void setParentsCorrespondenceDistrict(String parentsCorrespondenceDistrict) {
        this.parentsCorrespondenceDistrict = parentsCorrespondenceDistrict;
    }

    @Column(name = "ParentsCorrespondenceLocation", nullable = true)
    public String getParentsCorrespondenceLocation() {
        return parentsCorrespondenceLocation;
    }

    public void setParentsCorrespondenceLocation(String parentsCorrespondenceLocation) {
        this.parentsCorrespondenceLocation = parentsCorrespondenceLocation;
    }

    @Column(name = "ParentsCorrespondencePhoneNumber", length = 20, nullable = true)
    public String getParentsCorrespondencePhoneNumber() {
        return parentsCorrespondencePhoneNumber;
    }

    public void setParentsCorrespondencePhoneNumber(String parentsCorrespondencePhoneNumber) {
        this.parentsCorrespondencePhoneNumber = parentsCorrespondencePhoneNumber;
    }

    @Column(name = "ParentsCorrespondencePincode", length = 10, nullable = true)
    public String getParentsCorrespondencePincode() {
        return parentsCorrespondencePincode;
    }

    public void setParentsCorrespondencePincode(String parentsCorrespondencePincode) {
        this.parentsCorrespondencePincode = parentsCorrespondencePincode;
    }

    @Column(name = "ParentsCorrespondenceState", length = 50, nullable = true)
    public String getParentsCorrespondenceState() {
        return parentsCorrespondenceState;
    }

    public void setParentsCorrespondenceState(String parentsCorrespondenceState) {
        this.parentsCorrespondenceState = parentsCorrespondenceState;
    }

    @Column(name = "ParentsEmailid", length = 50, nullable = true)
    public String getParentsEmailid() {
        return parentsEmailid;
    }

    public void setParentsEmailid(String parentsEmailid) {
        this.parentsEmailid = parentsEmailid;
    }

    @Column(name = "ParentsName", length = 100, nullable = true)
    public String getParentsName() {
        return parentsName;
    }

    public void setParentsName(String parentsName) {
        this.parentsName = parentsName;
    }

    @Column(name = "ParentsOccupation", nullable = true)
    public String getParentsOccupation() {
        return parentsOccupation;
    }

    public void setParentsOccupation(String parentsOccupation) {
        this.parentsOccupation = parentsOccupation;
    }

    @Column(name = "ParentsPassword", nullable = true)
    public String getParentsPassword() {
        return parentsPassword;
    }

    public void setParentsPassword(String parentsPassword) {
        this.parentsPassword = parentsPassword;
    }

    @Column(name = "ParentsUsername", length = 50, nullable = true)
    public String getParentsUsername() {
        return parentsUsername;
    }

    public void setParentsUsername(String parentsUsername) {
        this.parentsUsername = parentsUsername;
    }

    @Column(name = "PassingGradeQE", length = 10, nullable = true)
    public String getPassingGradeQE() {
        return passingGradeQE;
    }

    public void setPassingGradeQE(String passingGradeQE) {
        this.passingGradeQE = passingGradeQE;
    }

    @Column(name = "Password", nullable = true)
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Column(name = "PermanentAddress", nullable = true)
    public String getPermanentAddress() {
        return permanentAddress;
    }

    public void setPermanentAddress(String permanentAddress) {
        this.permanentAddress = permanentAddress;
    }

    @Column(name = "PermanentCountry", length = 50, nullable = true)
    public String getPermanentCountry() {
        return permanentCountry;
    }

    public void setPermanentCountry(String permanentCountry) {
        this.permanentCountry = permanentCountry;
    }

    @Column(name = "PermanentDistrict", length = 50, nullable = true)
    public String getPermanentDistrict() {
        return permanentDistrict;
    }

    public void setPermanentDistrict(String permanentDistrict) {
        this.permanentDistrict = permanentDistrict;
    }

    @Column(name = "PermanentLocation", length = 50, nullable = true)
    public String getPermanentLocation() {
        return permanentLocation;
    }

    public void setPermanentLocation(String permanentLocation) {
        this.permanentLocation = permanentLocation;
    }

    @Column(name = "PermanentPhoneNumber", length = 20, nullable = true)
    public String getPermanentPhoneNumber() {
        return permanentPhoneNumber;
    }

    public void setPermanentPhoneNumber(String permanentPhoneNumber) {
        this.permanentPhoneNumber = permanentPhoneNumber;
    }

    @Column(name = "PermanentPincode", length = 15, nullable = true)
    public String getPermanentPincode() {
        return permanentPincode;
    }

    public void setPermanentPincode(String permanentPincode) {
        this.permanentPincode = permanentPincode;
    }

    @Column(name = "PermanentState", length = 50, nullable = true)
    public String getPermanentState() {
        return permanentState;
    }

    public void setPermanentState(String permanentState) {
        this.permanentState = permanentState;
    }

    @Column(name = "PhotosCheck", nullable = true)
    public String getPhotosCheck() {
        return photosCheck;
    }

    public void setPhotosCheck(String photosCheck) {
        this.photosCheck = photosCheck;
    }

    @Column(name = "PhysicsMarksObtainedQE", nullable = true)
    public String getPhysicsMarksObtainedQE() {
        return physicsMarksObtainedQE;
    }

    public void setPhysicsMarksObtainedQE(String physicsMarksObtainedQE) {
        this.physicsMarksObtainedQE = physicsMarksObtainedQE;
    }

    @Column(name = "RankEntranceExam", length = 10, nullable = true)
    public String getRankEntranceExam() {
        return rankEntranceExam;
    }

    public void setRankEntranceExam(String rankEntranceExam) {
        this.rankEntranceExam = rankEntranceExam;
    }

    @Column(name = "Religion", length = 20, nullable = true)
    public String getReligion() {
        return religion;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    @Column(name = "SanskritMarksObtainedQE", nullable = true)
    public String getSanskritMarksObtainedQE() {
        return sanskritMarksObtainedQE;
    }

    public void setSanskritMarksObtainedQE(String sanskritMarksObtainedQE) {
        this.sanskritMarksObtainedQE = sanskritMarksObtainedQE;
    }

    @Column(name = "Sex", length = 6, nullable = true)
    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    @Column(name = "StudyCertificate", nullable = true)
    public String getStudyCertificate() {
        return studyCertificate;
    }

    public void setStudyCertificate(String studyCertificate) {
        this.studyCertificate = studyCertificate;
    }

    @Column(name = "SubjectsQE", nullable = true)
    public String getSubjectsQE() {
        return subjectsQE;
    }

    public void setSubjectsQE(String subjectsQE) {
        this.subjectsQE = subjectsQE;
    }

    @Column(name = "TransferCertificate", nullable = true)
    public String getTransferCertificate() {
        return transferCertificate;
    }

    public void setTransferCertificate(String transferCertificate) {
        this.transferCertificate = transferCertificate;
    }

    @Column(name = "Username", length = 50, nullable = true)
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Column(name = "ZoologyMarksObtainedQE", nullable = true)
    public String getZoologyMarksObtainedQE() {
        return zoologyMarksObtainedQE;
    }

    public void setZoologyMarksObtainedQE(String zoologyMarksObtainedQE) {
        this.zoologyMarksObtainedQE = zoologyMarksObtainedQE;
    }
}
