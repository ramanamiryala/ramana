package com.suman.domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "STDBASEPROFILE")
public class StdBaseProfile implements Serializable {


    private String username;
    private String firstName;
    private String lastName;
    private String sex;
    private String profilePhotoFileName;

    private String universityRegistered;
    private String collegeRegistrationNumber; //Username & reg no can be same
    private String courseName;
    private String courseYear;
    private String joiningAcademicYear;

    private String emailId;
    private String phoneNumber;

    private String parentsName;
    private String parentsEmailid;
    private String parentsPhoneNumber;

    private long id;
    

    @Id
    @GeneratedValue
    @Column(name = "id")
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
    
    @Column(name="UniversityRegistered", length=10, nullable=true)

    public String getUniversityRegistered() {
        return universityRegistered;
    }

    public void setUniversityRegistered(String universityRegistered) {
        this.universityRegistered = universityRegistered;
    }



    @Column(name="Username", length=50, nullable=true)
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Column(name="EmailId", length=50, nullable=true)
    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }


    @Column(name="PhoneNumber", length=50, nullable=true)
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    


    @Column(name="CollegeRegistrationNumber", length=50, nullable=true)
    public String getCollegeRegistrationNumber() {
        return collegeRegistrationNumber;
    }

    public void setCollegeRegistrationNumber(String collegeRegistrationNumber) {
        this.collegeRegistrationNumber = collegeRegistrationNumber;
    }

    @Column(name="CourseName", length=50, nullable=true)
    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    @Column(name="CourseYear", length=50, nullable=true)
    public String getCourseYear() {
        return courseYear;
    }

    public void setCourseYear(String courseYear) {
        this.courseYear = courseYear;
    }

    @Column(name="FirstName", length=50, nullable=true)
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Column(name="JoiningAcademicYear", length=20, nullable=true)
    public String getJoiningAcademicYear() {
        return joiningAcademicYear;
    }

    public void setJoiningAcademicYear(String joiningAcademicYear) {
        this.joiningAcademicYear = joiningAcademicYear;
    }


    @Column(name="LastName", length=50, nullable=true)
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Column(name="ParentsEmailid", length=50, nullable=true)
    public String getParentsEmailid() {
        return parentsEmailid;
    }

    public void setParentsEmailid(String parentsEmailid) {
        this.parentsEmailid = parentsEmailid;
    }

    @Column(name="ParentsName", length=50, nullable=true)
    public String getParentsName() {
        return parentsName;
    }

    public void setParentsName(String parentsName) {
        this.parentsName = parentsName;
    }

    @Column(name="ParentsPhoneNumber", length=20, nullable=true)
    public String getParentsPhoneNumber() {
        return parentsPhoneNumber;
    }

    public void setParentsPhoneNumber(String parentsPhoneNumber) {
        this.parentsPhoneNumber = parentsPhoneNumber;
    }

    @Column(name = "ProfilePhotoFileName", length = 20, nullable = true)
    public String getProfilePhotoFileName() {
        return profilePhotoFileName;
    }

    public void setProfilePhotoFileName(String profilePhotoFileName) {
        this.profilePhotoFileName = profilePhotoFileName;
    }

   @Column(name = "Sex", length = 6, nullable = true)
    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }
  }



