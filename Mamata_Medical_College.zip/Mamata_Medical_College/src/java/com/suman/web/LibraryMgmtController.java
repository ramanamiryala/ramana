package com.suman.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.RequestParam;

import com.suman.domain.Users;
import com.suman.domain.Catalogue;
import com.suman.domain.Checkinandoutlog;
import com.suman.domain.Staff;
import com.suman.domain.Student;

import java.text.DateFormat;
import java.util.*;


import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;

import org.apache.log4j.Logger;

import com.suman.service.LibraryService;
import com.suman.security.UsersService;
import com.suman.service.StaffService;
import com.suman.service.StudentService;
import com.suman.validator.CatalogueValidator;

import com.suman.email.EmailSender;
import java.text.SimpleDateFormat;

@Controller
public class LibraryMgmtController {

    private UsersService usersService;
    private CatalogueValidator catalogueValidator;
    private LibraryService libraryService;
    private StaffService staffService;
    private StudentService studentService;
    private GenericManageableCaptchaService captchaService;
    private Logger log = Logger.getLogger(LibraryMgmtController.class);
    private EmailSender emailSender;

    @Autowired
    public LibraryMgmtController(GenericManageableCaptchaService captchaService, LibraryService libraryService,
            UsersService usersService, EmailSender emailSender, CatalogueValidator catalogueValidator,
            StaffService staffService, StudentService studentService) {
        this.libraryService = libraryService;
        this.captchaService = captchaService;
        this.usersService = usersService;
        this.emailSender = emailSender;
        this.catalogueValidator = catalogueValidator;
        this.staffService = staffService;
        this.studentService = studentService;
    }


    @RequestMapping(value = "/CatalogueMgmtAddRecord.htm")
    public ModelAndView CatalogueMgmtAddRecord(ModelMap modelMap) {
        Catalogue catalogue = new Catalogue();
        modelMap.addAttribute("catalogue", catalogue);
        libraryService.formAddOptionvalues(modelMap);
        String formerror = "";
        modelMap.addAttribute("formerror", formerror);
        return new ModelAndView("CatalogueMgmtAddRecord", modelMap);
    }

    @RequestMapping(value = "/CatalogueMgmtAddRecordSuccess.htm")
    public ModelAndView CatalogueMgmtAddRecordSuccess(
            @ModelAttribute("catalogue") Catalogue catalogue,
            BindingResult result, ModelMap model,
            HttpServletRequest request) throws Exception {

        catalogue.setYearofPublication(request.getParameter("yearofPublication"));


        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");


        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);

            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        catalogueValidator.validate(catalogue, result);

        if (result.hasErrors()) {
            libraryService.formAddOptionvalues(model);
            return new ModelAndView("CatalogueMgmtAddRecord", model);
        } else {
            if (!isResponseCorrect) { //Capatcha is not correct
                libraryService.formAddOptionvalues(model);
                model.addAttribute("formerror", "Capacth is Invalid");
                return new ModelAndView("CatalogueMgmtAddRecord", model);
            } else {
                List<Catalogue> CataloguedetailsList = libraryService.findCatalogueByRecordIdentifier(catalogue.getRecordIdentifier());
                if (CataloguedetailsList.size() > 0) {
                    libraryService.formAddOptionvalues(model);
                    model.addAttribute("RecordIdentifierError", "Item with Record Identifier is already existed");
                    return new ModelAndView("CatalogueMgmtAddRecord", model);
                }
                libraryService.saveCatalogue(catalogue);
                model.addAttribute("catalogue", catalogue);
                return new ModelAndView("CatalogueMgmtAddRecordSuccess", model);
            }
        }
    }

    @RequestMapping("/CatalogueMgmtSearch.htm")
    public ModelAndView CatalogueMgmtSearch(ModelMap modelMap) {

        modelMap.addAttribute("catalogue1", new Catalogue());
        libraryService.formAddOptionvalues(modelMap);
        return new ModelAndView("CatalogueMgmtSearch", modelMap);

    }


    @RequestMapping(value = "/CatalogueMgmtSearchResult.htm")
    public ModelAndView CatalogueMgmtSearchResult(HttpServletRequest request, ModelMap modelMap,
            @ModelAttribute("catalogue1") Catalogue catalogue1) {

        request.getSession().setAttribute("catalogue1_session", catalogue1);
        modelMap.addAttribute("catalogue1", new Catalogue());
        catalogue1.setYearofPublication(request.getParameter("yearofPublication"));
        List<Catalogue> searchCatalogue = libraryService.searchCatalogue(catalogue1);
        modelMap.addAttribute("searchCatalogue", searchCatalogue);
        libraryService.formAddOptionvalues(modelMap);

        if (request.getParameter("typeofrecord").toString().equals("")
                && request.getParameter("author").toString().equals("")
                && request.getParameter("yearofPublication").toString().equals("")
                && request.getParameter("ISDNNo").toString().equals("")
                && request.getParameter("recordIdentifier").toString().equals("")) {
            return new ModelAndView("CatalogueMgmtSearch", modelMap);
        } else {
            return new ModelAndView("CatalogueMgmtSearchResult", modelMap);
        }
    }


    @RequestMapping("/CatalogueMgmtModify.htm")
    public ModelAndView CatalogueMgmtModify(
            ModelMap model,
            @ModelAttribute("catalogue") Catalogue catalogue,
            @RequestParam("selection") int selection, HttpServletRequest request) {

        if (selection != 0) {
            List<Catalogue> catalogueDetailsList = libraryService.findCatalogueById(selection);
            Catalogue catalogueDetails = new Catalogue();
            catalogueDetails = catalogueDetailsList.get(0);

            String year = catalogueDetails.getYearofPublication();
            // String[] splitedyear = year.split("[]");
            model.addAttribute("yearofPublication", year);

            model.addAttribute("selection", selection);
            model.addAttribute("catalogueDetails", catalogueDetails);

            libraryService.formAddOptionvalues(model);

            return new ModelAndView("CatalogueMgmtModify", model);
        } else {
            return new ModelAndView("CatalogueMgmtSearchResult", model);
        }
    }


    @RequestMapping(value = "/CatalogueMgmtModifySuccess.htm")
    public ModelAndView CatalogueMgmtModifySuccess(
            @ModelAttribute("catalogue") Catalogue catalogue,
            BindingResult result, ModelMap model,
            HttpServletRequest request,
            @RequestParam("selection") int selection) throws Exception {

        if (selection != 0) {

            catalogue.setId(selection);
            catalogue.setYearofPublication(request.getParameter("yearofPublication"));
            // Checking Capatch Response
            boolean isResponseCorrect = false;
            String captchaId = request.getSession().getId();
            String response = request.getParameter("j_captcha_response");

            try {
                if (response != null) {
                    isResponseCorrect = captchaService.validateResponseForID(captchaId, response);

                }

            } catch (CaptchaServiceException e) {
                log.error("Problem Jcaptcha settings ", e);
            }

            catalogueValidator.validate(catalogue, result);

            if (result.hasErrors()) {
                libraryService.formAddOptionvalues(model);
                return new ModelAndView("CatalogueMgmtModify", model);
            } else {
                if (!isResponseCorrect) { //Capatcha is not correct
                    libraryService.formAddOptionvalues(model);
                    model.addAttribute("formerror", "Capacth is Invalid");
                    return new ModelAndView("CatalogueMgmtModify", model);
                } else {


                    libraryService.saveCatalogue(catalogue);
                    model.addAttribute("catalogue", catalogue);
                }
            }
        }

        return new ModelAndView("CatalogueMgmtModifySuccess", model);
    }


    @RequestMapping(value = "/CatalogueMgmtSearchResultback.htm")
    public ModelAndView CatalogueMgmtSearchResultback(HttpServletRequest request, ModelMap modelMap) {

        Catalogue catalogue1 = (Catalogue) request.getSession().getAttribute("catalogue1_session");
        modelMap.addAttribute("catalogue1", new Catalogue());
        // catalogue1.setYearofPublication(request.getParameter("yearofPublication"));
        List<Catalogue> searchCatalogue = libraryService.searchCatalogue(catalogue1);
        modelMap.addAttribute("searchCatalogue", searchCatalogue);
        libraryService.formAddOptionvalues(modelMap);

        return new ModelAndView("CatalogueMgmtSearchResult", modelMap);
    }

    @RequestMapping("/CatalogueMgmtDeleteCatalogue.htm")
    public ModelAndView CatalogueMgmtDeleteResult(
            ModelMap model,
            @ModelAttribute("catalogue") Catalogue catalogue,
            @RequestParam("selection") int selection, HttpServletRequest request) {

        if (selection != 0) {
            List<Catalogue> catalogueDetailsList = libraryService.findCatalogueById(selection);
            Catalogue catalogueDetails = new Catalogue();
            catalogueDetails = catalogueDetailsList.get(0);

            String year = catalogueDetails.getYearofPublication();
            // String[] splitedyear = year.split("[]");
            model.addAttribute("yearofPublication", year);

            model.addAttribute("selection", selection);
            model.addAttribute("catalogueDetails", catalogueDetails);

            libraryService.formAddOptionvalues(model);

            return new ModelAndView("CatalogueMgmtDeleteCatalogue", model);
        } else {
            return new ModelAndView("CatalogueMgmtSearchResult", model);
        }
    }

    @RequestMapping("/CatalogueMgmtDeleteCatalogueSuccess.htm")
    public ModelAndView CatalogueMgmtDeleteCatalogueSuccess(
            ModelMap model,
            @ModelAttribute("catalogue") Catalogue catalogue,
            @RequestParam("selection") int selection) {

        if (selection != 0) {
            List<Catalogue> catalogueDetailsList = libraryService.findCatalogueById(selection);
            catalogue = catalogueDetailsList.get(0);

            libraryService.deleteCatalogueRecord(catalogue);

            return new ModelAndView("CatalogueMgmtDeleteCatalogueSuccess", model);
        } else {
            return new ModelAndView("CatalogueMgmtDeleteCatalogue", model);
        }
    }

    @RequestMapping("/LibrarianCheckOut.htm")
    public ModelAndView LibrarianCheckOut(ModelMap model) {

        Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
        model.addAttribute("checkinandoutlog", checkinandoutlog);
        return new ModelAndView("LibrarianCheckOut", model);
    }

    @RequestMapping("/LibrarianCheckOutConfirm.htm")
    public ModelAndView LibrarianCheckOutConfirm(ModelMap model,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog,
            HttpServletRequest request) {

        String borrowerdetails = null;
        List<Catalogue> catalogueDetailsList = libraryService.findCatalogueByRecordIdentifier(checkinandoutlog.getRecordIdentifier());

        if (catalogueDetailsList.size() <= 0) {

            model.addAttribute("RecordIdentifierError", "RecordIdentifier does not existed or empty");
            //model.addAttribute("BorrowerUsernameError", "BorrowerUsername does not existed or empty");
            return new ModelAndView("LibrarianCheckOut", model);

        } else {

            List<Checkinandoutlog> checkinandoutlogDetailslist = libraryService.findCheckinandoutlogByRIwithCheckout(checkinandoutlog.getRecordIdentifier());

            if (checkinandoutlogDetailslist.size() <= 0) {

                 //model.addAttribute("BorrowerUsernameError", "BorrowerUsername does not existed or empty");

                List<Users> usersDetailsList = usersService.findUsersByUsername(checkinandoutlog.getBorrowerUsername());

                Catalogue catalogueDetails = catalogueDetailsList.get(0);

                String bookdetails = catalogueDetails.getTitle() + "," + catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                        + "," + catalogueDetails.getPublishers();

               // Users usersdetails = usersDetailsList.get(0);

                if (usersDetailsList.size() <= 0) {
                    model.addAttribute("BorrowerUsernameError", "User does not exist");
                    return new ModelAndView("LibrarianCheckOut", model);
                } else if (!usersDetailsList.get(0).isEnabled()) {
                    model.addAttribute("BorrowerUsernameError", "User is not enabled");
                    return new ModelAndView("LibrarianCheckOut", model);
                } 
                
                else {

                     Users usersdetails = usersDetailsList.get(0);
                    if (usersdetails.getUsertype().equals("STAFF")) {

                        List<Staff> staffdetailsList = staffService.findStaffByUserid(checkinandoutlog.getBorrowerUsername());

                        borrowerdetails = staffdetailsList.get(0).getFirstname() + "," + staffdetailsList.get(0).getLastname() + ","
                                + staffdetailsList.get(0).getCurrentDesignation() + "," + staffdetailsList.get(0).getDepartment();
                    } else if (usersdetails.getUsertype().equals("STUDENT")) {

                        List<Student> studentdetailsList = studentService.findStudentByUsername(checkinandoutlog.getBorrowerUsername());

                        borrowerdetails = studentdetailsList.get(0).getFirstName() + "," + studentdetailsList.get(0).getLastName() + ","
                                + studentdetailsList.get(0).getCollegeRegistrationNumber() + "," + studentdetailsList.get(0).getParentsName();
                    } else {
                        borrowerdetails = null;
                    }


                    if (borrowerdetails == null) {
                        model.addAttribute("BorrowerUsernameError", "User is not authorized to access library");
                        return new ModelAndView("LibrarianCheckOut", model);

                    } else {
                        if (libraryService.findCheckOutsByUsername(checkinandoutlog.getBorrowerUsername()) < 3) {

                            Date currentDate = new Date();
                            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                            DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

                            checkinandoutlog.setIssuedDate(dateFormat.format(currentDate).toString());
                            checkinandoutlog.setIssuedTime(currentTime.format(currentDate).toString());
                            checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());
                            checkinandoutlog.setStatus("CheckOut");
                            checkinandoutlog.setFinePaid("");

                            model.addAttribute("checkinandoutlog", checkinandoutlog);
                            model.addAttribute("bookdetails", bookdetails);
                            model.addAttribute("borrowerdetails", borrowerdetails);

                            String recordIdentifier = checkinandoutlog.getRecordIdentifier();

                            model.addAttribute("recordIdentifier", recordIdentifier);

                            String borrowerUsername = usersdetails.getUsername();

                            model.addAttribute("borrowerUsername", borrowerUsername);

                            return new ModelAndView("LibrarianCheckOutConfirm", model);
                        } else {
                            model.addAttribute("BorrowerUsernameError", " Borrower exceeded maximum Checkouts");
                            return new ModelAndView("LibrarianCheckOut", model);
                        }
                    }
                }

            } else //if (checkinandoutlogDetailslist.get(0).getStatus().equals("CheckOut"))
            {
                model.addAttribute("RecordIdentifierError", "Item with Record Identifier is already Checked Out");
                return new ModelAndView("LibrarianCheckOut", model);
            }
        }
    }

    @RequestMapping("/LibrarianCheckOutConfirmSuccess.htm")
    public ModelAndView LibrarianCheckOutConfirmSuccess(ModelMap model,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog,
            HttpServletRequest request) {

        model.addAttribute("checkinandoutlog", request.getParameter("checkinandoutlog"));
        model.addAttribute("bookdetails", request.getParameter("bookdetails"));
        model.addAttribute("borrowerdetails", request.getParameter("borrowerdetails"));
        model.addAttribute("recordIdentifier", request.getParameter("recordIdentifier"));
        model.addAttribute("borrowerUsername", request.getParameter("borrowerUsername"));

        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");

        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        //   else {
        if (!isResponseCorrect) { //Capatcha is not correct
            libraryService.formAddOptionvalues(model);
            model.addAttribute("formerror", "Capacth is Invalid");
            return new ModelAndView("LibrarianCheckOutConfirm", model);
        } else {

            List<Checkinandoutlog> checkinandoutlogDetailslist = libraryService.findCheckinandoutlogByRecordIdentifier(request.getParameter("recordIdentifier"));

            Date currentDate = new Date();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

            checkinandoutlog.setIssuedDate(dateFormat.format(currentDate).toString());
            checkinandoutlog.setIssuedTime(currentTime.format(currentDate).toString());
            checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());
            checkinandoutlog.setStatus("CheckOut");
            checkinandoutlog.setFinePaid("");

            libraryService.saveCheckinandoutlog(checkinandoutlog);
            model.addAttribute("checkinandoutlog", checkinandoutlog);

            return new ModelAndView("LibrarianCheckOutConfirmSuccess", model);
        }
    }


    @RequestMapping(value = "/LibrarianCheckOutConfirmCancel.htm")
    public ModelAndView LibrarianCheckOutConfirmCancel(ModelMap modelMap) {
        Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
        modelMap.addAttribute("checkinandoutlog", checkinandoutlog);

        return new ModelAndView("LibrarianCheckOut", modelMap);

    }


    @RequestMapping("/LibrarianCheckIn.htm")
    public ModelAndView LibrarianCheckIn(ModelMap model) {

        Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
        model.addAttribute("checkinandoutlog", checkinandoutlog);
        return new ModelAndView("LibrarianCheckIn", model);
    }


    @RequestMapping("/LibrarianCheckInConfirm.htm")
    public ModelAndView LibrarianCheckInConfirm(ModelMap model,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog,
            HttpServletRequest request) {

        List<Catalogue> catalogueDetailslist = libraryService.findCatalogueByRecordIdentifier(checkinandoutlog.getRecordIdentifier());
        if (catalogueDetailslist.size() <= 0) {
            model.addAttribute("RecordIdentifierError", "Item with this Record Identifier does not exist in Catalogue");
            return new ModelAndView("LibrarianCheckIn", model);
        } else {

            List<Checkinandoutlog> checkinandoutlogDetailslist = libraryService.findCheckinandoutlogByRIwithCheckout(catalogueDetailslist.get(0).getRecordIdentifier());

            if (checkinandoutlogDetailslist.size() <= 0) {
                model.addAttribute("RecordIdentifierError", "Item with RecordIdentifier is not Ckecked Out!");
                return new ModelAndView("LibrarianCheckIn", model);

            } else {
                Catalogue catalogueDetails = catalogueDetailslist.get(0);

                String booktitle = catalogueDetails.getTitle();

                String bookdetails = catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                        + "," + catalogueDetails.getPublishers();

                // List<Checkinandoutlog> checkinandoutlogDetailslist = libraryService.findCheckinandoutlogByRIwithCheckout(catalogueDetails.getRecordIdentifier());

                Checkinandoutlog checkinandoutlogDetails = checkinandoutlogDetailslist.get(0);

                String borrowerdetails = null;

                List<Users> usersDetailsList = usersService.findUsersByUsername(checkinandoutlogDetails.getBorrowerUsername());

                Users usersdetails = usersDetailsList.get(0);

                if (usersdetails.getUsertype().equals("STAFF")) {

                    List<Staff> staffdetailsList = staffService.findStaffByUserid(checkinandoutlogDetails.getBorrowerUsername());

                    borrowerdetails = staffdetailsList.get(0).getFirstname() + "," + staffdetailsList.get(0).getLastname() + ","
                            + staffdetailsList.get(0).getCurrentDesignation() + "," + staffdetailsList.get(0).getDepartment();
                } else if (usersdetails.getUsertype().equals("STUDENT")) {

                    List<Student> studentdetailsList = studentService.findStudentByUsername(checkinandoutlogDetails.getBorrowerUsername());

                    borrowerdetails = studentdetailsList.get(0).getFirstName() + "," + studentdetailsList.get(0).getLastName() + ","
                            + studentdetailsList.get(0).getCollegeRegistrationNumber() + "," + studentdetailsList.get(0).getParentsName();
                }

                String IssuedDate = checkinandoutlogDetails.getIssuedDate();

                Calendar c1 = Calendar.getInstance();
                // roll down the month
                c1.set(Integer.parseInt(IssuedDate.split("/")[2]),
                        Integer.parseInt(IssuedDate.split("/")[1]) - 1,
                        Integer.parseInt(IssuedDate.split("/")[0])); // Setting Calendert to Issuded Date 1999 jan 20

                c1.add(Calendar.DAY_OF_MONTH, 15); // Advancing 15 Days from Issued Date for finding Due date

                String DueDate = Integer.toString(c1.get(Calendar.DAY_OF_MONTH)) + "/"
                        + Integer.toString(c1.get(Calendar.MONTH) + 1) + "/"
                        + Integer.toString(c1.get(Calendar.YEAR));


                Date duedate = c1.getTime();
                // Get msec from each, and subtract.
                long diff = (new Date()).getTime() - duedate.getTime();
                double lateness;
                if (diff > 0.0) {
                    lateness = Math.rint((double) diff / (1000 * 60 * 60 * 24));
                } else {
                    lateness = 0.0;
                }

                String TotalFine = Double.toString(lateness * 4.0);

                model.addAttribute("checkinandoutlog", checkinandoutlog);
                model.addAttribute("booktitle", booktitle);
                model.addAttribute("bookdetails", bookdetails);
                model.addAttribute("borrowerdetails", borrowerdetails);
                model.addAttribute("IssuedDate", IssuedDate);
                model.addAttribute("DueDate", DueDate);
                model.addAttribute("TotalFine", TotalFine);
                model.addAttribute("recordIdentifier", checkinandoutlog.getRecordIdentifier());
                model.addAttribute("borrowerUsername", usersdetails.getUsername());

                return new ModelAndView("LibrarianCheckInConfirm", model);

            }
        }
    }

    @RequestMapping("/LibrariancheckInConfirmSuccess.htm")
    public ModelAndView LibrariancheckInConfirmSuccess(ModelMap model,
            HttpServletRequest request) {

        model.addAttribute("checkinandoutlog", request.getParameter("checkinandoutlog"));
        model.addAttribute("booktitle", request.getParameter("booktitle"));
        model.addAttribute("bookdetails", request.getParameter("bookdetails"));
        model.addAttribute("borrowerdetails", request.getParameter("borrowerdetails"));
        model.addAttribute("IssuedDate", request.getParameter("IssuedDate"));
        model.addAttribute("DueDate", request.getParameter("DueDate"));
        model.addAttribute("TotalFine", request.getParameter("TotalFine"));
        model.addAttribute("recordIdentifier", request.getParameter("recordIdentifier"));
        model.addAttribute("borrowerUsername", request.getParameter("borrowerUsername"));

        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");

        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        //   else {
        if (!isResponseCorrect) { //Capatcha is not correct

            model.addAttribute("formerror", "Capacth is Invalid");
            return new ModelAndView("LibrarianCheckInConfirm", model);
        } else {

            List<Catalogue> catalogueDetailsList = libraryService.findCatalogueByRecordIdentifier(request.getParameter("recordIdentifier").toString());

            Catalogue catalogueDetails = catalogueDetailsList.get(0);

            List<Checkinandoutlog> checkinandoutlogDetailsList = libraryService.findCheckinandoutlogByRIwithCheckout(catalogueDetails.getRecordIdentifier());

            Checkinandoutlog checkinandoutlog = checkinandoutlogDetailsList.get(0);



            Date currentDate = new Date();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

            //Date OrigainalDate = new Date(2010,5,18);
            checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());
            checkinandoutlog.setStatus("CheckIn");
            checkinandoutlog.setFinePaid(request.getParameter("TotalFine"));


            libraryService.saveCheckinandoutlog(checkinandoutlog);

            return new ModelAndView("LibrariancheckInConfirmSuccess", model);
        }

    }

    @RequestMapping(value = "/LibrariancheckInConfirmCancel.htm")
    public ModelAndView LibrariancheckInConfirmCancel(ModelMap modelMap) {
        Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
        modelMap.addAttribute("checkinandoutlog", checkinandoutlog);

        return new ModelAndView("LibrarianCheckIn", modelMap);

    }

    @RequestMapping("/LibrarianCheckInSearch.htm")
    public ModelAndView LibrarianCheckInSearch(ModelMap modelMap) {

        modelMap.addAttribute("checkinandoutlog", new Checkinandoutlog());

        return new ModelAndView("LibrarianCheckInSearch", modelMap);

    }

    @RequestMapping(value = "/LibrarianCheckInSearchResult.htm")
    public ModelAndView LibrarianCheckInSearchResult(HttpServletRequest request, ModelMap modelMap,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog) {

        request.getSession().setAttribute("checkinandoutlog_session", checkinandoutlog);
        modelMap.addAttribute("checkinandoutlog", new Checkinandoutlog());
        List<Checkinandoutlog> searchCheckinandoutlog = libraryService.searchCheckinandoutlog(checkinandoutlog.getBorrowerUsername());
        modelMap.addAttribute("searchCheckinandoutlog", searchCheckinandoutlog);


        return new ModelAndView("LibrarianCheckInSearchResult", modelMap);

    }

    @RequestMapping(value = "/LibrarianCheckInSearchResultCheckin.htm")
    public ModelAndView LibrarianCheckInSearchResultCheckin(
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog,
            BindingResult result, ModelMap model,
            HttpServletRequest request,
            @RequestParam("selection") int selection[]) throws Exception {

        String booktitle[] = new String[selection.length];
        String recordIdentifier[] = new String[selection.length];
        String bookdetails[] = new String[selection.length];
        //String borrowerdetails;
        String borrowerdetails = null;
        String IssuedDate[] = new String[selection.length];
        String DueDate[] = new String[selection.length];
        String TotalFine[] = new String[selection.length];
        String BorrowerUsername = null;

        for (int j = 0; j < selection.length; j++) {
            if (selection[j] != 0) {

                checkinandoutlog.setId(selection[j]);
                List<Checkinandoutlog> checkinandoutlogDetailsList = libraryService.findCheckinandoutlogById(selection[j]);

                Checkinandoutlog checkinandoutlogDetails = checkinandoutlogDetailsList.get(0);
                BorrowerUsername = checkinandoutlogDetails.getBorrowerUsername();

                List<Catalogue> catalogueDetailsList = libraryService.findCatalogueByRecordIdentifier(checkinandoutlogDetails.getRecordIdentifier());

                Catalogue catalogueDetails = catalogueDetailsList.get(0);

                booktitle[j] = catalogueDetails.getTitle();

                bookdetails[j] = catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                        + "," + catalogueDetails.getPublishers();

                recordIdentifier[j] = checkinandoutlogDetails.getRecordIdentifier();


                IssuedDate[j] = checkinandoutlogDetails.getIssuedDate();

                Calendar c1 = Calendar.getInstance();
                // roll down the month
                c1.set(Integer.parseInt(IssuedDate[j].split("/")[2]),
                        Integer.parseInt(IssuedDate[j].split("/")[1]) - 1,
                        Integer.parseInt(IssuedDate[j].split("/")[0])); // 1999 jan 20

                c1.add(Calendar.DAY_OF_MONTH, 15);
                //c1.getTime()

                DueDate[j] = Integer.toString(c1.get(Calendar.DAY_OF_MONTH)) + "/"
                        + Integer.toString(c1.get(Calendar.MONTH) + 1) + "/"
                        + Integer.toString(c1.get(Calendar.YEAR));

                Date duedate = c1.getTime();
                Date today = new Date();
                // Get msec from each, and subtract.
                long diff = today.getTime() - duedate.getTime();
                double lateness;
                if (diff > 0) {
                    lateness = Math.rint((double) diff / (1000 * 60 * 60 * 24));
                } else {
                    lateness = 0;
                }

                TotalFine[j] = Double.toString(lateness * 4.0);
            }
        }

        List<Users> usersDetailsList = usersService.findUsersByUsername(BorrowerUsername);

        Users usersdetails = usersDetailsList.get(0);

        if (usersdetails.getUsertype().equals("STAFF")) {

            List<Staff> staffdetailsList = staffService.findStaffByUserid(BorrowerUsername);

            borrowerdetails = staffdetailsList.get(0).getFirstname() + "," + staffdetailsList.get(0).getLastname() + ","
                    + staffdetailsList.get(0).getCurrentDesignation() + "," + staffdetailsList.get(0).getDepartment();
        } else if (usersdetails.getUsertype().equals("STUDENT")) {

            List<Student> studentdetailsList = studentService.findStudentByUsername(BorrowerUsername);

            borrowerdetails = studentdetailsList.get(0).getFirstName() + "," + studentdetailsList.get(0).getLastName() + ","
                    + studentdetailsList.get(0).getCollegeRegistrationNumber() + "," + studentdetailsList.get(0).getParentsName();
        }


        String borrowerUsername = usersdetails.getUsername();

        model.addAttribute("booksselected", selection.length);
        model.addAttribute("borrowerUsername", borrowerUsername);

        model.addAttribute("booktitle", booktitle);
        model.addAttribute("recordIdentifier", recordIdentifier);
        model.addAttribute("bookdetails", bookdetails);
        model.addAttribute("borrowerdetails", borrowerdetails);
        model.addAttribute("IssuedDate", IssuedDate);
        model.addAttribute("DueDate", DueDate);
        model.addAttribute("TotalFine", TotalFine);

        request.getSession().setAttribute("selection", selection);
        request.getSession().setAttribute("booktitle", booktitle);
        request.getSession().setAttribute("recordIdentifier", recordIdentifier);
        request.getSession().setAttribute("bookdetails", bookdetails);
        request.getSession().setAttribute("borrowerdetails", borrowerdetails);
        request.getSession().setAttribute("IssuedDate", IssuedDate);
        request.getSession().setAttribute("DueDate", DueDate);
        request.getSession().setAttribute("TotalFine", TotalFine);

        return new ModelAndView("LibrarianCheckInSearchResultCheckin", model);
    }

    @RequestMapping(value = "/LibrarianCheckInSearchResultCancel.htm")
    public ModelAndView LibrarianCheckInSearchResultCancel(ModelMap modelMap) {
        Checkinandoutlog checkinandoutlog = new Checkinandoutlog();
        modelMap.addAttribute("checkinandoutlog", checkinandoutlog);

        return new ModelAndView("LibrarianCheckInSearch", modelMap);

    }

    @RequestMapping(value = "/SearchResultCheckinConfirm.htm")
    public ModelAndView LibrarianCheckInSearchResultCheckinConfirm(ModelMap model,
            HttpServletRequest request) throws Exception {

        int selection[] = (int[]) request.getSession().getAttribute("selection");
        String TotalFine[] = (String[]) request.getSession().getAttribute("TotalFine");

        model.addAttribute("booksselected", selection.length);
        model.addAttribute("booktitle", request.getSession().getAttribute("booktitle"));
        model.addAttribute("recordIdentifier", request.getSession().getAttribute("recordIdentifier"));
        model.addAttribute("bookdetails", request.getSession().getAttribute("bookdetails"));
        model.addAttribute("borrowerdetails", request.getSession().getAttribute("borrowerdetails"));
        model.addAttribute("IssuedDate", request.getSession().getAttribute("IssuedDate"));
        model.addAttribute("DueDate", request.getSession().getAttribute("DueDate"));
        model.addAttribute("TotalFine", request.getSession().getAttribute("TotalFine"));
        model.addAttribute("selection", selection);
        model.addAttribute("borrowerUsername", request.getSession().getAttribute("borrowerUsername"));

        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");

        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        if (!isResponseCorrect) { //Capatcha is not correct
            libraryService.formAddOptionvalues(model);
            model.addAttribute("formerror", "Capacth is Invalid");
            return new ModelAndView("LibrarianCheckInSearchResultCheckin", model);
        } else {
            for (int j = 0; j < selection.length; j++) {

                if (selection[j] != 0) {

                    List<Checkinandoutlog> checkinandoutlogDetailsList =
                            libraryService.findCheckinandoutlogById(selection[j]);

                    Checkinandoutlog checkinandoutlog = checkinandoutlogDetailsList.get(0);

                    Date currentDate = new Date();
                    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

                    checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());
                    checkinandoutlog.setStatus("CheckIn");
                    checkinandoutlog.setFinePaid(TotalFine[j]);

                    libraryService.saveCheckinandoutlog(checkinandoutlog);
                }
            }

            return new ModelAndView("SearchResultCheckinConfirm", model);
        }
    }


    @RequestMapping(value = "/SearchResultCheckinCancel.htm")
    public ModelAndView SearchResultCheckinCancel(HttpServletRequest request, ModelMap modelMap) {

        Checkinandoutlog checkinandoutlog = (Checkinandoutlog) request.getSession().getAttribute("checkinandoutlog_session");
        modelMap.addAttribute("checkinandoutlog", new Checkinandoutlog());
        List<Checkinandoutlog> searchCheckinandoutlog = libraryService.searchCheckinandoutlog(checkinandoutlog.getBorrowerUsername());
        modelMap.addAttribute("searchCheckinandoutlog", searchCheckinandoutlog);

        return new ModelAndView("LibrarianCheckInSearchResult", modelMap);

    }
}






