/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.suman.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.annotation.RequestParam;

import com.suman.domain.Staff;
import com.suman.domain.Users;
import com.suman.domain.LeaveApplication;
import com.suman.domain.LeaveSummary;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.text.DateFormat;

import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;

import com.suman.biometric.AtdRecord;
import com.suman.biometric.AtdRecordId;
import com.suman.biometric.HrEmployee;


import org.apache.log4j.Logger;
import org.apache.commons.lang.RandomStringUtils;

import com.suman.service.StaffService;
import com.suman.service.AttendenceService;

import com.suman.security.UsersService;
import com.suman.validator.StaffValidator;

import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.Authentication;

import com.suman.email.EmailSender;
import com.suman.email.EmailDetails;
import java.text.SimpleDateFormat;

@Controller
public class AttendenceMgmtController {

    private StaffService staffService;
    private AttendenceService attendenceService;
    private StaffValidator staffValidator;
    private UsersService usersService;
    private GenericManageableCaptchaService captchaService;
    private Logger log = Logger.getLogger(AdminStudentController.class);
    private EmailSender emailSender;

    @Autowired
    public AttendenceMgmtController(AttendenceService attendenceService, StaffService staffService, StaffValidator staffValidator, GenericManageableCaptchaService captchaService, UsersService usersService, EmailSender emailSender) {
        this.attendenceService = attendenceService;
        this.staffService = staffService;
        this.staffValidator = staffValidator;
        this.captchaService = captchaService;
        this.usersService = usersService;
        this.emailSender = emailSender;

    }

    @RequestMapping(value = "/biometricProfileSearch.htm")
    public ModelAndView biometricProfileSearch(ModelMap modelMap) {
        modelMap.addAttribute("employee", new HrEmployee());
        return new ModelAndView("admin/attendenceMgmt/biometricProfileSearch", modelMap);
    }

    @RequestMapping(value = "/biometricProfileSearchResults.htm")
    public ModelAndView biometricProfileSearchResults(ModelMap modelMap, @ModelAttribute("employee") HrEmployee employee) {

        if (employee.getIdentityId().equals("") && employee.getCardId().equals("")
                && employee.getDeptId().equals("") && employee.getEmplName().equals("")) {
            modelMap.addAttribute("employee", new HrEmployee());
            modelMap.addAttribute("errorMsg", "Search is empty! <br> Please enter at least one Keyword<br>");
            return new ModelAndView("admin/attendenceMgmt/biometricProfileSearch", modelMap);
        } else {
            List<HrEmployee> EmployeeList = attendenceService.searchEmployeesList(employee);

            modelMap.addAttribute("employee", new HrEmployee());
            modelMap.addAttribute("employeeList", EmployeeList);
            return new ModelAndView("admin/attendenceMgmt/biometricProfileSearchResults", modelMap);
        }
    }

    @RequestMapping(value = "/biometricProfileUpdation.htm")
    public ModelAndView biometricProfileUpdation(ModelMap modelMap,
            @RequestParam("employeePrimKey") String selection,
            HttpServletRequest request) {

        List<HrEmployee> EmployeeList = attendenceService.findEmployeeByEmplId(selection);
        modelMap.addAttribute("employee", EmployeeList.get(0));

        return new ModelAndView("admin/attendenceMgmt/biometricProfileUpdation", modelMap);
    }

    @RequestMapping(value = "/biometricProfileUpdationDone.htm")
    public ModelAndView biometricProfileUpdationDone(ModelMap modelMap,
            @ModelAttribute("employee") HrEmployee employee) {

        attendenceService.updateEmployee(employee);
        modelMap.addAttribute("employee", employee);
        return new ModelAndView("admin/attendenceMgmt/biometricProfileUpdationDone", modelMap);
    }

    @RequestMapping(value = "/AttendenceProcessing.htm")
    public ModelAndView attendenceProcessing(ModelMap modelMap) {

        List<AtdRecord> TodaysAttendence = attendenceService.findAttendence("2010-06-16");
        List<HrEmployee> EmployeeList = attendenceService.findEmployeesList();


        String EmployeeNames[] = new String[TodaysAttendence.size()];

        for (int i = 0; i < TodaysAttendence.size(); i++) {
            for (int j = 0; j < EmployeeList.size(); j++) {
                if (EmployeeList.get(j).getEmplId().trim().equals(TodaysAttendence.get(i).getId().getEmplId().trim())) {
                    EmployeeNames[i] = (EmployeeList.get(j).getEmplName());
                }
            }
        }

        modelMap.addAttribute("employeeNames", EmployeeNames);

        modelMap.addAttribute("atdRecord", new AtdRecord());
        modelMap.addAttribute("TodaysAttendence", TodaysAttendence);
        return new ModelAndView("admin/attendenceMgmt/attendenceProcessing", modelMap);
    }
}
