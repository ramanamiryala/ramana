package com.suman.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.RequestParam;

import com.suman.domain.Users;
import com.suman.domain.Catalogue;
import com.suman.domain.Checkinandoutlog;
import com.suman.domain.Staff;
import com.suman.domain.Student;

import java.text.DateFormat;
import java.util.*;

import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.Authentication;


import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;

import org.apache.log4j.Logger;

import com.suman.service.LibraryService;
import com.suman.service.BorrowerLibraryService;
import com.suman.security.UsersService;
import com.suman.service.StaffService;
import com.suman.service.StudentService;
import com.suman.validator.CatalogueValidator;

import com.suman.email.EmailSender;
import java.text.SimpleDateFormat;

@Controller
public class BorrowerLibraryMgmtController {

    private UsersService usersService;
    private CatalogueValidator catalogueValidator;
    private BorrowerLibraryService borrowerLibraryService;
    private StaffService staffService;
    private StudentService studentService;
    private GenericManageableCaptchaService captchaService;
    private Logger log = Logger.getLogger(LibraryMgmtController.class);
    private EmailSender emailSender;

    @Autowired
    public BorrowerLibraryMgmtController(GenericManageableCaptchaService captchaService, 
            UsersService usersService, EmailSender emailSender, CatalogueValidator catalogueValidator,
            StaffService staffService, StudentService studentService,BorrowerLibraryService borrowerLibraryService) {
        
        this.captchaService = captchaService;
        this.usersService = usersService;
        this.emailSender = emailSender;
        this.catalogueValidator = catalogueValidator;
        this.staffService = staffService;
        this.studentService = studentService;
        this.borrowerLibraryService = borrowerLibraryService;
    }



     @RequestMapping("/BorrowerSearch.htm")
    public ModelAndView BorrowerSearch(ModelMap modelMap) {

        modelMap.addAttribute("catalogue1", new Catalogue());
        borrowerLibraryService.formAddOptionvalues(modelMap);
        return new ModelAndView("BorrowerSearch", modelMap);

    }


     
    @RequestMapping(value = "/BorrowerSearchResults.htm")
    public ModelAndView BorrowerSearchResults(HttpServletRequest request, ModelMap modelMap,
            @ModelAttribute("catalogue1") Catalogue catalogue1) {

        request.getSession().setAttribute("catalogue1_session", catalogue1);
        modelMap.addAttribute("catalogue1", new Catalogue());
        catalogue1.setYearofPublication(request.getParameter("yearofPublication"));
        List<Catalogue> searchCatalogue = borrowerLibraryService.searchCatalogue(catalogue1);
        
        if (request.getParameter("typeofrecord").toString().equals("")
                && request.getParameter("title").toString().equals("")
                && request.getParameter("author").toString().equals("")
                && request.getParameter("yearofPublication").toString().equals("")
                && request.getParameter("subjectCategory").toString().equals("")
                && request.getParameter("keywords").toString().equals("")) {
            return new ModelAndView("BorrowerSearch", modelMap);
        } else {

            int sizeOfCataloguetItems = searchCatalogue.size();

            //String searchCatalogue[] = new String[sizeOfCataloguetItems];
            String Availability[] = new String[sizeOfCataloguetItems];
            String IssuedDate[] = new String[sizeOfCataloguetItems];
            String DueDate[] = new String[sizeOfCataloguetItems];
            String borrowerdetails[] = new String[sizeOfCataloguetItems];

            for (int j = 0; j < sizeOfCataloguetItems; j++) {

                List<Checkinandoutlog> checkinandoutlogList = borrowerLibraryService.findCheckinandoutlogByRecordIdentifier(searchCatalogue.get(j).getRecordIdentifier());
                //tring Availability = null;
                if (checkinandoutlogList.size() > 0) {
                    IssuedDate[j] = checkinandoutlogList.get(0).getIssuedDate();
                    Calendar c1 = Calendar.getInstance();
                    // roll down the month
                    c1.set(Integer.parseInt(IssuedDate[j].split("/")[2]),
                            Integer.parseInt(IssuedDate[j].split("/")[1]) - 1,
                            Integer.parseInt(IssuedDate[j].split("/")[0])); // Setting Calendert to Issuded Date 1999 jan 20

                    c1.add(Calendar.DAY_OF_MONTH, 15); // Advancing 15 Days from Issued Date for finding Due date

                     DueDate[j] = Integer.toString(c1.get(Calendar.DAY_OF_MONTH)) + "/"
                            + Integer.toString(c1.get(Calendar.MONTH) + 1) + "/"
                            + Integer.toString(c1.get(Calendar.YEAR));
                    Availability[j] = DueDate[j];

                    List<Users> usersDetailsList = usersService.findUsersByUsername(checkinandoutlogList.get(0).getBorrowerUsername());

                Users usersdetails = usersDetailsList.get(0);

                if (usersdetails.getUsertype().equals("STAFF")) {

                    List<Staff> staffdetailsList = staffService.findStaffByUserid(checkinandoutlogList.get(0).getBorrowerUsername());

                    borrowerdetails[j] = staffdetailsList.get(0).getFirstname() + "," + staffdetailsList.get(0).getLastname() + ","
                            + staffdetailsList.get(0).getCurrentDesignation() + "," + staffdetailsList.get(0).getDepartment() +","
                            +staffdetailsList.get(0).getEmailid();
                } else if (usersdetails.getUsertype().equals("STUDENT")) {

                    List<Student> studentdetailsList = studentService.findStudentByUsername(checkinandoutlogList.get(0).getBorrowerUsername());

                    borrowerdetails[j] = studentdetailsList.get(0).getFirstName() + "," + studentdetailsList.get(0).getLastName() + ","
                            + studentdetailsList.get(0).getCollegeRegistrationNumber() + "," + studentdetailsList.get(0).getCourseJoined() + ","
                            +studentdetailsList.get(0).getEmailId();
                }

                } else{

                    Availability[j] = "Available Now";
                    borrowerdetails [j]="";
                }
            }

            modelMap.addAttribute("Availability", Availability);
            modelMap.addAttribute("borrowerdetails",borrowerdetails);
            modelMap.addAttribute("searchCatalogue", searchCatalogue);
            modelMap.addAttribute("sizeOfCataloguetItems",sizeOfCataloguetItems);
            borrowerLibraryService.formAddOptionvalues(modelMap);


            request.getSession().setAttribute("Availability",Availability);
            request.getSession().setAttribute("borrowerdetails",borrowerdetails);

            return new ModelAndView("BorrowerSearchResults", modelMap);
        }
    }

      
    @RequestMapping(value = "/LibraryAccountDetails.htm")
    public ModelAndView LibrarianCheckInSearchResult(HttpServletRequest request, ModelMap model,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog) {


        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();


        //request.getSession().setAttribute("checkinandoutlog_session", checkinandoutlog);
        model.addAttribute("checkinandoutlog", new Checkinandoutlog());
        List<Checkinandoutlog> searchCheckinandoutlog = borrowerLibraryService.searchCheckinandoutlog(username);

        int sizeOfChekedOutItems = searchCheckinandoutlog.size();

        String bookdetails[] = new String[sizeOfChekedOutItems];
        String IssuedDate[] = new String[sizeOfChekedOutItems];
        String DueDate[] = new String[sizeOfChekedOutItems];
        String TotalFine[] = new String[sizeOfChekedOutItems];
        String issueddate[] = new String[sizeOfChekedOutItems];

        for (int j = 0; j < sizeOfChekedOutItems; j++) {

            //Checkinandoutlog checkinandoutlogDetails = searchCheckinandoutlog.get(0);

            List<Catalogue> catalogueDetailslist = borrowerLibraryService.findCatalogueByRecordIdentifier(searchCheckinandoutlog.get(j).getRecordIdentifier());

            Catalogue catalogueDetails = catalogueDetailslist.get(0);

            bookdetails[j] = catalogueDetails.getTitle() + "," + catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                    + "," + catalogueDetails.getPublishers();

             IssuedDate[j] = searchCheckinandoutlog.get(j).getIssuedDate();


            Calendar c1 = Calendar.getInstance();
            // roll down the month
            c1.set(Integer.parseInt(IssuedDate[j].split("/")[2]),
                    Integer.parseInt(IssuedDate[j].split("/")[1]) - 1,
                    Integer.parseInt(IssuedDate[j].split("/")[0])); // Setting Calendert to Issuded Date 1999 jan 20

            c1.add(Calendar.DAY_OF_MONTH, 15); // Advancing 15 Days from Issued Date for finding Due date

            DueDate[j] = Integer.toString(c1.get(Calendar.DAY_OF_MONTH)) + "/"
                    + Integer.toString(c1.get(Calendar.MONTH) + 1) + "/"
                    + Integer.toString(c1.get(Calendar.YEAR));

            Date duedate = c1.getTime();

            // Get msec from each, and subtract.
            long diff = (new Date()).getTime() - duedate.getTime();
            double lateness;
            if (diff > 0.0) {
                lateness = Math.rint((double) diff / (1000 * 60 * 60 * 24));
            } else {
                lateness = 0.0;
            }

            TotalFine[j] = Double.toString(lateness * 4.0);

            issueddate[j] = searchCheckinandoutlog.get(j).getIssuedDate() + ";" + searchCheckinandoutlog.get(j).getIssuedTime();
        }

        model.addAttribute("bookdetails", bookdetails);
        model.addAttribute("issueddate", issueddate);
        model.addAttribute("DueDate", DueDate);
        model.addAttribute("TotalFine", TotalFine);
        model.addAttribute("sizeOfChekedOutItems", sizeOfChekedOutItems);

        request.getSession().setAttribute("bookdetails",bookdetails);
        request.getSession().setAttribute("issueddate",issueddate);
        request.getSession().setAttribute("DueDate",DueDate);
        request.getSession().setAttribute("TotalFine",TotalFine);
        request.getSession().setAttribute("sizeOfChekedOutItems",sizeOfChekedOutItems);

        return new ModelAndView("LibraryAccountDetails", model);

    }


     @RequestMapping(value = "/BorrowersRenewal.htm")
    public ModelAndView BorrowersRenewal(HttpServletRequest request, ModelMap model,
            @ModelAttribute("checkinandoutlog") Checkinandoutlog checkinandoutlog) {


        Authentication userauth = SecurityContextHolder.getContext().getAuthentication();
        String username = userauth.getPrincipal().toString();


        //request.getSession().setAttribute("checkinandoutlog_session", checkinandoutlog);
        model.addAttribute("checkinandoutlog", new Checkinandoutlog());
        List<Checkinandoutlog> searchCheckinandoutlog = borrowerLibraryService.searchCheckinandoutlog(username);

        int sizeOfChekedOutItems = searchCheckinandoutlog.size();

        String bookdetails[] = new String[sizeOfChekedOutItems];
        String IssuedDate[] = new String[sizeOfChekedOutItems];
        String DueDate[] = new String[sizeOfChekedOutItems];
        String TotalFine[] = new String[sizeOfChekedOutItems];
        String issueddate[] = new String[sizeOfChekedOutItems];

        for (int j = 0; j < sizeOfChekedOutItems; j++) {

            //Checkinandoutlog checkinandoutlogDetails = searchCheckinandoutlog.get(0);

            List<Catalogue> catalogueDetailslist = borrowerLibraryService.findCatalogueByRecordIdentifier(searchCheckinandoutlog.get(j).getRecordIdentifier());

            Catalogue catalogueDetails = catalogueDetailslist.get(0);

            bookdetails[j] = catalogueDetails.getTitle() + "," + catalogueDetails.getAuthor() + "," + catalogueDetails.getYearofPublication()
                    + "," + catalogueDetails.getPublishers();

             IssuedDate[j] = searchCheckinandoutlog.get(j).getIssuedDate();


            Calendar c1 = Calendar.getInstance();
            // roll down the month
            c1.set(Integer.parseInt(IssuedDate[j].split("/")[2]),
                    Integer.parseInt(IssuedDate[j].split("/")[1]) - 1,
                    Integer.parseInt(IssuedDate[j].split("/")[0])); // Setting Calendert to Issuded Date 1999 jan 20

            c1.add(Calendar.DAY_OF_MONTH, 15); // Advancing 15 Days from Issued Date for finding Due date

            DueDate[j] = Integer.toString(c1.get(Calendar.DAY_OF_MONTH)) + "/"
                    + Integer.toString(c1.get(Calendar.MONTH) + 1) + "/"
                    + Integer.toString(c1.get(Calendar.YEAR));

            Date duedate = c1.getTime();

            // Get msec from each, and subtract.
            long diff = (new Date()).getTime() - duedate.getTime();
            double lateness;
            if (diff > 0.0) {
                lateness = Math.rint((double) diff / (1000 * 60 * 60 * 24));
            } else {
                lateness = 0.0;
            }

            TotalFine[j] = Double.toString(lateness * 4.0);

            issueddate[j] = searchCheckinandoutlog.get(j).getIssuedDate() + ";" + searchCheckinandoutlog.get(j).getIssuedTime();
        }

        model.addAttribute("bookdetails", bookdetails);
        model.addAttribute("issueddate", issueddate);
        model.addAttribute("DueDate", DueDate);
        model.addAttribute("TotalFine", TotalFine);
        model.addAttribute("sizeOfChekedOutItems",sizeOfChekedOutItems);

        request.getSession().setAttribute("bookdetails",bookdetails);
        request.getSession().setAttribute("issueddate",issueddate);
        request.getSession().setAttribute("DueDate",DueDate);
        request.getSession().setAttribute("TotalFine",TotalFine);
        request.getSession().setAttribute("sizeOfChekedOutItems",sizeOfChekedOutItems);
        return new ModelAndView("BorrowersRenewal", model);
    }


    @RequestMapping(value = "/BorrowersRenewalSuccess.htm")
    public ModelAndView BorrowersRenewalSuccess(HttpServletRequest request, ModelMap model) {

        int selection[] = (int[]) request.getSession().getAttribute("selection");
       String TotalFine[] = (String[]) request.getSession().getAttribute("TotalFine");
       //String IssuedDate[]=(String[]) request.getSession().getAttribute("IssuedDate");

        model.addAttribute("sizeOfChekedOutItems", selection);
        model.addAttribute("bookdetails", request.getSession().getAttribute("bookdetails"));
        model.addAttribute("IssuedDate", request.getSession().getAttribute("IssuedDate"));
       // model.addAttribute("DueDate", request.getSession().getAttribute("DueDate"));
        model.addAttribute("borrowerdetails", request.getSession().getAttribute("borrowerdetails"));
        model.addAttribute("TotalFine", request.getSession().getAttribute("TotalFine"));

        String DueDate[]=null;
        String StatusDate[]=null;

        for (int j = 0; j < selection.length; j++) {
            if (selection[j] != 0) {

                List<Checkinandoutlog> checkinandoutlogDetailsList =
                        borrowerLibraryService.findCheckinandoutlogById(selection[j]);
                Checkinandoutlog checkinandoutlog = checkinandoutlogDetailsList.get(0);

                Date currentDate = new Date();
                    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

                    checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());

                    StatusDate[j]=checkinandoutlog.getStatusDate();
                     Calendar c1 = Calendar.getInstance();
            // roll down the month
            c1.set(Integer.parseInt(StatusDate[j].split("/")[2]),
                    Integer.parseInt(StatusDate[j].split("/")[1]) - 1,
                    Integer.parseInt(StatusDate[j].split("/")[0])); // Setting Calendert to Issuded Date 1999 jan 20

            c1.add(Calendar.DAY_OF_MONTH, 15); // Advancing 15 Days from Issued Date for finding Due date

            DueDate[j] = Integer.toString(c1.get(Calendar.DAY_OF_MONTH)) + "/"
                    + Integer.toString(c1.get(Calendar.MONTH) + 1) + "/"
                    + Integer.toString(c1.get(Calendar.YEAR));

            Date duedate = c1.getTime();

            // Get msec from each, and subtract.
            long diff = (new Date()).getTime() - duedate.getTime();
            double lateness;
            if (diff > 0.0) {
                lateness = Math.rint((double) diff / (1000 * 60 * 60 * 24));
            } else {
                lateness = 0.0;
            }

                TotalFine[j] = Double.toString(lateness * 4.0);

                checkinandoutlog.setStatusDate(dateFormat.format(currentDate).toString());
                checkinandoutlog.setStatus("CheckOut");
               // checkinandoutlog.setIssuedDate(IssuedDate[j]);
                checkinandoutlog.setFinePaid(TotalFine[j]);
                checkinandoutlog.setRemarks("Renewal");

                 if (checkinandoutlog.getRemarks().equals("Renewal")) {
                    int renewalscount = checkinandoutlog.getRenewal()+ 1;
                     checkinandoutlog.setRenewal(renewalscount);
                }

                borrowerLibraryService.saveCheckinandoutlog(checkinandoutlog);
            }
        }

        return new ModelAndView("BorrowersRenewalSuccess", model);

    }


       @RequestMapping("/OnlineReservation.htm")
    public ModelAndView OnlineReservation(ModelMap modelMap) {

        modelMap.addAttribute("catalogue1", new Catalogue());
        borrowerLibraryService.formAddOptionvalues(modelMap);
        return new ModelAndView("OnlineReservation", modelMap);

    }

        @RequestMapping(value = "/OnlineReservationResults.htm")
    public ModelAndView OnlineReservationSearchResults(HttpServletRequest request, ModelMap modelMap,
            @ModelAttribute("catalogue1") Catalogue catalogue1) {

        request.getSession().setAttribute("catalogue1_session", catalogue1);
        modelMap.addAttribute("catalogue1", new Catalogue());
        catalogue1.setYearofPublication(request.getParameter("yearofPublication"));
        List<Catalogue> searchCatalogue = borrowerLibraryService.searchCatalogue(catalogue1);

        if (request.getParameter("typeofrecord").toString().equals("")
                && request.getParameter("title").toString().equals("")
                && request.getParameter("author").toString().equals("")
                && request.getParameter("yearofPublication").toString().equals("")
                && request.getParameter("subjectCategory").toString().equals("")
                && request.getParameter("keywords").toString().equals("")) {
            return new ModelAndView("BorrowerSearch", modelMap);
        } else {

            int sizeOfCataloguetItems = searchCatalogue.size();

            //String searchCatalogue[] = new String[sizeOfCataloguetItems];
            String Availability[] = new String[sizeOfCataloguetItems];
            String IssuedDate[] = new String[sizeOfCataloguetItems];
            String DueDate[] = new String[sizeOfCataloguetItems];
            String borrowerdetails[] = new String[sizeOfCataloguetItems];

            for (int j = 0; j < sizeOfCataloguetItems; j++) {

                List<Checkinandoutlog> checkinandoutlogList = borrowerLibraryService.findCheckinandoutlogByRecordIdentifier(searchCatalogue.get(j).getRecordIdentifier());
                //tring Availability = null;
                if (checkinandoutlogList.size() > 0) {
                    IssuedDate[j] = checkinandoutlogList.get(0).getIssuedDate();
                    Calendar c1 = Calendar.getInstance();
                    // roll down the month
                    c1.set(Integer.parseInt(IssuedDate[j].split("/")[2]),
                            Integer.parseInt(IssuedDate[j].split("/")[1]) - 1,
                            Integer.parseInt(IssuedDate[j].split("/")[0])); // Setting Calendert to Issuded Date 1999 jan 20

                    c1.add(Calendar.DAY_OF_MONTH, 15); // Advancing 15 Days from Issued Date for finding Due date

                     DueDate[j] = Integer.toString(c1.get(Calendar.DAY_OF_MONTH)) + "/"
                            + Integer.toString(c1.get(Calendar.MONTH) + 1) + "/"
                            + Integer.toString(c1.get(Calendar.YEAR));
                    Availability[j] = DueDate[j];

                    List<Users> usersDetailsList = usersService.findUsersByUsername(checkinandoutlogList.get(0).getBorrowerUsername());

                Users usersdetails = usersDetailsList.get(0);

                if (usersdetails.getUsertype().equals("STAFF")) {

                    List<Staff> staffdetailsList = staffService.findStaffByUserid(checkinandoutlogList.get(0).getBorrowerUsername());

                    borrowerdetails[j] = staffdetailsList.get(0).getFirstname() + "," + staffdetailsList.get(0).getLastname() + ","
                            + staffdetailsList.get(0).getCurrentDesignation() + "," + staffdetailsList.get(0).getDepartment() +","
                            +staffdetailsList.get(0).getEmailid();
                } else if (usersdetails.getUsertype().equals("STUDENT")) {

                    List<Student> studentdetailsList = studentService.findStudentByUsername(checkinandoutlogList.get(0).getBorrowerUsername());

                    borrowerdetails[j] = studentdetailsList.get(0).getFirstName() + "," + studentdetailsList.get(0).getLastName() + ","
                            + studentdetailsList.get(0).getCollegeRegistrationNumber() + "," + studentdetailsList.get(0).getCourseJoined() + ","
                            +studentdetailsList.get(0).getEmailId();
                }

                } else{

                    Availability[j] = "Available Now";
                    borrowerdetails [j]="";
                }
            }

            modelMap.addAttribute("Availability", Availability);
            modelMap.addAttribute("borrowerdetails",borrowerdetails);
            modelMap.addAttribute("searchCatalogue", searchCatalogue);
            modelMap.addAttribute("sizeOfCataloguetItems",sizeOfCataloguetItems);
            borrowerLibraryService.formAddOptionvalues(modelMap);


            request.getSession().setAttribute("Availability",Availability);
            request.getSession().setAttribute("borrowerdetails",borrowerdetails);

            return new ModelAndView("OnlineReservationResults", modelMap);
        }
    }







}
