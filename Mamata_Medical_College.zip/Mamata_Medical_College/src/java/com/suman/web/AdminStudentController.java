package com.suman.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.web.bind.support.SessionStatus;

import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.annotation.RequestParam;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.jsp.PageContext;

import com.suman.domain.Student;
import com.suman.domain.StdBaseProfile;
import com.suman.domain.Users;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import javax.imageio.ImageIO;


import org.springframework.web.multipart.MultipartFile;
//import org.springframework.web.multipart.commons
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.FileItem;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.util.List;
import java.util.ArrayList;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.Calendar;
import org.springframework.web.multipart.commons.CommonsFileUploadSupport;
import org.apache.commons.fileupload.FileUpload;
import java.io.BufferedOutputStream;


import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;

import com.suman.service.StudentService;
import com.suman.security.UsersService;
import com.suman.validator.StudentValidator;

import org.apache.log4j.Logger;
import org.apache.commons.lang.RandomStringUtils;
import org.springframework.core.io.ClassPathResource;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;


import javax.servlet.ServletContext;

@Controller
public class AdminStudentController {

    private StudentService studentService;
    private StudentValidator studentValidator;
    private GenericManageableCaptchaService captchaService;
    private UsersService usersService;
    private Logger log = Logger.getLogger(AdminStudentController.class);

    @Autowired
    public AdminStudentController(GenericManageableCaptchaService captchaService, StudentService studentService,
            StudentValidator studentValidator, UsersService usersService) {
        this.studentService = studentService;
        this.studentValidator = studentValidator;
        this.captchaService = captchaService;
        this.usersService = usersService;
    }

    @RequestMapping("/image.htm")
    public ModelAndView viewPhoto(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) throws IOException {
        // MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        //MultipartFile file1 = multipartRequest.getFile("file1");

        FileItem fileitem;
        DiskFileItemFactory dif = new DiskFileItemFactory();
        dif.setSizeThreshold(20000);

        MultipartFile file1 = (MultipartFile) request.getSession().getAttribute("file1_sess");

        byte[] photo = file1.getBytes();
        response.setContentType(file1.getContentType());

        OutputStream os = response.getOutputStream();
        BufferedOutputStream bos = new BufferedOutputStream(os);
        bos.write(photo, 0, photo.length);
        bos.close();
        return null;

    }

    @RequestMapping("/AdminStdBaseProfileRegistration.htm")
    public ModelAndView submitStdBaseProfileRegistration(
            @ModelAttribute("stdBaseProfile") StdBaseProfile stdBaseProfile,
            BindingResult result,
            HttpServletRequest request,
            ModelMap modelMap) throws IOException {

        request.getSession().removeAttribute("file1_sess");
        request.getSession().removeAttribute("stdBaseProfile_sess");

        Calendar c1 = Calendar.getInstance();
        modelMap.addAttribute("currentyear", Integer.toString(c1.get(Calendar.YEAR)));
        modelMap.addAttribute("nextyear", Integer.toString(c1.get(Calendar.YEAR) + 1));
        modelMap.addAttribute("isimageuploaded", null);
        modelMap.addAttribute("userProfilePhotoExists", null);
        request.getSession().setAttribute("stdBaseProfile_sess", stdBaseProfile);

      
        studentService.formAddOptionvalues(modelMap);
        return new ModelAndView("admin/studentMgmt/baseProfileRegistration", modelMap);
    }

    @RequestMapping("/AdminStdBaseProfileRegistrationConfirm.htm")
    public ModelAndView submitStdBaseProfileRegistrationConfirm(
            @ModelAttribute("stdBaseProfile") StdBaseProfile stdBaseProfile,
            BindingResult result,
            HttpServletRequest request,
            @RequestParam(value = "register", required = false) Object register,
            @RequestParam(value = "photoUpload", required = false) Object photoUpload,
            ModelMap modelMap) throws IOException {

        studentService.formAddOptionvalues(modelMap);


        if (register != null) // If there is only photo uploading
        {

            stdBaseProfile.setJoiningAcademicYear(request.getParameter("fromYearAcademicYear") + "-" + request.getParameter("toYearAcademicYear"));

            if (stdBaseProfile.getUniversityRegistered().toString().equals("NO")) {
                stdBaseProfile.setCollegeRegistrationNumber(stdBaseProfile.getEmailId());
            }
            studentValidator.validateStdBaseProfile(stdBaseProfile, result);

            // CHECKING uniquness of EmailIds,Registration numbers and etc

            if (studentService.listStdBaseProfileByRegistraionNo(stdBaseProfile.getCollegeRegistrationNumber()).size() > 0) {
                result.rejectValue("collegeRegistrationNumber", "collegeRegistrationNumber.existsAlready");
            }


            if (usersService.userDetailsCheck(stdBaseProfile.getEmailId(), "emailid").size() > 0) {
                result.rejectValue("emailId", "emailId.exitsAlready");
            }

            if (usersService.userDetailsCheck(stdBaseProfile.getParentsEmailid(), "emailid").size() > 0) {
                result.rejectValue("parentsEmailid", "parentsEmailid.exitsAlready");
            }

            if (stdBaseProfile.getParentsEmailid().equals(stdBaseProfile.getEmailId())
                    && !stdBaseProfile.getParentsEmailid().equals("") && !stdBaseProfile.getEmailId().equals("")) {
                result.rejectValue("emailId", "emailIds.isSame");
                result.rejectValue("parentsEmailid", "emailIds.isSame");
            }


            if (usersService.userDetailsCheck(stdBaseProfile.getPhoneNumber(), "phonenumber").size() > 0) {
                result.rejectValue("phoneNumber", "phoneNumber.existsAlready");
            }

            if (usersService.userDetailsCheck(stdBaseProfile.getParentsPhoneNumber(), "phonenumber").size() > 0) {
                result.rejectValue("parentsPhoneNumber", "parentsPhoneNumber.existsAlready");
            }

            if (stdBaseProfile.getPhoneNumber().equals(stdBaseProfile.getParentsPhoneNumber())) {
                result.rejectValue("parentsPhoneNumber", "phoneNumbers.isSame");
                result.rejectValue("phoneNumber", "phoneNumbers.isSame");
            }

            if (result.hasErrors()) {
                //       studentService.formAddOptionvalues(modelMap);
                studentService.specialStdBaseProfileAtrributesMapping(modelMap, request, stdBaseProfile);
                return new ModelAndView("admin/studentMgmt/baseProfileRegistration", modelMap);
            } else {

                MultipartFile oldfile = (MultipartFile) request.getSession().getAttribute("file1_sess");

                MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
                MultipartFile file1 = multipartRequest.getFile("file1");

                if (file1.isEmpty() && oldfile == null) {
                    //         studentService.formAddOptionvalues(modelMap);
                    studentService.specialStdBaseProfileAtrributesMapping(modelMap, request, stdBaseProfile);
                    modelMap.addAttribute("fileerror", "File is Empty");
                    modelMap.addAttribute("isimageuploaded", null);

//                    modelMap.addAttribute("stdBaseProfile", stdBaseProfile_session);
                    return new ModelAndView("admin/studentMgmt/baseProfileRegistration", modelMap);
                } else {

                    if (!file1.isEmpty()) {
                        request.getSession().setAttribute("file1_sess", file1);
                    }

                    studentService.specialStdBaseProfileAtrributesMapping(modelMap, request, stdBaseProfile);
                    modelMap.addAttribute("stdBaseProfile", stdBaseProfile);
                    modelMap.addAttribute("isimageuploaded", file1.getName());

                    //       studentService.formAddOptionvalues(modelMap);

                    request.getSession().setAttribute("stdBaseProfile_sess", stdBaseProfile);
                    return new ModelAndView("admin/studentMgmt/baseProfileRegistrationConfirm", modelMap);
                }

            }
        } else //Only photo uploading
        {

            MultipartFile oldfile = (MultipartFile) request.getSession().getAttribute("file1_sess");

            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultipartFile file1 = multipartRequest.getFile("file1");

            if (file1.isEmpty() && oldfile == null) {


                studentService.specialStdBaseProfileAtrributesMapping(modelMap, request, stdBaseProfile);
                modelMap.addAttribute("fileerror", "File is Empty");
                modelMap.addAttribute("isimageuploaded", null);

//                    modelMap.addAttribute("stdBaseProfile", stdBaseProfile_session);
                return new ModelAndView("admin/studentMgmt/baseProfileRegistration", modelMap);
            } else {

                if (!file1.isEmpty()) {
                    request.getSession().setAttribute("file1_sess", file1);
                }

                studentService.specialStdBaseProfileAtrributesMapping(modelMap, request, stdBaseProfile);
                modelMap.addAttribute("stdBaseProfile", stdBaseProfile);
                modelMap.addAttribute("isimageuploaded", file1.getName());


                //     studentService.formAddOptionvalues(modelMap);

                return new ModelAndView("admin/studentMgmt/baseProfileRegistration", modelMap);

            }
        }

    }
    @RequestMapping("/AdminStdBaseProfileRegistrationSuccess.htm")
    public ModelAndView submitStdBaseProfileRegistrationSuccess(
            @ModelAttribute("stdBaseProfile") StdBaseProfile stdBaseProfile,
            HttpServletRequest request,
            @RequestParam(value = "confirm", required = false) Object confirm,
            @RequestParam(value = "back", required = false) Object back,
            @RequestParam(value = "change", required = false) Object captchaChange,
            ModelMap modelMap) throws IOException {

        stdBaseProfile = (StdBaseProfile) request.getSession().getAttribute("stdBaseProfile_sess");
        MultipartFile file1 = (MultipartFile) request.getSession().getAttribute("file1_sess");

        modelMap.addAttribute("stdBaseProfile", stdBaseProfile);
        modelMap.addAttribute("isimageuploaded", file1.getName());

        if (confirm != null) {
            // Checking Capatch Response
            boolean isResponseCorrect = false;
            String captchaId = request.getSession().getId();
            String response = request.getParameter("j_captcha_response");

            try {
                if (response != null) {
                    isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                }

            } catch (CaptchaServiceException e) {
                log.error("Problem Jcaptcha settings ", e);
            }


            if (!isResponseCorrect) { //Capatcha is not correct
                modelMap.addAttribute("captchaerror", "Capacth is Invalid");
                return new ModelAndView("admin/studentMgmt/baseProfileRegistrationConfirm", modelMap);
            } else {
                
                stdBaseProfile.setUsername(stdBaseProfile.getCollegeRegistrationNumber());
                studentService.saveStdBaseProfile(stdBaseProfile);

                Users user = new Users();
                user.setUsername(stdBaseProfile.getUsername());
                user.setEnabled(true);
                user.setPassword(RandomStringUtils.randomAlphanumeric(10));
                user.setUsertype("STUDENT");
                user.setEmailid(stdBaseProfile.getEmailId());
                user.setPhonenumber(stdBaseProfile.getPhoneNumber());

                //Saving into Common Users Table
                usersService.AddNewUser(user);

                // Saving StdBaseProfile's Parents Login Details

                Users user_parent = new Users();
                user_parent.setUsername(stdBaseProfile.getParentsEmailid());
                user_parent.setEnabled(true);
                user_parent.setPassword(RandomStringUtils.randomAlphanumeric(10));
                user_parent.setUsertype("PARENTS");
                user_parent.setEmailid(stdBaseProfile.getParentsEmailid());
                user_parent.setPhonenumber(stdBaseProfile.getParentsPhoneNumber());

                //Saving into Common Users Table
                usersService.AddNewUser(user_parent);

                List<StdBaseProfile> stdBaseProfileDetails = studentService.findStdBaseProfileByUsername(stdBaseProfile.getUsername());

                ResourceBundle bundle = ResourceBundle.getBundle("messages");
                String rootwebapp = bundle.getString("webapp.root");
                String actrootwebapp = bundle.getString("actwebapp.root");


                String filename = file1.getOriginalFilename().toString();

                int dotPosi = filename.lastIndexOf(".");
                String extension = filename.substring(dotPosi);
                String NewFilename = Long.toString(stdBaseProfileDetails.get(0).getId()) + extension;

                String profPhotoContextPath = "/profile_photos/student/" + NewFilename;
                String profPhotoAbsolutePathName = rootwebapp + profPhotoContextPath;

                //String profPhotoAbsolutePathName = actrootwebapp + profPhotoContextPath;
                file1.transferTo(new File(profPhotoAbsolutePathName));
                stdBaseProfile.setId(stdBaseProfileDetails.get(0).getId());
                stdBaseProfile.setProfilePhotoFileName(NewFilename);
                //Updating the StdBaseProfile table with Profile File name
                studentService.updateStdBaseProfile(stdBaseProfile);

                modelMap.addAttribute("userProfilePhotoExists", "profilephotoexits");

                return new ModelAndView("admin/studentMgmt/baseProfileRegistrationSuccess", modelMap);
            }
        } else if (back != null) {
            studentService.formAddOptionvalues(modelMap);
            studentService.specialStdBaseProfileAtrributesMapping(modelMap, request, stdBaseProfile);
            return new ModelAndView("admin/studentMgmt/baseProfileRegistration", modelMap);

        } else // capatchChange!=null
        {
            studentService.formAddOptionvalues(modelMap);
            studentService.specialStdBaseProfileAtrributesMapping(modelMap, request, stdBaseProfile);
            return new ModelAndView("admin/studentMgmt/baseProfileRegistrationConfirm", modelMap);
        }
    }

    @RequestMapping("/AdminStdBaseProfileSearch.htm")
    public ModelAndView stdBaseProfileSearch(ModelMap model, @ModelAttribute("stdBaseProfile1") StdBaseProfile stdBaseProfile1) {
        return new ModelAndView("admin/studentMgmt/baseProfSearch", model);
    }

    @RequestMapping("/AdminStdBaseProfileSearchResults.htm")
    public ModelAndView stdBaseProfileSearchResults(ModelMap model,
            @ModelAttribute("stdBaseProfile1") StdBaseProfile stdBaseProfile1,
            HttpServletRequest request) {

        model.addAttribute("stdBaseProfile", new StdBaseProfile());

        List<StdBaseProfile> stdBaseProfSearch = studentService.searchStdBaseProfile(stdBaseProfile1);
        model.addAttribute("stdBaseProfSearch", stdBaseProfSearch);

        request.getSession().setAttribute("stdBaseProfSearch", stdBaseProfSearch);

        return new ModelAndView("admin/studentMgmt/baseProfSearchResults", model);
    }

    @RequestMapping("/AdminStdBaseProfileUpdate.htm")
    public ModelAndView stdBaseProfileRegistrationUpdation(
            @ModelAttribute("stdBaseProfile") StdBaseProfile stdBaseProfile,
            HttpServletRequest request,
            ModelMap modelMap) throws IOException {

        Calendar c1 = Calendar.getInstance();
        modelMap.addAttribute("currentyear", Integer.toString(c1.get(Calendar.YEAR)));
        modelMap.addAttribute("nextyear", Integer.toString(c1.get(Calendar.YEAR) + 1));
 //       modelMap.addAttribute("isimageuploaded", null);
        //   modelMap.addAttribute("userProfilePhotoExists", null);
   //     request.getSession().setAttribute("stdBaseProfile_sess", stdBaseProfile);
        long stdBaseProfilePrimKey = Long.parseLong(request.getParameter("stdBaseProfilePrimKey"));

        if (stdBaseProfilePrimKey != 0) {

            stdBaseProfile = studentService.findStdBaseProfileByPrimaryKey(stdBaseProfilePrimKey).get(0);


            modelMap.addAttribute("stdBaseProfile", stdBaseProfile);
            request.getSession().setAttribute("stdBaseProfilePrimKey", stdBaseProfilePrimKey);

            ResourceBundle bundle = ResourceBundle.getBundle("messages");
            String rootwebapp = bundle.getString("webapp.root");
            String actrootwebapp = bundle.getString("actwebapp.root");

            String NewFilename = stdBaseProfile.getProfilePhotoFileName();
            String profPhotoContextPath = "/profile_photos/student/" + NewFilename;
            String profPhotoAbsolutePathName = rootwebapp + profPhotoContextPath;
            //String profPhotoAbsolutePathName = actrootwebapp + profPhotoContextPath;
            //file1.transferTo(new File(profPhotoAbsolutePathName));
            File profilefile = new File(profPhotoAbsolutePathName);

            if (profilefile.exists()) {
                modelMap.addAttribute("userProfilePhotoExists", "yes");
            } else {
                modelMap.addAttribute("userProfilePhotoExists", "no");
            }
        }
        request.getSession().removeAttribute("file1_sess");
        request.getSession().removeAttribute("stdBaseProfile_sess");

        studentService.specialStdBaseProfileAtrributesMapping(modelMap, request, stdBaseProfile);

        modelMap.addAttribute("isimageuploaded", "no");
        studentService.formAddOptionvalues(modelMap);

                request.getSession().setAttribute("stdBaseProfile_sess", stdBaseProfile);
        return new ModelAndView("admin/studentMgmt/baseProfileUpdate", modelMap);
    }

    @RequestMapping("/AdminStdBaseProfileUpdateConfirm.htm")
    public ModelAndView stdBaseProfileRegistrationUpdateConfirm(
            @ModelAttribute("stdBaseProfile") StdBaseProfile stdBaseProfile,
            BindingResult result,
            HttpServletRequest request,
            ModelMap model,
            @RequestParam(value = "confirm", required = false) Object confirm,
            @RequestParam(value = "cancel", required = false) Object cancel,
            @RequestParam(value = "photoUpload", required = false) Object photoUpload) throws IOException {

        studentService.formAddOptionvalues(model);

        if (cancel != null) {
            List<StdBaseProfile> stdBaseProfSearch = (List<StdBaseProfile>) request.getSession().getAttribute("stdBaseProfSearch");

            model.addAttribute("stdBaseProfile", new StdBaseProfile());
            model.addAttribute("stdBaseProfSearch", stdBaseProfSearch);
            return new ModelAndView("admin/studentMgmt/baseProfSearchResults", model);
        } else if (photoUpload != null) {
            //Now this problem is to be solved
            MultipartFile oldfile = (MultipartFile) request.getSession().getAttribute("file1_sess");

            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultipartFile file1 = multipartRequest.getFile("file1");

            if (file1.isEmpty() && oldfile == null) {

                studentService.specialStdBaseProfileAtrributesMapping(model, request, stdBaseProfile);
                model.addAttribute("fileerror", "File is Empty. <br> Please upload new photo to update the photo");
                model.addAttribute("isimageuploaded", "no");

                if (request.getParameter("userProfilePhotoExists").toString().equals("yes")) {

                    ResourceBundle bundle = ResourceBundle.getBundle("messages");
                    String rootwebapp = bundle.getString("webapp.root");
                    String actrootwebapp = bundle.getString("actwebapp.root");
                    String NewFilename = stdBaseProfile.getProfilePhotoFileName();
                    String profPhotoContextPath = "/profile_photos/student/" + NewFilename;
                    String profPhotoAbsolutePathName = rootwebapp + profPhotoContextPath;

                    //String profPhotoAbsolutePathName = actrootwebapp + profPhotoContextPath;
                    //file1.transferTo(new File(profPhotoAbsolutePathName));
                    File profilefile = new File(profPhotoAbsolutePathName);
                    if (profilefile.exists()) {
                        model.addAttribute("userProfilePhotoExists", "yes");
                    } else { // In case if the profile is deleted manually(by mistake) by the admin
                        model.addAttribute("userProfilePhotoExists", "no");
                    }
                } else {
                    model.addAttribute("userProfilePhotoExists", "no");
                }

//                    modelMap.addAttribute("stdBaseProfile", stdBaseProfile_session);
                studentService.specialStdBaseProfileAtrributesMapping(model, request, stdBaseProfile);
                model.addAttribute("stdBaseProfile", stdBaseProfile);
                return new ModelAndView("admin/studentMgmt/baseProfileUpdate", model);
            } else {

                if (!file1.isEmpty()) {
                    request.getSession().setAttribute("file1_sess", file1);
                    model.addAttribute("userProfilePhotoExists", "no");
                } else {
                    file1 = oldfile; // replacing file1 with old image only
                    model.addAttribute("userProfilePhotoExists", "no");
                    model.addAttribute("fileerror", "File is Empty. <br> Please upload new photo to update the photo");
                }

                model.addAttribute("isimageuploaded", "yes");
                studentService.specialStdBaseProfileAtrributesMapping(model, request, stdBaseProfile);
                model.addAttribute("stdBaseProfile", stdBaseProfile);

                return new ModelAndView("admin/studentMgmt/baseProfileUpdate", model);
            }
        } else// confirm!=null
        {

            stdBaseProfile.setJoiningAcademicYear(request.getParameter("fromYearAcademicYear") + "-" + request.getParameter("toYearAcademicYear"));

            if (stdBaseProfile.getUniversityRegistered().toString().equals("NO")) {
                stdBaseProfile.setCollegeRegistrationNumber(stdBaseProfile.getEmailId());
            }
            studentValidator.validateStdBaseProfile(stdBaseProfile, result);

            // CHECKING uniquness of EmailIds,Registration numbers and etc

            if (studentService.stdBaseProfileCheck(stdBaseProfile.getCollegeRegistrationNumber(), "collegeRegistrationNumber", stdBaseProfile.getId()).size() > 0) {
                result.rejectValue("collegeRegistrationNumber", "collegeRegistrationNumber.existsAlready");
            }


            if (studentService.stdBaseProfileCheck(stdBaseProfile.getEmailId(), "emailId", stdBaseProfile.getId()).size() > 0) {
                result.rejectValue("emailId", "emailId.exitsAlready");
            }

            if (studentService.stdBaseProfileCheck(stdBaseProfile.getParentsEmailid(), "parentsEmailid", stdBaseProfile.getId()).size() > 0) {
                result.rejectValue("parentsEmailid", "parentsEmailid.exitsAlready");
            }

            if (stdBaseProfile.getParentsEmailid().equals(stdBaseProfile.getEmailId())
                    && !stdBaseProfile.getParentsEmailid().equals("")
                    && !stdBaseProfile.getEmailId().equals("")) {
                result.rejectValue("emailId", "emailIds.isSame");
                result.rejectValue("parentsEmailid", "emailIds.isSame");
            }


            if (studentService.stdBaseProfileCheck(stdBaseProfile.getPhoneNumber(), "phoneNumber", stdBaseProfile.getId()).size() > 0) {
                result.rejectValue("phoneNumber", "phoneNumber.existsAlready");
            }

            if (studentService.stdBaseProfileCheck(stdBaseProfile.getParentsPhoneNumber(), "parentsPhoneNumber", stdBaseProfile.getId()).size() > 0) {
                result.rejectValue("parentsPhoneNumber", "parentsPhoneNumber.existsAlready");
            }

            if (stdBaseProfile.getPhoneNumber().equals(stdBaseProfile.getParentsPhoneNumber())
                    && !stdBaseProfile.getPhoneNumber().equals("")
                    && !stdBaseProfile.getParentsPhoneNumber().equals("")) {

                result.rejectValue("parentsPhoneNumber", "phoneNumbers.isSame");
                result.rejectValue("phoneNumber", "phoneNumbers.isSame");
            }

            if (result.hasErrors()) {
                //       studentService.formAddOptionvalues(modelMap);
                studentService.specialStdBaseProfileAtrributesMapping(model, request, stdBaseProfile);
                return new ModelAndView("admin/studentMgmt/baseProfileUpdate", model);
            } else {

                MultipartFile oldfile = (MultipartFile) request.getSession().getAttribute("file1_sess");

                MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
                MultipartFile file1 = multipartRequest.getFile("file1");

                if (file1.isEmpty() && oldfile == null) {
                    studentService.specialStdBaseProfileAtrributesMapping(model, request, stdBaseProfile);
                    model.addAttribute("fileerror", null);
                    model.addAttribute("isimageuploaded", "no");
                    model.addAttribute("stdBaseProfile", stdBaseProfile);

                    if (request.getParameter("userProfilePhotoExists").toString().equals("yes")) {

                        ResourceBundle bundle = ResourceBundle.getBundle("messages");
                        String rootwebapp = bundle.getString("webapp.root");
                        String actrootwebapp = bundle.getString("actwebapp.root");
                        String NewFilename = stdBaseProfile.getProfilePhotoFileName();
                        String profPhotoContextPath = "/profile_photos/student/" + NewFilename;
                        String profPhotoAbsolutePathName = rootwebapp + profPhotoContextPath;

                        //String profPhotoAbsolutePathName = actrootwebapp + profPhotoContextPath;
                        //file1.transferTo(new File(profPhotoAbsolutePathName));
                        File profilefile = new File(profPhotoAbsolutePathName);
                        if (profilefile.exists()) {
                            model.addAttribute("userProfilePhotoExists", "yes");

                            request.getSession().setAttribute("stdBaseProfile_sess", stdBaseProfile);
//                            request.getSession().setAttribute("isimageuploaded", null);
//                            request.getSession().setAttribute("userProfilePhotoExists", "yes");

                            return new ModelAndView("admin/studentMgmt/baseProfileUpdateConfirm", model);
                        } else { // In case if the profile is deleted manually(by mistake) by the admin
                            model.addAttribute("userProfilePhotoExists", "no");
                            return new ModelAndView("admin/studentMgmt/baseProfileUpdate", model);

                        }
                    } else {
                        model.addAttribute("userProfilePhotoExists", "no");
                        return new ModelAndView("admin/studentMgmt/baseProfileUpdate", model);
                    }

                } else {

                  if (!file1.isEmpty()) {
                    request.getSession().setAttribute("file1_sess", file1);
                    model.addAttribute("userProfilePhotoExists", "no");
                } else {
                    file1 = oldfile; // replacing file1 with old image only
                    model.addAttribute("userProfilePhotoExists", "no");
                  //  model.addAttribute("fileerror", "File is Empty. <br> Please upload new photo to update the photo");
                }

                    studentService.specialStdBaseProfileAtrributesMapping(model, request, stdBaseProfile);
                    model.addAttribute("isimageuploaded", "yes");
                    model.addAttribute("stdBaseProfile", stdBaseProfile);
//                    model.addAttribute("userProfilePhotoExists", request.getParameter("userProfilePhotoExists"));

                    return new ModelAndView("admin/studentMgmt/baseProfileUpdateConfirm", model);

                }
            }

        }
    }

    @RequestMapping("/AdminStdBaseProfileUpdateSuccess.htm")
    public ModelAndView submitStdBaseProfileUpdateSuccess(
            @ModelAttribute("stdBaseProfile") StdBaseProfile stdBaseProfile,
            HttpServletRequest request,
            @RequestParam(value = "confirm", required = false) Object confirm,
            @RequestParam(value = "back", required = false) Object back,
            @RequestParam(value = "change", required = false) Object captchaChange,
            ModelMap modelMap) throws IOException {

        stdBaseProfile = (StdBaseProfile) request.getSession().getAttribute("stdBaseProfile_sess");
        
        modelMap.addAttribute("stdBaseProfile", stdBaseProfile);
//      modelMap.addAttribute("isimageuploaded", request.getParameter("isimageuploaded"));
        

        if (confirm != null) {
            // Checking Capatch Response
            boolean isResponseCorrect = false;
            String captchaId = request.getSession().getId();
            String response = request.getParameter("j_captcha_response");

            try {
                if (response != null) {
                    isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                }

            } catch (CaptchaServiceException e) {
                log.error("Problem Jcaptcha settings ", e);
            }


            if (!isResponseCorrect) { //Capatcha is not correct

                modelMap.addAttribute("isimageuploaded", request.getParameter("isimageuploaded"));
                modelMap.addAttribute("userProfilePhotoExists", request.getParameter("userProfilePhotoExists"));
                modelMap.addAttribute("captchaerror", "Capacth is Invalid");
                return new ModelAndView("admin/studentMgmt/baseProfileUpdateConfirm", modelMap);

            } else {

                stdBaseProfile.setUsername(stdBaseProfile.getCollegeRegistrationNumber());
                studentService.updateStdBaseProfile(stdBaseProfile);

                Users user = new Users();
                user.setUsername(stdBaseProfile.getUsername());
                user.setEnabled(true);
                user.setPassword(RandomStringUtils.randomAlphanumeric(10));
                user.setUsertype("STUDENT");
                user.setEmailid(stdBaseProfile.getEmailId());
                user.setPhonenumber(stdBaseProfile.getPhoneNumber());
                
                List<Users> stdUser = (List <Users>) usersService.userDetailsCheck(stdBaseProfile.getUsername(), "username");
                if(stdUser.size()>0)
                {
                    user.setId(stdUser.get(0).getId());
                    usersService.UpdateUser(user);
                }
                else
                {
                    usersService.AddNewUser(user);
                }
               

                // Saving StdBaseProfile's Parents Login Details
                Users user_parent = new Users();
                user_parent.setUsername(stdBaseProfile.getParentsEmailid());
                user_parent.setEnabled(true);
                user_parent.setPassword(RandomStringUtils.randomAlphanumeric(10));
                user_parent.setUsertype("PARENTS");
                user_parent.setEmailid(stdBaseProfile.getParentsEmailid());
                user_parent.setPhonenumber(stdBaseProfile.getParentsPhoneNumber());

                List<Users> parentUser = (List <Users>) usersService.userDetailsCheck(stdBaseProfile.getParentsEmailid(), "username");
                if(parentUser.size()>0)
                {
                    user_parent.setId(parentUser.get(0).getId());
                    usersService.UpdateUser(user_parent);
                }
                else
                {
                    usersService.AddNewUser(user_parent);
                }



                List<StdBaseProfile> stdBaseProfileDetails = studentService.findStdBaseProfileByUsername(stdBaseProfile.getUsername());

                if (request.getParameter("isimageuploaded").toString().equals("yes")) // if image is uploaded
                {
                    MultipartFile file1 = (MultipartFile) request.getSession().getAttribute("file1_sess");
                    ResourceBundle bundle = ResourceBundle.getBundle("messages");
                    String rootwebapp = bundle.getString("webapp.root");
                    String actrootwebapp = bundle.getString("actwebapp.root");


                    String filename = file1.getOriginalFilename().toString();

                    int dotPosi = filename.lastIndexOf(".");
                    String extension = filename.substring(dotPosi);
                    String NewFilename = Long.toString(stdBaseProfileDetails.get(0).getId()) + extension;

                    String profPhotoContextPath = "/profile_photos/student/" + NewFilename;
                    String profPhotoAbsolutePathName = rootwebapp + profPhotoContextPath;

                    //String profPhotoAbsolutePathName = actrootwebapp + profPhotoContextPath;
                    file1.transferTo(new File(profPhotoAbsolutePathName));
                    stdBaseProfile.setProfilePhotoFileName(NewFilename);
                }
                else
                {
                    stdBaseProfile.setProfilePhotoFileName(stdBaseProfileDetails.get(0).getProfilePhotoFileName());
                }

                stdBaseProfile.setId(stdBaseProfileDetails.get(0).getId());

                //Updating the StdBaseProfile table with Profile File name
                studentService.updateStdBaseProfile(stdBaseProfile);

                modelMap.addAttribute("userProfilePhotoExists", "yes");


                return new ModelAndView("admin/studentMgmt/baseProfileUpdateSuccess", modelMap);
            }
        } else if (back != null) {
            studentService.formAddOptionvalues(modelMap);
            modelMap.addAttribute("userProfilePhotoExists", request.getParameter("userProfilePhotoExists"));
            modelMap.addAttribute("isimageuploaded", request.getParameter("isimageuploaded"));

            studentService.specialStdBaseProfileAtrributesMapping(modelMap, request, stdBaseProfile);
            return new ModelAndView("admin/studentMgmt/baseProfileUpdate", modelMap);

        } else // capatchChange!=null
        {
            modelMap.addAttribute("userProfilePhotoExists", request.getParameter("userProfilePhotoExists"));
            modelMap.addAttribute("isimageuploaded", request.getParameter("isimageuploaded"));

            studentService.formAddOptionvalues(modelMap);
            studentService.specialStdBaseProfileAtrributesMapping(modelMap, request, stdBaseProfile);
            return new ModelAndView("admin/studentMgmt/baseProfileUpdateConfirm", modelMap);
        }
    }






    static final String[] pages = {"First", "Second", "Third", "Confirm", "Done"};

    @RequestMapping("/AdminStdProfileRegistration.htm")
    public ModelAndView submittedView(@ModelAttribute("student") Student student,
            BindingResult result,
            @RequestParam(value = "nextPage", required = false) Integer page,
            @RequestParam(value = "next", required = false) Object next,
            @RequestParam(value = "prev", required = false) Object prev,
            @RequestParam(value = "photoUpload", required = false) Object photoUpload,
            @RequestParam(value = "curPage", required = false) Integer curPage,
            @RequestParam(value = "confirm", required = false) Object confirm,
            HttpServletRequest request,
            ModelMap modelMap) throws IOException {




        Student student_session = new Student();

        studentService.formAddOptionvalues(modelMap);

        if (curPage != null && (next != null || confirm != null)) {

            page = curPage + 1;
        }

        if (curPage != null && prev != null) {
            page = curPage - 1;
        }

//        if (curPage !=null && confirm != null) {
//            page = curPage+1;
//        }

        if (page == null || page < 1 || page > pages.length) {
            page = 1;
        }



        if (page == 1 && photoUpload == null && prev == null && next == null) { //Going to Page-1

            modelMap.addAttribute("isimageuploaded", null);
            modelMap.addAttribute("userProfilePhotoExists", null);
            request.getSession().setAttribute("student_sess", student);
        } else if (page == 1 && photoUpload != null && next == null && prev == null) {
            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultipartFile file1 = multipartRequest.getFile("file1");


            student.setAdmissionDate(request.getParameter("admday") + "/" + request.getParameter("admmonth") + "/" + request.getParameter("admyear"));
            student.setDateofBirth(request.getParameter("bday") + "/" + request.getParameter("bmonth") + "/" + request.getParameter("byear"));

            studentValidator.validateStudentRegPageFirst(student, result);

            if (usersService.userDetailsCheck(student.getEmailId(), "emailid").size() > 0) {
                result.rejectValue("emailId", "emailId.exitsAlready");
            }

// SIMIlarly  DO IT FOR PARENTS EMAILD IN SECOND PAGE ALSO 

            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
//                studentService.specialStudentAtrributesMapping(modelMap,request);
                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 1;
            } else {
                if (file1.isEmpty()) {
                    studentService.formAddOptionvalues(modelMap);
//                    studentService.specialStudentAtrributesMapping(modelMap,request);
                    studentService.specialStudentAtrributesMapping(modelMap, request, student);
                    modelMap.addAttribute("fileerror", "File is Empty");
                    modelMap.addAttribute("isimageuploaded", null);
                    page = 1;
                } else {

                    request.getSession().setAttribute("file1_sess", file1);

                    student_session = (Student) request.getSession().getAttribute("student_sess");
                    studentService.combineStudentRegPage1withOldPageObjects(student, student_session);
                    modelMap.addAttribute("isimageuploaded", file1.getName());

                    request.getSession().setAttribute("student_sess", student_session);


                    studentService.specialStudentAtrributesMapping(modelMap, request, student_session);
                    modelMap.addAttribute("student", student_session);

                    page = 1;
                }
            }

        } else if (page == 2 && next != null && prev == null) { // Going from Page-1 to Page-2

            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultipartFile file1 = multipartRequest.getFile("file1");

            student.setAdmissionDate(request.getParameter("admday") + "/" + request.getParameter("admmonth") + "/" + request.getParameter("admyear"));
            student.setDateofBirth(request.getParameter("bday") + "/" + request.getParameter("bmonth") + "/" + request.getParameter("byear"));


            studentValidator.validateStudentRegPageFirst(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
                //studentService.specialStudentAtrributesMapping(modelMap,request);

                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 1;
            } else {

                MultipartFile oldfile = (MultipartFile) request.getSession().getAttribute("file1_sess");

                if (file1.isEmpty() && oldfile == null) {
                    studentService.formAddOptionvalues(modelMap);
                    //   studentService.specialStudentAtrributesMapping(modelMap, request);
                    studentService.specialStudentAtrributesMapping(modelMap, request, student);

                    modelMap.addAttribute("fileerror", "File is Empty");
                    page = 1;
                } else {
                    if (!file1.isEmpty()) {
                        request.getSession().setAttribute("file1_sess", file1);
                    }


                    student_session = (Student) request.getSession().getAttribute("student_sess");
                    // Now I need to add student_sess attribute values (if any)to student
                    studentService.combineStudentRegPage1withOldPageObjects(student, student_session);
                    studentService.specialStudentAtrributesMapping(modelMap, request, student_session);

                    request.getSession().setAttribute("student_sess", student_session);
                    modelMap.addAttribute("student", student_session);
                    page = 2;
                }
            }
        } else if (page == 3 && next != null && prev == null) { // Going from Page-2 to Page-3

            student.setCurrentAddress(request.getParameter("stc_line1") + ";" + request.getParameter("stc_line2") + ";" + request.getParameter("stc_line3"));
            student.setPermanentAddress(request.getParameter("stp_line1") + ";" + request.getParameter("stp_line2") + ";" + request.getParameter("stp_line3"));
            student.setParentsCorrespondenceAddress(request.getParameter("pc_line1") + ";" + request.getParameter("pc_line2") + ";" + request.getParameter("pc_line3"));


            studentValidator.validateStudentRegPageSecond(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 2;
            } else {

                student_session = (Student) request.getSession().getAttribute("student_sess");
                studentService.combineStudentRegPage2withOldPageObjects(student, student_session);
                studentService.specialStudentAtrributesMapping(modelMap, request, student_session);
                //Now student is with Complete details till Page 2
                request.getSession().setAttribute("student_sess", student_session);
                modelMap.addAttribute("student", student_session);
                page = 3;
            }


        } else if (page == 4 && next != null && prev == null) {// Page-4 from Page -3

            student.setAcedamicYearStudiedQE(request.getParameter("qefromyear") + "-" + request.getParameter("qetoyear"));
            student.setClassVIAcademicYear(request.getParameter("VIfromyear") + "-" + request.getParameter("VItoyear"));
            student.setClassVIIAcademicYear(request.getParameter("VIIfromyear") + "-" + request.getParameter("VIItoyear"));
            student.setClassVIIIAcademicYear(request.getParameter("VIIIfromyear") + "-" + request.getParameter("VIIItoyear"));
            student.setClassIXAcademicYear(request.getParameter("IXfromyear") + "-" + request.getParameter("IXtoyear"));
            student.setClassXAcademicYear(request.getParameter("Xfromyear") + "-" + request.getParameter("Xtoyear"));
            student.setClassXIAcademicYear(request.getParameter("XIfromyear") + "-" + request.getParameter("XItoyear"));
            student.setClassXIIAcademicYear(request.getParameter("XIIfromyear") + "-" + request.getParameter("XIItoyear"));


            studentValidator.validateStudentRegPageThird(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 3;
            } else {

                student_session = (Student) request.getSession().getAttribute("student_sess");
                // Now set the Student details to Stduent_session
                studentService.combineStudentRegPage3withOldPageObjects(student, student_session);
                studentService.specialStudentAtrributesMapping(modelMap, request, student_session);
                request.getSession().setAttribute("student_sess", student_session);
                modelMap.addAttribute("student", student_session);
                page = 4;

            }

        } else if (page == 1 && prev != null && next == null) { //When going back to page 1 from CurrPage=2
            student = (Student) request.getSession().getAttribute("student_sess");

//            studentService.backSpecialStudentAtrributesMapping(modelMap,student);

            studentService.specialStudentAtrributesMapping(modelMap, request, student);

            modelMap.addAttribute("isimageuploaded", "Image is there already");
            modelMap.addAttribute("student", student);

        } else if (page == 2 && prev != null && next == null) // When Going back to page-2 from CurrPage=3
        {
            student = (Student) request.getSession().getAttribute("student_sess");


            //studentService.backSpecialStudentAtrributesMapping(modelMap,student);
            studentService.specialStudentAtrributesMapping(modelMap, request, student);


            modelMap.addAttribute("student", student);

        } else if (page == 3 && prev != null && next == null) // When Going back to page-3 from CurrPage=4
        {
            student = (Student) request.getSession().getAttribute("student_sess");

            //studentService.backSpecialStudentAtrributesMapping(modelMap,student);
            studentService.specialStudentAtrributesMapping(modelMap, request, student);
            modelMap.addAttribute("student", student);
        } else if (page == 5 && confirm != null) {
            // Checking Capatch Response
            boolean isResponseCorrect = false;
            String captchaId = request.getSession().getId();
            String response = request.getParameter("j_captcha_response");

            student = (Student) request.getSession().getAttribute("student_sess");
            // Now set the Student details to Stduent_session
            modelMap.addAttribute("student", student);

            try {
                if (response != null) {

                    isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                    log.error("Captcha is valid..Great!");
                }

            } catch (CaptchaServiceException e) {
                log.error("Problem Jcaptcha settings ", e);
            }

            if (!isResponseCorrect) { //Capatcha is not correct
                modelMap.addAttribute("captchaerror", "Capacth is Invalid");
                page = 4;

            } else {
                //Setting Username & Passwords
                student.setPassword(RandomStringUtils.randomAlphanumeric(10));
                student.setUsername(student.getEmailId());

                if ((usersService.userDetailsCheck(student.getUsername(), "username").size() < 1)
                        && (usersService.userDetailsCheck(student.getEmailId(), "emailid").size() < 1)
                        && (usersService.userDetailsCheck(student.getParentsEmailid(), "emailid").size() < 1)) {//checking the usernames of both

                    //Checking Username & emailid details
                    // College Registarion Number ----> for Old student
                    //Setting Username & Password for Parents
                    student.setParentsUsername(student.getParentsEmailid());
                    student.setParentsPassword(RandomStringUtils.randomAlphanumeric(10));

                    // Saving Student
                    studentService.saveStudent(student);

                    Users user = new Users();
                    user.setUsername(student.getUsername());
                    user.setEnabled(true);
                    user.setPassword(student.getPassword());
                    user.setUsertype("STUDENT");
                    user.setEmailid(student.getEmailId());
                    //Saving into Common Users Table
                    usersService.AddNewUser(user);

                    // Saving Student's Parents Login Details
                    Users user_parent = new Users();
                    user_parent.setUsername(student.getParentsUsername());
                    user_parent.setEnabled(true);
                    user_parent.setPassword(student.getParentsPassword());
                    user_parent.setUsertype("PARENTS");
                    user_parent.setEmailid(student.getParentsEmailid());
                    //Saving into Common Users Table
                    usersService.AddNewUser(user_parent);

                    List<Student> studentDetails = studentService.findStudentByUsername(student.getUsername());

                    ResourceBundle bundle = ResourceBundle.getBundle("messages");
                    String rootwebapp = bundle.getString("webapp.root");
                    String actrootwebapp = bundle.getString("actwebapp.root");

                    MultipartFile file1 = (MultipartFile) request.getSession().getAttribute("file1_sess");

                    String filename = file1.getOriginalFilename().toString();

                    int dotPosi = filename.lastIndexOf(".");
                    String extension = filename.substring(dotPosi);
                    String NewFilename = Long.toString(studentDetails.get(0).getId()) + extension;

                    String profPhotoContextPath = "/profile_photos/student/" + NewFilename;
                    String profPhotoAbsolutePathName = rootwebapp + profPhotoContextPath;

                    //String profPhotoAbsolutePathName = actrootwebapp + profPhotoContextPath;
                    file1.transferTo(new File(profPhotoAbsolutePathName));
                    student.setId(studentDetails.get(0).getId());
                    student.setProfilePhotoFileName(NewFilename);
                    //Updating the Student table with Profile File name
                    studentService.updateStudent(student);
                }
            }
        }
        modelMap.addAttribute("pageNum", page);
        modelMap.addAttribute("pageMax", pages.length);
        modelMap.addAttribute("pageView", pages[page - 1]);
        /* IMPLEMENT YOUR LOGIC */
        return new ModelAndView("AdminStdProfile", modelMap);
    }

    @RequestMapping("/AdminStdntProfSearch.htm")
    public ModelAndView adminStudentSearch(ModelMap model, @ModelAttribute("student1") Student student1) {
        return new ModelAndView("AdminStdntProfSearch", model);
    }

    @RequestMapping("/AdminStdntProfSearchResults.htm")
    public ModelAndView adminStudentSearchResults(ModelMap model, @ModelAttribute("student") Student student, @ModelAttribute("student1") Student student1) {

        model.addAttribute("student", new Student());

        List<Student> studentSearch = studentService.searchStudent(student1);
        model.addAttribute("studentSearch", studentSearch);

        return new ModelAndView("AdminStdntProfSearchResults", model);
    }

    @RequestMapping("/AdminStudentProfileUpdate.htm")
    public ModelAndView adminStudentProfileUpdation(@ModelAttribute("student") Student student,
            BindingResult result,
            @RequestParam(value = "nextPage", required = false) Integer page,
            @RequestParam(value = "next", required = false) Object next,
            @RequestParam(value = "prev", required = false) Object prev,
            @RequestParam(value = "photoUpload", required = false) Object photoUpload,
            @RequestParam(value = "curPage", required = false) Integer curPage,
            @RequestParam(value = "confirm", required = false) Object confirm,
            HttpServletRequest request,
            ModelMap modelMap) throws IOException {


        Student student_session = new Student();

        studentService.formAddOptionvalues(modelMap);

        if (curPage != null && (next != null || confirm != null)) {
            page = curPage + 1;
        }

        if (curPage != null && prev != null) {
            page = curPage - 1;
        }

        if (page == null || page < 1 || page > pages.length) {
            page = 1;
        }


        String userProfilePhotoExists = null;

        if (page == 1 && photoUpload == null && prev == null && next == null) { //Going to Page-1

            long stdntPrimKey = Long.parseLong(request.getParameter("stdntPrimKey"));

            if (stdntPrimKey != 0) {

                student = studentService.findStudentByPrimaryKey(stdntPrimKey).get(0);

                List<Users> userdetails = usersService.userDetailsCheck(student.getUsername(), "username");
                long usersprimkeyid = userdetails.get(0).getId();

                List<Users> parentsdetails = usersService.userDetailsCheck(student.getParentsEmailid(), "username");
                long parentsprimkeyid = parentsdetails.get(0).getId();

                modelMap.addAttribute("student", student);
                request.getSession().setAttribute("stdntPrimKey", stdntPrimKey);
                request.getSession().setAttribute("usersprimkeyid", usersprimkeyid);
                request.getSession().setAttribute("parentsprimkeyid", parentsprimkeyid);


                ResourceBundle bundle = ResourceBundle.getBundle("messages");
                String rootwebapp = bundle.getString("webapp.root");
                String actrootwebapp = bundle.getString("actwebapp.root");

                String NewFilename = student.getProfilePhotoFileName();
                String profPhotoContextPath = "/profile_photos/student/" + NewFilename;
                String profPhotoAbsolutePathName = rootwebapp + profPhotoContextPath;
                //String profPhotoAbsolutePathName = actrootwebapp + profPhotoContextPath;
                //file1.transferTo(new File(profPhotoAbsolutePathName));
                File profilefile = new File(profPhotoAbsolutePathName);

                if (profilefile.exists()) {
                    userProfilePhotoExists = "1";
                    request.getSession().setAttribute("userProfilePhotoExists", userProfilePhotoExists);
                    modelMap.addAttribute("userProfilePhotoExists", userProfilePhotoExists);
                } else {

                    request.getSession().setAttribute("userProfilePhotoExists", null);
                    modelMap.addAttribute("userProfilePhotoExists", null);
                }

                //Now this problem is to be solved
                //      And next we need to start Attendence part

            }
            studentService.specialStudentAtrributesMapping(modelMap, request, student);

            modelMap.addAttribute("isimageuploaded", null);
            request.getSession().setAttribute("student_sess", student);

        } else if ((page == 1 && photoUpload != null && next == null && prev == null)) {
            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultipartFile file1 = multipartRequest.getFile("file1");


            student.setAdmissionDate(request.getParameter("admday") + "/" + request.getParameter("admmonth") + "/" + request.getParameter("admyear"));
            student.setDateofBirth(request.getParameter("bday") + "/" + request.getParameter("bmonth") + "/" + request.getParameter("byear"));

            studentValidator.validateStudentRegPageFirst(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
//                studentService.specialStudentAtrributesMapping(modelMap,request);
                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 1;
            } else {
                if (file1.isEmpty()) {
                    studentService.formAddOptionvalues(modelMap);
//                    studentService.specialStudentAtrributesMapping(modelMap,request);
                    studentService.specialStudentAtrributesMapping(modelMap, request, student);
                    student_session = (Student) request.getSession().getAttribute("student_sess");
                    modelMap.addAttribute("student", student_session);
                    modelMap.addAttribute("fileerror", "File is Empty");
                    modelMap.addAttribute("isimageuploaded", null);
                    page = 1;
                } else {

                    request.getSession().setAttribute("file1_sess", file1);

                    student_session = (Student) request.getSession().getAttribute("student_sess");
                    studentService.combineStudentRegPage1withOldPageObjects(student, student_session);
                    modelMap.addAttribute("isimageuploaded", file1.getName());

                    request.getSession().setAttribute("student_sess", student_session);


                    studentService.specialStudentAtrributesMapping(modelMap, request, student_session);
                    modelMap.addAttribute("student", student_session);

                    userProfilePhotoExists = null;
                    request.getSession().setAttribute("userProfilePhotoExists", userProfilePhotoExists);
                    modelMap.addAttribute("userProfilePhotoExists", userProfilePhotoExists);



                    page = 1;
                }
            }

        } else if (page == 2 && next != null && prev == null
                && (request.getSession().getAttribute("userProfilePhotoExists") != null
                && ((MultipartHttpServletRequest) request).getFile("file1").isEmpty())) {

            student.setAdmissionDate(request.getParameter("admday") + "/" + request.getParameter("admmonth") + "/" + request.getParameter("admyear"));
            student.setDateofBirth(request.getParameter("bday") + "/" + request.getParameter("bmonth") + "/" + request.getParameter("byear"));


            studentValidator.validateStudentRegPageFirst(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
                //studentService.specialStudentAtrributesMapping(modelMap,request);
                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 1;
            } else {
                student_session = (Student) request.getSession().getAttribute("student_sess");
                // Now I need to add student_sess attribute values (if any)to student
                studentService.combineStudentRegPage1withOldPageObjects(student, student_session);
                studentService.specialStudentAtrributesMapping(modelMap, request, student_session);

                request.getSession().setAttribute("student_sess", student_session);
                modelMap.addAttribute("student", student_session);
                page = 2;
            }
        } else if ((page == 2 && next != null && prev == null
                && (request.getSession().getAttribute("userProfilePhotoExists") == null
                || !((MultipartHttpServletRequest) request).getFile("file1").isEmpty()))) { // IF USER WANTS TO UPDATE PROFILE PHOTO // Going from Page-1 to Page-2

            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultipartFile file1 = multipartRequest.getFile("file1");

            student.setAdmissionDate(request.getParameter("admday") + "/" + request.getParameter("admmonth") + "/" + request.getParameter("admyear"));
            student.setDateofBirth(request.getParameter("bday") + "/" + request.getParameter("bmonth") + "/" + request.getParameter("byear"));


            studentValidator.validateStudentRegPageFirst(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
                //studentService.specialStudentAtrributesMapping(modelMap,request);

                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 1;
            } else {

                MultipartFile oldfile = (MultipartFile) request.getSession().getAttribute("file1_sess");

                if (file1.isEmpty() && oldfile == null) {
                    studentService.formAddOptionvalues(modelMap);
                    //   studentService.specialStudentAtrributesMapping(modelMap, request);
                    studentService.specialStudentAtrributesMapping(modelMap, request, student);

                    modelMap.addAttribute("fileerror", "File is Empty");
                    page = 1;
                } else {
                    if (!file1.isEmpty()) {
                        userProfilePhotoExists = null;
                        request.getSession().setAttribute("userProfilePhotoExists", userProfilePhotoExists);
                        modelMap.addAttribute("userProfilePhotoExists", userProfilePhotoExists);

                        request.getSession().setAttribute("file1_sess", file1);
                    }


                    student_session = (Student) request.getSession().getAttribute("student_sess");
                    // Now I need to add student_sess attribute values (if any)to student
                    studentService.combineStudentRegPage1withOldPageObjects(student, student_session);
                    studentService.specialStudentAtrributesMapping(modelMap, request, student_session);

                    request.getSession().setAttribute("student_sess", student_session);
                    modelMap.addAttribute("student", student_session);

                    page = 2;
                }
            }
        } else if (page == 3 && next != null && prev == null) { // Going from Page-2 to Page-3

            student.setCurrentAddress(request.getParameter("stc_line1") + ";" + request.getParameter("stc_line2") + ";" + request.getParameter("stc_line3"));
            student.setPermanentAddress(request.getParameter("stp_line1") + ";" + request.getParameter("stp_line2") + ";" + request.getParameter("stp_line3"));
            student.setParentsCorrespondenceAddress(request.getParameter("pc_line1") + ";" + request.getParameter("pc_line2") + ";" + request.getParameter("pc_line3"));


            studentValidator.validateStudentRegPageSecond(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 2;
            } else {

                student_session = (Student) request.getSession().getAttribute("student_sess");
                studentService.combineStudentRegPage2withOldPageObjects(student, student_session);
                studentService.specialStudentAtrributesMapping(modelMap, request, student_session);
                //Now student is with Complete details till Page 2
                request.getSession().setAttribute("student_sess", student_session);
                modelMap.addAttribute("student", student_session);
                page = 3;
            }


        } else if (page == 4 && next != null && prev == null) {// Page-4 from Page -3

            student.setAcedamicYearStudiedQE(request.getParameter("qefromyear") + "-" + request.getParameter("qetoyear"));
            student.setClassVIAcademicYear(request.getParameter("VIfromyear") + "-" + request.getParameter("VItoyear"));
            student.setClassVIIAcademicYear(request.getParameter("VIIfromyear") + "-" + request.getParameter("VIItoyear"));
            student.setClassVIIIAcademicYear(request.getParameter("VIIIfromyear") + "-" + request.getParameter("VIIItoyear"));
            student.setClassIXAcademicYear(request.getParameter("IXfromyear") + "-" + request.getParameter("IXtoyear"));
            student.setClassXAcademicYear(request.getParameter("Xfromyear") + "-" + request.getParameter("Xtoyear"));
            student.setClassXIAcademicYear(request.getParameter("XIfromyear") + "-" + request.getParameter("XItoyear"));
            student.setClassXIIAcademicYear(request.getParameter("XIIfromyear") + "-" + request.getParameter("XIItoyear"));


            studentValidator.validateStudentRegPageThird(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 3;
            } else {

                student_session = (Student) request.getSession().getAttribute("student_sess");
                // Now set the Student details to Stduent_session
                studentService.combineStudentRegPage3withOldPageObjects(student, student_session);
                studentService.specialStudentAtrributesMapping(modelMap, request, student_session);
                request.getSession().setAttribute("student_sess", student_session);
                modelMap.addAttribute("student", student_session);
                page = 4;

            }

        } else if (page == 1 && prev != null && next == null) { //When going back to page 1 from CurrPage=2
            student = (Student) request.getSession().getAttribute("student_sess");

//            studentService.backSpecialStudentAtrributesMapping(modelMap,student);


            studentService.specialStudentAtrributesMapping(modelMap, request, student);

            if (request.getSession().getAttribute("userProfilePhotoExists") == null) {
                modelMap.addAttribute("isimageuploaded", "Image is there already");
                modelMap.addAttribute("userProfilePhotoExists", null);
            } else {
                modelMap.addAttribute("isimageuploaded", null);
                modelMap.addAttribute("userProfilePhotoExists", request.getSession().getAttribute("userProfilePhotoExists"));
            }
            modelMap.addAttribute("student", student);

        } else if (page == 2 && prev != null && next == null) // When Going back to page-2 from CurrPage=3
        {
            student = (Student) request.getSession().getAttribute("student_sess");


            //studentService.backSpecialStudentAtrributesMapping(modelMap,student);
            studentService.specialStudentAtrributesMapping(modelMap, request, student);


            modelMap.addAttribute("student", student);

        } else if (page == 3 && prev != null && next == null) // When Going back to page-3 from CurrPage=4
        {
            student = (Student) request.getSession().getAttribute("student_sess");

            //studentService.backSpecialStudentAtrributesMapping(modelMap,student);
            studentService.specialStudentAtrributesMapping(modelMap, request, student);
            modelMap.addAttribute("student", student);
        } else if (page == 5 && confirm != null) {
            // Checking Capatch Response
            boolean isResponseCorrect = false;
            String captchaId = request.getSession().getId();
            String response = request.getParameter("j_captcha_response");

            student = (Student) request.getSession().getAttribute("student_sess");
            // Now set the Student details to Stduent_session
            modelMap.addAttribute("student", student);



            try {
                if (response != null) {

                    isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                    log.error("Captcha is valid..Great!");
                }

            } catch (CaptchaServiceException e) {
                log.error("Problem Jcaptcha settings ", e);
            }

            if (!isResponseCorrect) { //Capatcha is not correct
                modelMap.addAttribute("captchaerror", "Capacth is Invalid");
                page = 4;

            } else {
                //student.setPassword(RandomStringUtils.randomAlphanumeric(10));
                student.setUsername(student.getEmailId());
                student.setParentsUsername(student.getParentsEmailid());
                student.setId(Long.parseLong(request.getSession().getAttribute("stdntPrimKey").toString()));

                studentService.updateStudent(student);

                Users user = new Users();
                user.setUsername(student.getUsername());
                user.setEnabled(true);
                user.setPassword(student.getPassword());
                user.setUsertype("STUDENT");
                user.setEmailid(student.getEmailId());
                user.setId(Long.parseLong(request.getSession().getAttribute("usersprimkeyid").toString()));

                //Saving into Common Users Table
                usersService.UpdateUser(user);

                // Saving Student's Parents Login Details
                Users user_parent = new Users();
                user_parent.setUsername(student.getParentsUsername());
                user_parent.setEnabled(true);
                user_parent.setPassword(student.getParentsPassword());
                user_parent.setUsertype("PARENTS");
                user_parent.setEmailid(student.getParentsEmailid());
                user_parent.setId(Long.parseLong(request.getSession().getAttribute("parentsprimkeyid").toString()));

                //Saving into Common Users Table
                usersService.UpdateUser(user_parent);


                if (request.getSession().getAttribute("userProfilePhotoExists") == null) {
                    List<Student> studentDetails = studentService.findStudentByUsername(student.getUsername());


                    ResourceBundle bundle = ResourceBundle.getBundle("messages");
                    String rootwebapp = bundle.getString("webapp.root");
                    String actrootwebapp = bundle.getString("actwebapp.root");

                    MultipartFile file1 = (MultipartFile) request.getSession().getAttribute("file1_sess");

                    String filename = file1.getOriginalFilename().toString();

                    int dotPosi = filename.lastIndexOf(".");
                    String extension = filename.substring(dotPosi);
                    String NewFilename = Long.toString(studentDetails.get(0).getId()) + extension;

                    String profPhotoContextPath = "/profile_photos/student/" + NewFilename;
                    String profPhotoAbsolutePathName = rootwebapp + profPhotoContextPath;

                    //String profPhotoAbsolutePathName = actrootwebapp + profPhotoContextPath;
                    file1.transferTo(new File(profPhotoAbsolutePathName));
                    student.setId(studentDetails.get(0).getId());
                    student.setProfilePhotoFileName(NewFilename);
                    //Updating the Student table with Profile File name
                    studentService.updateStudent(student);
                }


                //
            }
        }
        modelMap.addAttribute("pageNum", page);
        modelMap.addAttribute("pageMax", pages.length);
        modelMap.addAttribute("pageView", pages[page - 1]);

        modelMap.addAttribute("stdntPrimKey", request.getSession().getAttribute("stdntPrimKey"));
        modelMap.addAttribute("usersprimkeyid", request.getSession().getAttribute("usersprimkeyid"));



        /* IMPLEMENT YOUR LOGIC */
        return new ModelAndView("AdminStdProfile", modelMap);
    }
}



