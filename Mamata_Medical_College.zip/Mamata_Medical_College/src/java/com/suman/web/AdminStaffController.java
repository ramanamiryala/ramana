package com.suman.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.annotation.RequestParam;

import com.suman.domain.Staff;
import com.suman.domain.Users;
import com.suman.domain.LeaveApplication;
import com.suman.domain.LeaveSummary;
import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.util.List;
import java.util.Date;
import java.text.DateFormat;

import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;



import org.apache.log4j.Logger;
import org.apache.commons.lang.RandomStringUtils;

import com.suman.service.StaffService;
import com.suman.security.UsersService;
import com.suman.validator.StaffValidator;

import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.Authentication;

import com.suman.email.EmailSender;
import com.suman.email.EmailDetails;
import java.text.SimpleDateFormat;

@Controller
public class AdminStaffController {

    private StaffService staffService;
    private StaffValidator staffValidator;
    private UsersService usersService;
    private GenericManageableCaptchaService captchaService;
    private Logger log = Logger.getLogger(AdminStudentController.class);
    private EmailSender emailSender;

    @Autowired
    public AdminStaffController(StaffService staffService, StaffValidator staffValidator, GenericManageableCaptchaService captchaService, UsersService usersService, EmailSender emailSender) {
        this.staffService = staffService;
        this.staffValidator = staffValidator;
        this.captchaService = captchaService;
        this.usersService = usersService;
        this.emailSender = emailSender;

    }

    @RequestMapping(value = "/staffRegistration.htm")
    public ModelAndView staffForm(ModelMap modelMap) {
        //Student student = new Student();
        Staff staff = new Staff();
        modelMap.addAttribute("staff", staff);

        staffService.formAddOptionvalues(modelMap);
        String formerror = "";
        modelMap.addAttribute("formerror", formerror);

        return new ModelAndView("admin/staffMgmt/registration", modelMap);
    }
    private static final String destinationDir = "C:/Temp/";

    @RequestMapping(value = "/staffRegistrationSubmit.htm")
    public ModelAndView regSuccess(
            @ModelAttribute("staff") Staff staff, BindingResult result, ModelMap model,
            HttpServletRequest request,
            @RequestParam("file1") MultipartFile file1) throws Exception {

        staff.setDateofbirth(request.getParameter("bday") + "/" + request.getParameter("bmonth") + "/" + request.getParameter("byear"));
        staff.setJoiningDate(request.getParameter("joiningday") + "/" + request.getParameter("joiningmonth") + "/" + request.getParameter("joiningyear"));
        staff.setDuration1(request.getParameter("formmonthduration1") + "/" + request.getParameter("formYearduration1") + "-" + request.getParameter("tomonthduration1") + "/" + request.getParameter("toYearduration1"));
        staff.setDuration2(request.getParameter("formmonthduration2") + "/" + request.getParameter("formYearduration2") + "-" + request.getParameter("tomonthduration2") + "/" + request.getParameter("toYearduration2"));

        staff.setAcademicYear1(request.getParameter("formmonthacademicYear1") + "/" + request.getParameter("formYearacademicYear1") + "-" + request.getParameter("tomonthacademicYear1") + "/" + request.getParameter("toYearacademicYear1"));
        staff.setAcademicYear2(request.getParameter("formmonthacademicYear2") + "/" + request.getParameter("formYearacademicYear2") + "-" + request.getParameter("tomonthacademicYear2") + "/" + request.getParameter("toYearacademicYear2"));
        staff.setAcademicYear3(request.getParameter("formmonthacademicYear3") + "/" + request.getParameter("formYearacademicYear3") + "-" + request.getParameter("tomonthacademicYear3") + "/" + request.getParameter("toYearacademicYear3"));
        staff.setPassword(RandomStringUtils.randomAlphanumeric(10));
        staff.setUsername(staff.getEmailid());

        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");

        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                log.error("Captcha is valid..Great!");
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        staffValidator.validateRegistration(staff, result);

        if (result.hasErrors()) {
            staffService.formAddOptionvalues(model);
            return new ModelAndView("admin/staffMgmt/registration", model);
        }

        if (file1.isEmpty()) {
            staffService.formAddOptionvalues(model);
            model.addAttribute("formerror", "file is Empty");
            return new ModelAndView("admin/staffMgmt/registration", model);
        } else {
            if (!isResponseCorrect) { //Capatcha is not correct
                staffService.formAddOptionvalues(model);
                model.addAttribute("formerror", "Capacth is Invalid");
                return new ModelAndView("admin/staffMgmt/registration", model);
            } else {

                if ((usersService.userDetailsCheck(staff.getUsername(), "username").size() < 1)
                        && (usersService.userDetailsCheck(staff.getEmailid(), "emailid").size() < 1)) {
//Checking Username & emailid details

                    staffService.saveStaff(staff);

                    Users user = new Users();
                    user.setUsername(staff.getUsername());
                    user.setEnabled(true);
                    user.setPassword(staff.getPassword());
                    user.setUsertype("STAFF");
                    user.setEmailid(staff.getEmailid());

                    //Saving into Common Users Table
                    usersService.AddNewUser(user);

                    List<Staff> staffDetails = staffService.findStaffByUserid(staff.getUsername());
                    ResourceBundle bundle = ResourceBundle.getBundle("messages");
                    String rootwebapp = bundle.getString("webapp.root");

                    String filename = file1.getOriginalFilename().toString();

                    int dotPosi = filename.lastIndexOf(".");
                    String extension = filename.substring(dotPosi);
                    String NewFilename = Long.toString(staffDetails.get(0).getId()) + extension;
                    String profPhotoContextPath = "/profile_photos/staff/" + NewFilename;
                    String profPhotoAbsolutePathName = rootwebapp + profPhotoContextPath;

                    file1.transferTo(new File(profPhotoAbsolutePathName));
                    staff.setId(staffDetails.get(0).getId());
                    staff.setProfilePhotoFileName(NewFilename);

                    staffService.updateStaff(staff);

                    model.addAttribute("profPhotoAbsolutePathName", profPhotoAbsolutePathName);
                    return new ModelAndView("admin/staffMgmt/registrationSuccess", model);

                } else {
                    staffService.formAddOptionvalues(model);
                    model.addAttribute("formerror", "User with given details already exists. <br> Please change username & email ids <br>");
                    return new ModelAndView("admin/staffMgmt/registration", model);
                }
            }

        }

    }

    @RequestMapping("/AdminStaffProfSearch.htm")
    public ModelAndView staffSearch(ModelMap model, @ModelAttribute("staff") Staff staff, @ModelAttribute("staff1") Staff staff1) {

        model.addAttribute("staff", new Staff());
        List<Staff> staffSearch = staffService.searchStaff(staff1);
        model.addAttribute("staffSearch", staffSearch);

        return new ModelAndView("admin/staffMgmt/profileSearch", model);

    }

    @RequestMapping("/AdminStaffProfUpdate.htm")
    public ModelAndView AdminStaffUpdate(
            ModelMap model,
            @ModelAttribute("staff") Staff staff,
            @RequestParam("selection") int selection) {
        if (selection != 0) {

            staff.setId(selection);

            staffService.retrieveStaff(staff);

            String JoiningDate = staff.getJoiningDate();
            String[] splitedDate = JoiningDate.split("/");
            //10/05/2010

            model.addAttribute("joiningday", splitedDate[0]);
            model.addAttribute("joiningmonth", splitedDate[1]);
            model.addAttribute("joiningyear", splitedDate[2]);

            String DateofBirth = staff.getDateofbirth();
            String[] splitDateofBirth = DateofBirth.split("/");

            model.addAttribute("bday", splitDateofBirth[0]);
            model.addAttribute("bmonth", splitDateofBirth[1]);
            model.addAttribute("byear", splitDateofBirth[2]);

            String AcadYear1 = staff.getAcademicYear1();
            String[] splitAcadYear1 = AcadYear1.split("[/\\-]");

            model.addAttribute("formmonthacademicYear1", splitAcadYear1[0]);
            model.addAttribute("formYearacademicYear1", splitAcadYear1[1]);
            model.addAttribute("tomonthacademicYear1", splitAcadYear1[2]);
            model.addAttribute("toYearacademicYear1", splitAcadYear1[3]);

            String AcadYear2 = staff.getAcademicYear2();
            String[] splitAcadYear2 = AcadYear2.split("[/\\-]");

            model.addAttribute("formmonthacademicYear2", splitAcadYear2[0]);
            model.addAttribute("formYearacademicYear2", splitAcadYear2[1]);
            model.addAttribute("tomonthacademicYear2", splitAcadYear2[2]);
            model.addAttribute("toYearacademicYear2", splitAcadYear2[3]);

            String AcadYear3 = staff.getAcademicYear3();
            String[] splitAcadYear3 = AcadYear3.split("[/\\-]");

            model.addAttribute("formmonthacademicYear3", splitAcadYear3[0]);
            model.addAttribute("formYearacademicYear3", splitAcadYear3[1]);
            model.addAttribute("tomonthacademicYear3", splitAcadYear3[2]);
            model.addAttribute("toYearacademicYear3", splitAcadYear3[3]);

            String Duration1 = staff.getDuration1();
            String[] splitDur1 = Duration1.split("[/\\-]");

            model.addAttribute("formmonthduration1", splitDur1[0]);
            model.addAttribute("formYearduration1", splitDur1[1]);
            model.addAttribute("tomonthduration1", splitDur1[2]);
            model.addAttribute("toYearduration1", splitDur1[3]);

            String Duration2 = staff.getDuration2();
            String[] splitDur2 = Duration2.split("[/\\-]");

            model.addAttribute("formmonthduration2", splitDur2[0]);
            model.addAttribute("formYearduration2", splitDur2[1]);
            model.addAttribute("tomonthduration2", splitDur2[2]);
            model.addAttribute("toYearduration2", splitDur2[3]);

            model.addAttribute("staff", staff);
            model.addAttribute("selection", selection);

            Users user = new Users();
            user.setUsername(staff.getUsername());
            user.setPassword(staff.getPassword());

            List<Users> userdetails = usersService.userLoginCheck(user);
            long userid = userdetails.get(0).getId();

            staffService.formAddOptionvalues(model);
            String formerror = "";
            model.addAttribute("formerror", formerror);

            return new ModelAndView("admin/staffMgmt/profileUpdate", "userid", userid);
        } else {
            return new ModelAndView("admin/staffMgmt/profileSearch", model);
        }

    }

    @RequestMapping(value = "/AdminStaffProfUpdateDone.htm")
    public ModelAndView AdminStaffUpdateSuccess(
            @ModelAttribute("staff") Staff staff, BindingResult result, ModelMap model,
            HttpServletRequest request,
            //@RequestParam("userid") int userid,//user's Primary Key
            @RequestParam("file1") MultipartFile file1,
            @RequestParam("selection") int selection) throws Exception {
        
         if (selection != 0) {


             staff.setDateofbirth(request.getParameter("bday") + "/" + request.getParameter("bmonth") + "/" + request.getParameter("byear"));
        staff.setJoiningDate(request.getParameter("joiningday") + "/" + request.getParameter("joiningmonth") + "/" + request.getParameter("joiningyear"));
        staff.setDuration1(request.getParameter("formmonthduration1") + "/" + request.getParameter("formYearduration1") + "-" + request.getParameter("tomonthduration1") + "/" + request.getParameter("toYearduration1"));
        staff.setDuration2(request.getParameter("formmonthduration2") + "/" + request.getParameter("formYearduration2") + "-" + request.getParameter("tomonthduration2") + "/" + request.getParameter("toYearduration2"));

        staff.setAcademicYear1(request.getParameter("formmonthacademicYear1") + "/" + request.getParameter("formYearacademicYear1") + "-" + request.getParameter("tomonthacademicYear1") + "/" + request.getParameter("toYearacademicYear1"));
        staff.setAcademicYear2(request.getParameter("formmonthacademicYear2") + "/" + request.getParameter("formYearacademicYear2") + "-" + request.getParameter("tomonthacademicYear2") + "/" + request.getParameter("toYearacademicYear2"));
        staff.setAcademicYear3(request.getParameter("formmonthacademicYear3") + "/" + request.getParameter("formYearacademicYear3") + "-" + request.getParameter("tomonthacademicYear3") + "/" + request.getParameter("toYearacademicYear3"));

        staff.setUsername(staff.getEmailid());
        staff.setId(selection);

        List<Staff> staffOldDetails = staffService.findStaffByID(selection);
        staff.setPassword(staffOldDetails.get(0).getPassword());
        staff.setProfilePhotoFileName(staffOldDetails.get(0).getProfilePhotoFileName());


        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");

        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                log.error("Captcha is valid..Great!");
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        staffValidator.validateRegistration(staff, result);


        if (result.hasErrors()) {
            staffService.formAddOptionvalues(model);
            return new ModelAndView("admin/staffMgmt/profileUpdate");
        }


        if (!isResponseCorrect) {
            staffService.formAddOptionvalues(model);
            return new ModelAndView("admin/staffMgmt/profileUpdate", "captchaerror", "Invalid Captcha");
        } else {

            List<Users> userDetails = usersService.userDetailsCheck(staff.getUsername(), "username");

            Users user = new Users();
            user.setId(userDetails.get(0).getId());
            user.setUsername(staff.getUsername());
            user.setEnabled(userDetails.get(0).isEnabled());
            user.setPassword(staff.getPassword());
            user.setEmailid(staff.getEmailid());
            user.setUsertype("STAFF");


            if (!file1.isEmpty()) {

                 ResourceBundle bundle = ResourceBundle.getBundle("messages");
                    String rootwebapp = bundle.getString("webapp.root");

                    String filename = file1.getOriginalFilename().toString();

                    int dotPosi = filename.lastIndexOf(".");
                    String extension = filename.substring(dotPosi);
                    String NewFilename = Long.toString(staff.getId()) + extension;
                    String profPhotoContextPath = "/profile_photos/staff/" + NewFilename;
                    String profPhotoAbsolutePathName = rootwebapp + profPhotoContextPath;

                    file1.transferTo(new File(profPhotoAbsolutePathName));
                    staff.setProfilePhotoFileName(NewFilename);

            }else

            usersService.UpdateUser(user);
            staffService.updateStaff(staff);

            return new ModelAndView("admin/staffMgmt/profileUpdateDone");

         }

        
        }
         else
         {
              return new ModelAndView("admin/staffMgmt/profileSearch", model);
         }
    }





    
    
    @RequestMapping("/AdminLMSearchLeaves.htm")
    public ModelAndView LMSearchLeaves(ModelMap modelMap) {

        modelMap.addAttribute("leaveApplication1", new LeaveApplication());

        staffService.formAddOptionvalues(modelMap);


        return new ModelAndView("admin/leaveMgmt/searchLeaves", modelMap);

    }

    @RequestMapping(value = "/AdminLMSearchResult.htm")
    public ModelAndView AdminLMSearchResult(HttpServletRequest request, ModelMap modelMap,
            @ModelAttribute("leaveApplication1") LeaveApplication leaveApplication1) {

        request.getSession().setAttribute("leaveApplication1_session", leaveApplication1);
        modelMap.addAttribute("leaveApplication", new LeaveApplication());
        leaveApplication1.setAppliedDate(request.getParameter("appliedday") + "/" + request.getParameter("appliedmonth") + "/" + request.getParameter("appliedyear"));
        List<LeaveApplication> SearchLeaves = staffService.LMSearchLeaves(leaveApplication1);
        modelMap.addAttribute("SearchLeaves", SearchLeaves);


        return new ModelAndView("admin/leaveMgmt/searchResult", modelMap);

    }

    @RequestMapping(value = "/AdminLMSearchResultback.htm")
    public ModelAndView AdminLMSearchResultBack(HttpServletRequest request, ModelMap modelMap) {
        LeaveApplication leaveApplication1 = (LeaveApplication) request.getSession().getAttribute("leaveApplication1_session");
        modelMap.addAttribute("leaveApplication", new LeaveApplication());
        List<LeaveApplication> SearchLeaves = staffService.LMSearchLeaves(leaveApplication1);
        modelMap.addAttribute("SearchLeaves", SearchLeaves);


        return new ModelAndView("admin/leaveMgmt/searchResult", modelMap);

    }

    @RequestMapping("/AdminLMDeleteLeaveResult.htm")
    public ModelAndView AdminLMDeleteResult(
            ModelMap model,
            @ModelAttribute("leaveApplication") LeaveApplication leaveApplication,
            @RequestParam("selection") int selection) {

        if (selection != 0) {
            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));
            leaveApplication = leaveAppDetailsList.get(0);

            staffService.deleteLeaveApplication(leaveApplication);

            return new ModelAndView("admin/leaveMgmt/deleteLeaveResult", model);
        } else {
            return new ModelAndView("admin/leaveMgmt/searchResult", model);
        }

    }

    @RequestMapping("/AdminLMLeaveUpdation.htm")
    public ModelAndView LeaveUpdation(
            ModelMap model,
            @ModelAttribute("leaveApplication") LeaveApplication leaveApplication,
            @RequestParam("selection") int selection) {

        if (selection != 0) {
            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));
            LeaveApplication leaveAppDetails = new LeaveApplication();
            leaveAppDetails = leaveAppDetailsList.get(0);


            String duration = leaveAppDetails.getDuration();
            String[] splitedDur = duration.split("[\\;/\\-]");
            //"9:00 AM;1/1/1900-6:00 PM;2/3/1901";

            model.addAttribute("fromtime", splitedDur[0]);
            model.addAttribute("fromday", splitedDur[1]);
            model.addAttribute("frommonth", splitedDur[2]);
            model.addAttribute("fromyear", splitedDur[3]);

            model.addAttribute("totime", splitedDur[4]);
            model.addAttribute("today", splitedDur[5]);
            model.addAttribute("tomonth", splitedDur[6]);
            model.addAttribute("toyear", splitedDur[7]);
            model.addAttribute("selection", selection);
            model.addAttribute("leaveAppDetails", leaveAppDetails);

            staffService.formAddOptionvalues(model);

            return new ModelAndView("admin/leaveMgmt/leaveUpdation", model);
        } else {
            return new ModelAndView("admin/leaveMgmt/searchResult", model);
        }

    }

    @RequestMapping("/AdminLMLeaveUpdationSucess.htm")
    public ModelAndView AdminLeaveUpdationSucess(
            ModelMap model,
            @ModelAttribute("leaveApplication") LeaveApplication leaveApplication,
            HttpServletRequest request,
            @RequestParam("selection") int selection) {

        if (selection != 0) {

            List<LeaveApplication> leaveAppDetailsList = staffService.findLeaveApplicationById((selection));

            Date currentDate = new Date();
            DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

            leaveApplication.setId(selection);
            leaveApplication.setStatusDate(dateFormat.format(currentDate).toString());
            leaveApplication.setStatusTime(currentTime.format(currentDate).toString());
            leaveApplication.setAppliedDate(leaveAppDetailsList.get(0).getAppliedDate());
            leaveApplication.setReportingAuthority(leaveAppDetailsList.get(0).getReportingAuthority());
            leaveApplication.setUsername(leaveAppDetailsList.get(0).getUsername());
            leaveApplication.setStatus("Accepted");
            leaveApplication.setRemarks(leaveAppDetailsList.get(0).getRemarks());
            leaveApplication.setDuration(request.getParameter("fromtime") + ";" + request.getParameter("fromday") + "/"
                    + request.getParameter("frommonth") + "/" + request.getParameter("fromyear") + "-" + request.getParameter("totime") + ";" + request.getParameter("today") + "/" + request.getParameter("tomonth") + "/" + request.getParameter("toyear"));


            staffService.saveLeaveApplication(leaveApplication);
            List<Staff> staffDetails = staffService.findStaffByUserid(leaveApplication.getUsername());

            Staff staff = new Staff();
            staff.setFirstname(staffDetails.get(0).getFirstname());
            staff.setLastname(staffDetails.get(0).getLastname());
            staff.setDesignation(staffDetails.get(0).getDesignation());

            List<Staff> RADetails = staffService.findStaffByUserid(leaveApplication.getReportingAuthority());

            Staff RA = new Staff();
            RA.setFirstname(RADetails.get(0).getFirstname());
            RA.setLastname(RADetails.get(0).getLastname());

            EmailDetails emailDetails = new EmailDetails();
            emailDetails.setTo(staffDetails.get(0).getEmailid());
            emailDetails.setCC(RADetails.get(0).getEmailid());
            emailDetails.setFrom("ramana.miryala@gmail.com");
            emailDetails.setSubject("Admin LM Leave Updation Sucess details");
            emailDetails.setVMTemplate("LeaveEmailTempate.vm");

            String[] InlineFilenames = new String[1];
            InlineFilenames[0] = "F:/Haritha_Tech_Project/Java_systemwithsecurity/web/img/medicalcollegeLogo.jpg";

            emailDetails.setAddInline(InlineFilenames);

            String[] AttachmentFilenames = new String[1];
            AttachmentFilenames[0] = null;

            emailDetails.setAttachment(AttachmentFilenames);
            model.addAttribute("RA", RA);
            model.addAttribute("staff", staff);
            model.addAttribute("leaveApplication", leaveApplication);

            emailSender.sendEmail(model, emailDetails);


            return new ModelAndView("admin/leaveMgmt/leaveUpdationSuccess", model);
        } else {
            return new ModelAndView("admin/leaveMgmt/leaveUpdation", model);
        }
    }

    @RequestMapping(value = "/AdminLMLeaveUpdationCancel.htm")
    public ModelAndView AdminLeaveUpdationCancel(ModelMap modelMap, @ModelAttribute("leaveApplication") LeaveApplication leaveApplication, @ModelAttribute("leaveApplication1") LeaveApplication leaveApplication1) {

        modelMap.addAttribute("leaveApplication", new LeaveApplication());
        List<LeaveApplication> SearchLeaves = staffService.LMSearchLeaves(leaveApplication1);
        modelMap.addAttribute("SearchLeaves", SearchLeaves);

        return new ModelAndView("admin/leaveMgmt/searchResult", modelMap);

    }

    @RequestMapping(value = "/AdminLMSpecialLeavesApplication.htm")
    public ModelAndView AdminSpecialLeaveApplication(ModelMap modelMap) {
        LeaveApplication leaveApplication = new LeaveApplication();


        Date currentDate = new Date();
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

        String[] splitedDate = (dateFormat.format(currentDate).toString()).split("/");

        modelMap.addAttribute("fromday", splitedDate[0]);
        modelMap.addAttribute("frommonth", splitedDate[1]);
        modelMap.addAttribute("fromyear", splitedDate[2]);

        modelMap.addAttribute("today", splitedDate[0]);
        modelMap.addAttribute("tomonth", splitedDate[1]);
        modelMap.addAttribute("toyear", splitedDate[2]);
        modelMap.addAttribute("leaveApplication", leaveApplication);
        staffService.formAddOptionvalues(modelMap);
        String formerror = "";
        modelMap.addAttribute("formerror", formerror);
        return new ModelAndView("admin/leaveMgmt/specialLeavesApplication", modelMap);
    }

    @RequestMapping(value = "/AdminLMSpecialLeaveSuccess.htm")
    public ModelAndView AdminSpecialLeaveSuccess(
            @ModelAttribute("leaveApplicatin") LeaveApplication leaveApplication,
            BindingResult result, ModelMap model,
            HttpServletRequest request) throws Exception {


        List<Staff> staffDetails = staffService.findStaffByUserid(leaveApplication.getUsername());
        if (staffDetails == null) {
            return new ModelAndView("admin/leaveMgmt/specialLeavesApplication", model);

        } else {

            leaveApplication.setDuration(request.getParameter("fromtime") + ";" + request.getParameter("fromday") + "/"
                    + request.getParameter("frommonth") + "/" + request.getParameter("fromyear") + "-" + request.getParameter("totime") + ";" + request.getParameter("today") + "/" + request.getParameter("tomonth") + "/" + request.getParameter("toyear"));


            //List<LeaveApplication> staffDetails = staffService.findLeaveApplicationByUsername(leaveApplication.getUsername());
            String staffEmailId = staffDetails.get(0).getEmailid();
            String ReportingAuthUsername = staffDetails.get(0).getReportingAuthority();

            List<Staff> RADetails = staffService.findStaffByUserid(ReportingAuthUsername);
            String RAEmailId = RADetails.get(0).getEmailid();

            // Checking Capatch Response
            boolean isResponseCorrect = false;
            String captchaId = request.getSession().getId();
            String response = request.getParameter("j_captcha_response");
            try {
                if (response != null) {
                    isResponseCorrect = captchaService.validateResponseForID(captchaId, response);

                }

            } catch (CaptchaServiceException e) {
                log.error("Problem Jcaptcha settings ", e);
            }

            staffValidator.validateLeaveApplication(leaveApplication, result);

            if (result.hasErrors()) {
                staffService.formAddOptionvalues(model);
                return new ModelAndView("admin/leaveMgmt/specialLeavesApplication", model);
            } else {
                if (!isResponseCorrect) { //Capatcha is not correct
                    staffService.formAddOptionvalues(model);
                    model.addAttribute("formerror", "Capacth is Invalid");
                    return new ModelAndView("admin/leaveMgmt/specialLeavesApplication", model);
                } else {
                    Date currentDate = new Date();
                    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                    DateFormat currentTime = new SimpleDateFormat("HH:mm:ss");

                    leaveApplication.setAppliedDate(dateFormat.format(currentDate).toString());
                    leaveApplication.setStatusDate(dateFormat.format(currentDate).toString());
                    leaveApplication.setStatusTime(currentTime.format(currentDate).toString());
                    leaveApplication.setStatus("In Process");
                    leaveApplication.setReportingAuthority(ReportingAuthUsername);
                    leaveApplication.setUsername(staffDetails.get(0).getUsername());
                    leaveApplication.setRemarks(" ");

                    staffService.saveLeaveApplication(leaveApplication);


                    Staff staff = new Staff();
                    staff.setFirstname(staffDetails.get(0).getFirstname());
                    staff.setLastname(staffDetails.get(0).getLastname());
                    staff.setDesignation(staffDetails.get(0).getDesignation());

                    Staff RA = new Staff();
                    RA.setFirstname(RADetails.get(0).getFirstname());
                    RA.setLastname(RADetails.get(0).getLastname());

                    EmailDetails emailDetails = new EmailDetails();

                    emailDetails.setTo(staffDetails.get(0).getEmailid());
                    emailDetails.setCC(RAEmailId);
                    emailDetails.setFrom("ramana.miryala@gmail.com");
                    emailDetails.setSubject(" Admin LM SpecialLeave details ");
                    emailDetails.setVMTemplate("LeaveEmailTempate.vm");

                    String[] InlineFilenames = new String[1];
                    InlineFilenames[0] = "F:/Haritha_Tech_Project/Java_systemwithsecurity/web/img/medicalcollegeLogo.jpg";

                    emailDetails.setAddInline(InlineFilenames);

                    String[] AttachmentFilenames = new String[1];
                    AttachmentFilenames[0] = null;

                    emailDetails.setAttachment(AttachmentFilenames);
                    model.addAttribute("RA", RA);
                    model.addAttribute("staff", staff);
                    model.addAttribute("leaveApplication", leaveApplication);


                    emailSender.sendEmail(model, emailDetails);


                    List<LeaveSummary> leavesummaryDetails = staffService.findleaveSummaryByUsername(leaveApplication.getUsername());
                    LeaveSummary leaveSummary = new LeaveSummary();
                    leaveSummary = leavesummaryDetails.get(0);


                    if (leaveApplication.getTypeOfLeave().equals("CCL")) {
                        int appliedleaves = leaveSummary.getCclAppliedNo() + 1;
                        leaveSummary.setCclAppliedNo(appliedleaves);
                    } else if (leaveApplication.getTypeOfLeave().equals("SL")) {
                        int appliedleaves = leaveSummary.getSlAppliedNo() + 1;
                        leaveSummary.setSlAppliedNo(appliedleaves);
                    } else if (leaveApplication.getTypeOfLeave().equals("CL")) {
                        int appliedleaves = leaveSummary.getClAppliedNo() + 1;
                        leaveSummary.setClAppliedNo(appliedleaves);
                    } else if (leaveApplication.getTypeOfLeave().equals("SPCL")) {
                        int appliedleaves = leaveSummary.getSpclAppliedNo() + 1;
                        leaveSummary.setSpclAppliedNo(appliedleaves);
                    } else if (leaveApplication.getTypeOfLeave().equals("EL")) {
                        int appliedleaves = leaveSummary.getElAppliedNo() + 1;
                        leaveSummary.setElAppliedNo(appliedleaves);
                    }

                    staffService.saveLeaveSummary(leaveSummary);

                    return new ModelAndView("admin/leaveMgmt/specialLeaveSuccess", model);
                }
            }
        }


    }
}











