package com.suman.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.suman.security.UsersService;
import com.suman.service.StudentService;
import com.suman.domain.Student;
import com.suman.domain.StdBaseProfile;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StudentValidator implements Validator {

//        private UsersService usersService;
//        private StudentService studentService;

    @Override
    public boolean supports(Class clazz) {
        return Student.class.isAssignableFrom(clazz);
    }

    
//    public StudentValidator(UsersService usersService, StudentService studentService) {
//        this.usersService = usersService;
//        this.studentService = studentService;
//    }

    @Override
    public void validate(Object target, Errors errors) {
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "name.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "password.required");
    }

    //@Override
    public void validateRegistration(Object obj, Errors errors) {

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "name", "name.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "password.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "year1", "year1.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "rno", "rno.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "studentAddress", "studentAddress.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "parentAddress", "parentAddress.required");

    }

    //@Override
    public void loginFail(Object target, Errors errors) {
        errors.rejectValue("password", "passwordwrong.required");
    }

    public void validateStdBaseProfile(Object obj, Errors errors)
    {
        StdBaseProfile stdBaseProfile =(StdBaseProfile) obj;

        NameCheck(errors,stdBaseProfile.getFirstName(),"firstName", "firstName.required", "firstName.notValid");
        NameCheck(errors,stdBaseProfile.getLastName(),"lastName", "lastName.required", "lastName.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "sex", "sex.required");

        PhoneCheck(errors,stdBaseProfile.getPhoneNumber(),"phoneNumber", "phoneNumber.required", "phoneNumber.notValid");
        EmailCheck(errors,stdBaseProfile.getEmailId(),"emailId", "emailId.required","emailId.notValid");
        

     ValidationUtils.rejectIfEmptyOrWhitespace(errors,"universityRegistered","universityRegistered.required");

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "collegeRegistrationNumber", "collegeRegistrationNumber.required");

        
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "courseName", "courseName.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "courseYear", "courseYear.required");

        AcademicYearCheck(errors,stdBaseProfile.getJoiningAcademicYear(), "joiningAcademicYear", "joiningAcademicYear.required", "joiningAcademicYear.notValid");

        NameCheck(errors,stdBaseProfile.getParentsName(),"parentsName", "parentsName.required","parentsName.notValid");
        EmailCheck(errors,stdBaseProfile.getParentsEmailid(),"parentsEmailid", "parentsEmailid.required","parentsEmailid.notValid");

        if(stdBaseProfile.getParentsEmailid().equals(stdBaseProfile.getEmailId()))
        {
            errors.rejectValue("parentsEmailid", "parentsEmailid.sameEmailid");
        }

        PhoneCheck(errors,stdBaseProfile.getParentsPhoneNumber(),"parentsPhoneNumber", "parentsPhoneNumber.required", "parentsPhoneNumber.notValid");


    }
    public void validateStudentRegPageFirst(Object obj, Errors errors)
    {
        Student std = (Student) obj;


        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "admissionNo", "admissionNo.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "courseJoined", "courseJoined.required");
        DateCheck(errors, std.getAdmissionDate(), "admissionDate", "admissionDate.required", "admissionDate.notValid");
 
        NameCheck(errors,std.getFirstName(),"firstName", "firstName.required", "firstName.notValid");
        NameCheck(errors,std.getLastName(),"lastName", "lastName.required", "lastName.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "sex", "sex.required");
        
        DateCheck(errors, std.getDateofBirth(), "dateofBirth", "dateofBirth.required", "dateofBirth.notValid");
        NameCheck(errors,std.getMotherTounge(),"motherTounge", "motherTounge.required","motherTounge.notValid");
        NameCheck(errors,std.getNationality(),"nationality", "nationality.required","nationality.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "religion", "religion.required");

        PhoneCheck(errors,std.getMobileNumber(),"mobileNumber", "mobileNumber.required", "mobileNumber.notValid");
        EmailCheck(errors,std.getEmailId(),"emailId", "emailId.required","emailId.notValid");

    }

    public void validateStudentRegPageSecond(Object obj, Errors errors)
    {
        Student std = (Student) obj;


        NameCheck(errors,std.getParentsName(),"parentsName", "parentsName.required","parentsName.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "parentsOccupation", "parentsOccupation.required");
        NumberCheck(errors,std.getParentsAnnualIncome(),"parentsAnnualIncome", "parentsAnnualIncome.required", "parentsAnnualIncome.notValid");


        AddressCheck(errors,std.getCurrentAddress(), "currentAddress", "currentAddress.required","currentAddress.notValid");

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "currentLocation", "currentLocation.required");
        NameCheck(errors,std.getCurrentDistrict(),"currentDistrict", "currentDistrict.required","currentDistrict.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "currentState", "currentState.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "currentCountry", "currentCountry.required");

        PINCodeCheck(errors,std.getCurrentPincode(), "currentPincode","currentPincode.required", "currentPincode.notValid");
        PhoneCheck(errors,std.getCurrentPhoneNumber(),"currentPhoneNumber", "currentPhoneNumber.required","currentPhoneNumber.notValid");

        AddressCheck(errors,std.getPermanentAddress(), "permanentAddress", "permanentAddress.required","permanentAddress.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "permanentLocation", "permanentLocation.required");
        NameCheck(errors,std.getPermanentDistrict(),"permanentDistrict", "permanentDistrict.required","permanentDistrict.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "permanentState", "permanentState.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "permanentCountry", "permanentCountry.required");

        PINCodeCheck(errors,std.getPermanentPincode(), "permanentPincode","permanentPincode.required", "permanentPincode.notValid");
        PhoneCheck(errors,std.getPermanentPhoneNumber(),"permanentPhoneNumber", "permanentPhoneNumber.required","permanentPhoneNumber.notValid");

        AddressCheck(errors,std.getParentsCorrespondenceAddress(), "parentsCorrespondenceAddress", "parentsCorrespondenceAddress.required","parentsCorrespondenceAddress.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "parentsCorrespondenceAddress", "parentsCorrespondenceAddress.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "parentsCorrespondenceLocation", "parentsCorrespondenceLocation.required");
        NameCheck(errors,std.getParentsCorrespondenceDistrict(),"parentsCorrespondenceDistrict", "parentsCorrespondenceDistrict.required","parentsCorrespondenceDistrict.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "parentsCorrespondenceState", "parentsCorrespondenceState.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "parentsCorrespondenceCountry", "parentsCorrespondenceCountry.required");


        PINCodeCheck(errors,std.getParentsCorrespondencePincode(), "parentsCorrespondencePincode","parentsCorrespondencePincode.required", "parentsCorrespondencePincode.notValid");

        PhoneCheck(errors,std.getParentsCorrespondencePhoneNumber(),"parentsCorrespondencePhoneNumber", "parentsCorrespondencePhoneNumber.required","parentsCorrespondencePhoneNumber.notValid");
        EmailCheck(errors,std.getParentsEmailid(),"parentsEmailid", "parentsEmailid.required","parentsEmailid.notValid");
        if(std.getParentsEmailid().equals(std.getEmailId()))
        {
            errors.rejectValue("parentsEmailid","parentsEmailid.sameEmailid");
        }


    }

    public void validateStudentRegPageThird(Object obj, Errors errors)
    {
        Student std = (Student) obj;

       ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nameQE", "nameQE.required");

        AcademicYearCheck(errors, std.getAcedamicYearStudiedQE(), "acedamicYearStudiedQE", "acedamicYearStudiedQE.required", "acedamicYearStudiedQE.notValid");

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "hallTicketNoQE", "hallTicketNoQE.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "passingGradeQE", "passingGradeQE.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "subjectsQE", "subjectsQE.required");

        MarksErrorsCheck(errors, std.getEnglishMarksObtainedQE(), "englishMarksObtainedQE", "englishMarksObtainedQE.required", "englishMarksObtainedQE.notValid");
        MarksErrorsCheck(errors, std.getSanskritMarksObtainedQE(), "sanskritMarksObtainedQE", "sanskritMarksObtainedQE.required", "sanskritMarksObtainedQE.notValid");
        MarksErrorsCheck(errors, std.getBotanyMarksObtainedQE(), "botanyMarksObtainedQE", "botanyMarksObtainedQE.required", "botanyMarksObtainedQE.notValid");
        MarksErrorsCheck(errors, std.getZoologyMarksObtainedQE(), "zoologyMarksObtainedQE", "zoologyMarksObtainedQE.required", "zoologyMarksObtainedQE.notValid");
        MarksErrorsCheck(errors, std.getPhysicsMarksObtainedQE(), "physicsMarksObtainedQE", "physicsMarksObtainedQE.required", "physicsMarksObtainedQE.notValid");
        MarksErrorsCheck(errors, std.getChemistryMarksObtainedQE(), "chemistryMarksObtainedQE", "chemistryMarksObtainedQE.required", "chemistryMarksObtainedQE.notValid");

        MarksErrorsCheck(errors, std.getMaxEnglishMarksQE(), "maxEnglishMarksQE", "maxEnglishMarksQE.required", "maxEnglishMarksQE.notValid");
        MarksErrorsCheck(errors, std.getSanskritMarksObtainedQE(), "maxSanskritMarksQE", "maxSanskritMarksQE.required", "maxSanskritMarksQE.notValid");
        MarksErrorsCheck(errors, std.getMaxBotanyMarksQE(), "maxBotanyMarksQE", "maxBotanyMarksQE.required", "maxBotanyMarksQE.notValid");
        MarksErrorsCheck(errors, std.getMaxZoologyMarksQE(), "maxZoologyMarksQE", "maxZoologyMarksQE.required", "maxZoologyMarksQE.notValid");
        MarksErrorsCheck(errors, std.getMaxphysicsMarksQE(), "maxphysicsMarksQE", "maxphysicsMarksQE.required", "maxphysicsMarksQE.notValid");
        MarksErrorsCheck(errors, std.getMaxEnglishMarksQE(), "maxchemistryMarksQE", "maxchemistryMarksQE.required", "maxchemistryMarksQE.notValid");

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "hallTicketEntranceExam", "hallTicketEntranceExam.required");
        NumberCheck(errors,std.getRankEntranceExam(),"rankEntranceExam", "rankEntranceExam.required", "rankEntranceExam.notValid");


        AcademicYearCheck(errors, std.getClassVIAcademicYear(), "classVIAcademicYear", "classVIAcademicYear.required", "classVIAcademicYear.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "classVISchool", "classVISchool.required");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors,"classVIRemarks","classVIRemarks.required");


        AcademicYearCheck(errors, std.getClassVIIAcademicYear(), "classVIIAcademicYear", "classVIIAcademicYear.required", "classVIIAcademicYear.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "classVIISchool", "classVIISchool.required");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors,"classVIIRemarks","classVIIRemarks.required");

        AcademicYearCheck(errors, std.getClassVIIIAcademicYear(), "classVIIIAcademicYear", "classVIIIAcademicYear.required", "classVIIIAcademicYear.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "classVIIISchool", "classVIIISchool.required");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors,"classVIIIRemarks","classVIIIRemarks.required");

        AcademicYearCheck(errors, std.getClassIXAcademicYear(), "classIXAcademicYear", "classIXAcademicYear.required", "classIXAcademicYear.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "classIXSchool", "classIXSchool.required");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors,"classIXRemarks","classIXRemarks.required");

        AcademicYearCheck(errors, std.getClassXAcademicYear(), "classXAcademicYear", "classXAcademicYear.required", "classXAcademicYear.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "classXSchool", "classXSchool.required");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors,"classXRemarks","classXRemarks.required");

        AcademicYearCheck(errors, std.getClassXIAcademicYear(), "classXIAcademicYear", "classXIAcademicYear.required", "classXIAcademicYear.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "classXICollege", "classXICollege.required");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors,"classXIRemarks","classXIRemarks.required");


        AcademicYearCheck(errors, std.getClassXIIAcademicYear(), "classXIIAcademicYear", "classXIIAcademicYear.required", "classXIIAcademicYear.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "classXIICollege", "classXIICollege.required");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors,"classXIIRemarks","classXIIRemarks.required");


        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dobCertificate", "dobCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "interMemoCertificate", "interMemoCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "studyCertificate", "studyCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "transferCertificate", "transferCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "conductCertificate", "conductCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "casteCertificate", "casteCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "eamcetRankCertificate", "eamcetRankCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "eamcetHallTicketCertificate", "eamcetHallTicketCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "photosCheck", "photosCheck.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "otherCertificate", "otherCertificate.required");


    }

    //@Override
    public void validateStudentRegistration(Object obj, Errors errors) {

        Student std = (Student) obj;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "admissionNo", "admissionNo.required");


        DateCheck(errors, std.getAdmissionDate(), "admissionDate", "admissionDate.required", "admissionDate.notValid");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors,"profilePhotoFileName","profilePhotoFileName.required");

        NameCheck(errors,std.getFirstName(),"firstName", "firstName.required", "firstName.notValid");
        NameCheck(errors,std.getLastName(),"lastName", "lastName.required", "lastName.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "sex", "sex.required");
        NameCheck(errors,std.getParentsName(),"parentsName", "parentsName.required","parentsName.notValid");


        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "parentsOccupation", "parentsOccupation.required");

        NumberCheck(errors,std.getParentsAnnualIncome(),"parentsAnnualIncome", "parentsAnnualIncome.required", "parentsAnnualIncome.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "courseJoined", "courseJoined.required");
        

        DateCheck(errors, std.getDateofBirth(), "dateofBirth", "dateofBirth.required", "dateofBirth.notValid");
        NameCheck(errors,std.getMotherTounge(),"motherTounge", "motherTounge.required","motherTounge.notValid");
        NameCheck(errors,std.getNationality(),"nationality", "nationality.required","nationality.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "religion", "religion.required");


        PhoneCheck(errors,std.getMobileNumber(),"mobileNumber", "mobileNumber.required", "mobileNumber.notValid");
        EmailCheck(errors,std.getEmailId(),"emailId", "emailId.required","emailId.notValid");




        AddressCheck(errors,std.getCurrentAddress(), "currentAddress", "currentAddress.required","currentAddress.notValid");

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "currentLocation", "currentLocation.required");
        NameCheck(errors,std.getCurrentDistrict(),"currentDistrict", "currentDistrict.required","currentDistrict.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "currentState", "currentState.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "currentCountry", "currentCountry.required");

        PINCodeCheck(errors,std.getCurrentPincode(), "currentPincode","currentPincode.required", "currentPincode.notValid");
        PhoneCheck(errors,std.getCurrentPhoneNumber(),"currentPhoneNumber", "currentPhoneNumber.required","currentPhoneNumber.notValid");

        AddressCheck(errors,std.getPermanentAddress(), "permanentAddress", "permanentAddress.required","permanentAddress.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "permanentLocation", "permanentLocation.required");
        NameCheck(errors,std.getPermanentDistrict(),"permanentDistrict", "permanentDistrict.required","permanentDistrict.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "permanentState", "permanentState.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "permanentCountry", "permanentCountry.required");

        PINCodeCheck(errors,std.getPermanentPincode(), "permanentPincode","permanentPincode.required", "permanentPincode.notValid");
        PhoneCheck(errors,std.getPermanentPhoneNumber(),"permanentPhoneNumber", "permanentPhoneNumber.required","permanentPhoneNumber.notValid");

        AddressCheck(errors,std.getParentsCorrespondenceAddress(), "parentsCorrespondenceAddress", "parentsCorrespondenceAddress.required","parentsCorrespondenceAddress.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "parentsCorrespondenceAddress", "parentsCorrespondenceAddress.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "parentsCorrespondenceLocation", "parentsCorrespondenceLocation.required");
        NameCheck(errors,std.getParentsCorrespondenceDistrict(),"parentsCorrespondenceDistrict", "parentsCorrespondenceDistrict.required","parentsCorrespondenceDistrict.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "parentsCorrespondenceState", "parentsCorrespondenceState.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "parentsCorrespondenceCountry", "parentsCorrespondenceCountry.required");


        PINCodeCheck(errors,std.getParentsCorrespondencePincode(), "parentsCorrespondencePincode","parentsCorrespondencePincode.required", "parentsCorrespondencePincode.notValid");

        PhoneCheck(errors,std.getParentsCorrespondencePhoneNumber(),"parentsCorrespondencePhoneNumber", "parentsCorrespondencePhoneNumber.required","parentsCorrespondencePhoneNumber.notValid");
        EmailCheck(errors,std.getParentsEmailid(),"parentsEmailid", "parentsEmailid.required","parentsEmailid.notValid");
        if(std.getParentsEmailid().equals(std.getEmailId()))
        {
            errors.rejectValue("parentsEmailid","parentsEmailid.sameEmailid");
        }


        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "nameQE", "nameQE.required");

        AcademicYearCheck(errors, std.getAcedamicYearStudiedQE(), "acedamicYearStudiedQE", "acedamicYearStudiedQE.required", "acedamicYearStudiedQE.notValid");

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "hallTicketNoQE", "hallTicketNoQE.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "passingGradeQE", "passingGradeQE.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "subjectsQE", "subjectsQE.required");

        MarksErrorsCheck(errors, std.getEnglishMarksObtainedQE(), "englishMarksObtainedQE", "englishMarksObtainedQE.required", "englishMarksObtainedQE.notValid");
        MarksErrorsCheck(errors, std.getSanskritMarksObtainedQE(), "sanskritMarksObtainedQE", "sanskritMarksObtainedQE.required", "sanskritMarksObtainedQE.notValid");
        MarksErrorsCheck(errors, std.getBotanyMarksObtainedQE(), "botanyMarksObtainedQE", "botanyMarksObtainedQE.required", "botanyMarksObtainedQE.notValid");
        MarksErrorsCheck(errors, std.getZoologyMarksObtainedQE(), "zoologyMarksObtainedQE", "zoologyMarksObtainedQE.required", "zoologyMarksObtainedQE.notValid");
        MarksErrorsCheck(errors, std.getPhysicsMarksObtainedQE(), "physicsMarksObtainedQE", "physicsMarksObtainedQE.required", "physicsMarksObtainedQE.notValid");
        MarksErrorsCheck(errors, std.getChemistryMarksObtainedQE(), "chemistryMarksObtainedQE", "chemistryMarksObtainedQE.required", "chemistryMarksObtainedQE.notValid");

        MarksErrorsCheck(errors, std.getMaxEnglishMarksQE(), "maxEnglishMarksQE", "maxEnglishMarksQE.required", "maxEnglishMarksQE.notValid");
        MarksErrorsCheck(errors, std.getSanskritMarksObtainedQE(), "maxSanskritMarksQE", "maxSanskritMarksQE.required", "maxSanskritMarksQE.notValid");
        MarksErrorsCheck(errors, std.getMaxBotanyMarksQE(), "maxBotanyMarksQE", "maxBotanyMarksQE.required", "maxBotanyMarksQE.notValid");
        MarksErrorsCheck(errors, std.getMaxZoologyMarksQE(), "maxZoologyMarksQE", "maxZoologyMarksQE.required", "maxZoologyMarksQE.notValid");
        MarksErrorsCheck(errors, std.getMaxphysicsMarksQE(), "maxphysicsMarksQE", "maxphysicsMarksQE.required", "maxphysicsMarksQE.notValid");
        MarksErrorsCheck(errors, std.getMaxEnglishMarksQE(), "maxchemistryMarksQE", "maxchemistryMarksQE.required", "maxchemistryMarksQE.notValid");

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "hallTicketEntranceExam", "hallTicketEntranceExam.required");
        NumberCheck(errors,std.getRankEntranceExam(),"rankEntranceExam", "rankEntranceExam.required", "rankEntranceExam.notValid");


        AcademicYearCheck(errors, std.getClassVIAcademicYear(), "classVIAcademicYear", "classVIAcademicYear.required", "classVIAcademicYear.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "classVISchool", "classVISchool.required");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors,"classVIRemarks","classVIRemarks.required");


        AcademicYearCheck(errors, std.getClassVIIAcademicYear(), "classVIIAcademicYear", "classVIIAcademicYear.required", "classVIIAcademicYear.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "classVIISchool", "classVIISchool.required");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors,"classVIIRemarks","classVIIRemarks.required");

        AcademicYearCheck(errors, std.getClassVIIIAcademicYear(), "classVIIIAcademicYear", "classVIIIAcademicYear.required", "classVIIIAcademicYear.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "classVIIISchool", "classVIIISchool.required");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors,"classVIIIRemarks","classVIIIRemarks.required");

        AcademicYearCheck(errors, std.getClassIXAcademicYear(), "classIXAcademicYear", "classIXAcademicYear.required", "classIXAcademicYear.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "classIXSchool", "classIXSchool.required");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors,"classIXRemarks","classIXRemarks.required");

        AcademicYearCheck(errors, std.getClassXAcademicYear(), "classXAcademicYear", "classXAcademicYear.required", "classXAcademicYear.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "classXSchool", "classXSchool.required");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors,"classXRemarks","classXRemarks.required");

        AcademicYearCheck(errors, std.getClassXIAcademicYear(), "classXIAcademicYear", "classXIAcademicYear.required", "classXIAcademicYear.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "classXICollege", "classXICollege.required");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors,"classXIRemarks","classXIRemarks.required");


        AcademicYearCheck(errors, std.getClassXIAcademicYear(), "classXIIAcademicYear", "classXIIAcademicYear.required", "classXIIAcademicYear.notValid");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "classXIICollege", "classXIICollege.required");
        //ValidationUtils.rejectIfEmptyOrWhitespace(errors,"classXIIRemarks","classXIIRemarks.required");

       
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "dobCertificate", "dobCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "interMemoCertificate", "interMemoCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "studyCertificate", "studyCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "transferCertificate", "transferCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "conductCertificate", "conductCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "casteCertificate", "casteCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "eamcetRankCertificate", "eamcetRankCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "eamcetHallTicketCertificate", "eamcetHallTicketCertificate.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "photosCheck", "photosCheck.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "otherCertificate", "otherCertificate.required");





    }

        public void NumberCheck(Errors errors, String Rank, String objAttribute, String ReqMsg, String InvalidMsg) {
        String RANK_PATTERN = "^[0-9]+$"; //Regex - Java Regular Expressions

        if (Rank.isEmpty()) {
            errors.rejectValue(objAttribute, ReqMsg);
        } else if (!Pattern.compile(RANK_PATTERN).matcher(Rank).matches()) {
            errors.rejectValue(objAttribute, InvalidMsg);
        }
    }

    public void MarksErrorsCheck(Errors errors, String Marks, String objAttribute, String ReqMsg, String InvalidMsg) {
        String MARKS_PATTERN = "^[0-9]+$"; //Regex - Java Regular Expressions

        if (Marks.isEmpty()) {
            errors.rejectValue(objAttribute, ReqMsg);
        } else if (Marks.length() > 3) {
            errors.rejectValue(objAttribute, InvalidMsg);
        } else if (!Pattern.compile(MARKS_PATTERN).matcher(Marks).matches()) {
            errors.rejectValue(objAttribute, InvalidMsg);
        }
    }

    public void AcademicYearCheck(Errors errors, String AcademicYear, String objAttribute, String ReqMsg, String InvalidMsg) {
        String ACADEMICYEAR_PATTERN = "^(19|20)[0-9][0-9]\\-(19|20)[0-9][0-9]$";


        if (AcademicYear.equals("-")) {
            errors.rejectValue(objAttribute, ReqMsg);
        } else if (!Pattern.compile(ACADEMICYEAR_PATTERN).matcher(AcademicYear).matches()) {
            errors.rejectValue(objAttribute, InvalidMsg);
        } else if (Pattern.compile(ACADEMICYEAR_PATTERN).matcher(AcademicYear).matches()) {
            if (Integer.parseInt(AcademicYear.split("-")[0].toString()) >= Integer.parseInt(AcademicYear.split("-")[1].toString())) {
                errors.rejectValue(objAttribute, InvalidMsg);
            }
        }
    }

    public void DateCheck(Errors errors, String date, String objAttribute, String ReqMsg, String InvalidMsg) {
        String DATE_PATTERN = "^([1-9]|[12][0-9]|3[01])[- /.]([1-9]|1[012])[- /.](19|20)[0-9][0-9]$";
        if (date.equals("//")) {
            errors.rejectValue(objAttribute, ReqMsg);
        } else if (!Pattern.compile(DATE_PATTERN).matcher(date).matches()) {
            errors.rejectValue(objAttribute, InvalidMsg);
        }
    }

    public void PhoneCheck(Errors errors, String phoneNumber, String objAttribute, String ReqMsg, String InvalidMsg) {

        String PHONE_PATTERN = "^[0-9]+$"; //Regex - Java Regular Expressions
        if (phoneNumber.isEmpty()) {
            errors.rejectValue(objAttribute, ReqMsg);
        } else if (phoneNumber.length() != 12) {
            errors.rejectValue(objAttribute, InvalidMsg);
        } else if (!Pattern.compile(PHONE_PATTERN).matcher(phoneNumber).matches()) {
            errors.rejectValue(objAttribute, InvalidMsg);
        }
    }

        public void EmailCheck(Errors errors, String emailId, String objAttribute, String ReqMsg, String InvalidMsg) {
                    String EMAIL_PATTERN = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";


            if (emailId.isEmpty()) {
            errors.rejectValue(objAttribute, ReqMsg);
        } else if (!Pattern.compile(EMAIL_PATTERN).matcher(emailId).matches()) {
            errors.rejectValue(objAttribute, InvalidMsg);
        }
        }

        public void PINCodeCheck(Errors errors, String pincode, String objAttribute, String ReqMsg, String InvalidMsg) {
            
                String PINZIP_PATTERN = "^[0-9]+$"; //Regex - Java Regular Expressions

                if (pincode.isEmpty()) {
            errors.rejectValue(objAttribute, ReqMsg);
        } else if (pincode.length() < 5 || pincode.length() > 6) {
            errors.rejectValue(objAttribute, InvalidMsg);
        } else if (!Pattern.compile(PINZIP_PATTERN).matcher(pincode).matches()) {
            errors.rejectValue(objAttribute, InvalidMsg);
        }
        }

        public void NameCheck(Errors errors, String name, String objAttribute, String ReqMsg, String InvalidMsg) {
        String NAME_PATTERN = "^[A-Za-z ]+$"; //Regex - Java Regular Expressions
        if(name.isEmpty())
        {
            errors.rejectValue(objAttribute, ReqMsg);
        }else if (!Pattern.compile(NAME_PATTERN).matcher(name).matches())
        {
            errors.rejectValue(objAttribute, InvalidMsg);
        }
        }

        public void AddressCheck(Errors errors, String address, String objAttribute, String ReqMsg,String InvalidMsg)
        {
            String ADDRESS_PATTERN ="^[A-Za-z0-9 ]+;[A-Za-z0-9 ]+;[A-Za-z0-9 ]+$";
            if(address.equals(";;"))
            {
                errors.rejectValue(objAttribute, ReqMsg);
            }
            else if(!Pattern.compile(ADDRESS_PATTERN).matcher(address).matches())
            {
                errors.rejectValue(objAttribute,InvalidMsg);
            }
        }

}
