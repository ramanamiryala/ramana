package com.college.service;

import java.util.List;
import com.college.domain.Users;

public interface AllUsersService {

    public List<Users> userLoginCheck(Users user);
    public boolean userEmailCheck(String emailid);


}
