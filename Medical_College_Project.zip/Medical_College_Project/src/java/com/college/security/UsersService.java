package com.college.security;

import java.util.List;
import com.college.domain.Users;

public interface UsersService {

    public List<Users> userLoginCheck(Users user);
    public boolean userEmailCheck(String emailid);
    public boolean userNameCheck(String username);
    public String userPasswordReset(String username, String emailid);
    public List<Users> userDetailsCheck(String userattribute, String userDBColumnName);

    public void AddNewUser(Users user);
    public void UpdateUser(Users user);


     public String uniqueIdGenerator();

}
