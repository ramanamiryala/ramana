/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.college.service;


import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;
import java.util.ArrayList;
import com.college.domain.Users;

public class AllUsersServiceImp implements AllUsersService {

     private HibernateTemplate hibernateTemplate;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.hibernateTemplate = new HibernateTemplate(sessionFactory);
	}


@Override
         public List<Users> userLoginCheck(Users user){
            List<Users> userDetails;
             //List<Marks> studentDetails;
            Object row[] = new Object[2];
            row[0] = (Object)user.getUsername();
            row[1] = (Object)user.getPassword();
           userDetails = (List<Users>) hibernateTemplate.find("from Users where username = ? AND password = ? ", row);
           return userDetails;
        }

@Override
          public boolean userEmailCheck(String emailid){
         Users user = new Users();
         user.setEmailid(emailid);
         List<Users> userDetails;

         userDetails = (List<Users>) hibernateTemplate.find("from Users where emailid = ? ", emailid);

         if(userDetails.size()<1)
         {
             return false;
         }
         else
         {


             return true;
         }


        }




}
