package com.college.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import org.springframework.ui.ModelMap;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.util.ClassUtils;

import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;
import com.college.domain.Users;
import com.college.domain.Student;
import com.college.service.StudentService;

import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.Authentication;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;
import com.college.security.UsersService;
import com.college.email.EmailSender;
import com.college.email.EmailDetails;

import org.apache.log4j.Logger;



@Controller
public class LoginHelpController {

    private UsersService usersService;
    private EmailSender emailSender;
    private GenericManageableCaptchaService captchaService;
     private Logger log = Logger.getLogger(LoginHelpController.class);
    private StudentService studentService;

    @Autowired
    public LoginHelpController(StudentService studentService, GenericManageableCaptchaService captchaService, UsersService usersService, EmailSender emailSender) {
        this.studentService = studentService;
        this.emailSender = emailSender;
        this.usersService = usersService;
        this.captchaService = captchaService;
    }


       @RequestMapping(value="/college_login.htm", method = RequestMethod.GET)
        public ModelAndView Login (ModelMap model)
        {
            Users user = new Users();
            model.addAttribute("user",user);
            return new ModelAndView("Login",model);
	}

      @RequestMapping("/home.htm")
      public ModelAndView home (ModelMap model) throws Exception {

          //List<Users> userDetails = authProvider.studentLoginCheck(user);
          //Getting Main Authentication From Security Context Holder
         Authentication userauth= SecurityContextHolder.getContext().getAuthentication();


         //.getAuthorities()[0].toString();

         String rolename =  userauth.getAuthorities()[0].toString();
         String  username = userauth.getPrincipal().toString();
         String password =  userauth.getCredentials().toString();

         if(rolename.equals("ROLE_STUDENT"))
         {
             Student student = new Student();

             student.setUsername(username);
      
             studentService.retrieveStudent(student);

             model.addAttribute("student",student);

             return new ModelAndView("StudentHome",model);

         }
         else if (rolename.equals("ROLE_ADMIN"))
         {
             return new ModelAndView("AdminHome", model);
         }
         else { //if(userrole.equals("ROLE_STAFF"))

             return new ModelAndView("staff_home", model);
         }


      }


    @RequestMapping(value = "/forgotpassword.htm")
    public ModelAndView forgotpassword(ModelMap model) {
        return new ModelAndView("forgotpassword");
    }

    @RequestMapping(value = "/forgotpasswordSuccess.htm")
    public ModelAndView forgotpasswordSuccess(
            HttpServletRequest request,
            @RequestParam("emailid") String emailid,
            @RequestParam("username") String username) {

// Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");


        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                log.error("Captcha is valid..Great!");
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }



        
        String forgotmessage = usersService.userPasswordReset(username, emailid);

        if (!forgotmessage.equals("")) {
            forgotmessage = forgotmessage + "<br> Please Enter above fields again. "
                    + "<br>Contact <b> Website Adminstrator </b> in case you forgot username & email id ";
            return new ModelAndView("forgotpassword", "forgotmessage", forgotmessage);
        } else {

            if (isResponseCorrect) { //Capatcha is correct
                List<Users> userdetails;

                Student student = new Student();

                if (!emailid.equals("")) {
                 //   student.setEmailid(emailid);
                   // studentService.retrieveStudent(student);
                    userdetails = usersService.userDetailsCheck(emailid, "emailid");
                } else {
                   // student.setUsername(username);
                    //studentService.retrieveStudent(student);
                    userdetails = usersService.userDetailsCheck(username, "username");
                }

                Users user = new Users();
                user = userdetails.get(0);

                // Now set the Password in the STudent from user details
               // student.setPassword(user.getPassword());
                //studentService.updateStudent(student);


                ModelMap model = new ModelMap();
                EmailDetails emailDetails = new EmailDetails();

                model.addAttribute("user", user);

                emailDetails.setTo(user.getEmailid());
                emailDetails.setFrom("ramana.miryala@gmail.com");
                //emailDetails.setFrom("root@localhost");
                emailDetails.setSubject("Your Password is Reset by Admin");
                emailDetails.setVMTemplate("PasswordReset.vm");

                String[] InlineFilenames = new String[1];
                InlineFilenames[0] = "F:/Haritha_Tech_Project/Medical_College_Project/web/WEB-INF/images/harithalogo.jpg";

                emailDetails.setAddInline(InlineFilenames);

                String[] AttachmentFilenames = new String[1];
                AttachmentFilenames[0] = null;

                emailDetails.setAttachment(AttachmentFilenames);


                emailSender.sendEmail(model, emailDetails);


                return new ModelAndView("frgtpswrdSuccess", "emailid", emailid);
            } else {
                return new ModelAndView("forgotpassword", "forgotmessage", "Captcha is Invalid");
            }
        }


    }
}
