package com.college.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.web.bind.support.SessionStatus;

import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.annotation.RequestParam;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.jsp.PageContext;

import com.college.domain.Student;
import com.college.domain.Users;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import javax.imageio.ImageIO;


import org.springframework.web.multipart.MultipartFile;
//import org.springframework.web.multipart.commons
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.FileItem;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.io.FileInputStream;
import java.util.List;
import java.util.ArrayList;
import java.util.Properties;
import java.util.ResourceBundle;
import org.springframework.web.multipart.commons.CommonsFileUploadSupport;
import org.apache.commons.fileupload.FileUpload;
import java.io.BufferedOutputStream;


import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;

import com.college.service.StudentService;
import com.college.security.UsersService;
import com.college.validator.StudentValidator;

import org.apache.log4j.Logger;
import org.apache.commons.lang.RandomStringUtils;
import org.springframework.core.io.ClassPathResource;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;


import javax.servlet.ServletContext;

@Controller
public class AdminStudentController {

    private StudentService studentService;
    private StudentValidator studentValidator;
    private GenericManageableCaptchaService captchaService;
    private UsersService usersService;
    private Logger log = Logger.getLogger(AdminStudentController.class);

    @Autowired
    public AdminStudentController(GenericManageableCaptchaService captchaService, StudentService studentService,
            StudentValidator studentValidator, UsersService usersService) {
        this.studentService = studentService;
        this.studentValidator = studentValidator;
        this.captchaService = captchaService;
        this.usersService = usersService;
    }



    @RequestMapping("/image.htm")
    public ModelAndView viewPhoto(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) throws IOException {
        // MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        //MultipartFile file1 = multipartRequest.getFile("file1");

        FileItem fileitem;
        DiskFileItemFactory dif = new DiskFileItemFactory();
        dif.setSizeThreshold(20000);

        MultipartFile file1 = (MultipartFile) request.getSession().getAttribute("file1_sess");

        byte[] photo = file1.getBytes();
        response.setContentType(file1.getContentType());

        OutputStream os = response.getOutputStream();
        BufferedOutputStream bos = new BufferedOutputStream(os);
        bos.write(photo, 0, photo.length);
        bos.close();
        return null;

    }

    static final String[] pages = {"First", "Second", "Third", "Confirm", "Done"};
    @RequestMapping("/AdminStdProfileRegistration.htm")
    public ModelAndView submittedView(@ModelAttribute("student") Student student,
            BindingResult result,
            @RequestParam(value = "nextPage", required = false) Integer page,
            @RequestParam(value = "next", required = false) Object next,
            @RequestParam(value = "prev", required = false) Object prev,
            @RequestParam(value = "photoUpload", required = false) Object photoUpload,
            @RequestParam(value = "curPage", required = false) Integer curPage,
            @RequestParam(value = "confirm", required = false) Object confirm,
            HttpServletRequest request,
            ModelMap modelMap
            ) throws IOException{




        Student student_session = new Student();

        studentService.formAddOptionvalues(modelMap);

        if (curPage != null && (next != null || confirm != null)) {

            page = curPage + 1;
        }

        if (curPage != null && prev != null) {
            page = curPage - 1;
        }

//        if (curPage !=null && confirm != null) {
//            page = curPage+1;
//        }

        if (page == null || page < 1 || page > pages.length) {
            page = 1;
        }



        if (page == 1 && photoUpload == null && prev == null && next == null) { //Going to Page-1

            modelMap.addAttribute("isimageuploaded", null);
            request.getSession().setAttribute("student_sess", student);
        } else if (page == 1 && photoUpload != null && next == null && prev == null) {
            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultipartFile file1 = multipartRequest.getFile("file1");


            student.setAdmissionDate(request.getParameter("admday") + "/" + request.getParameter("admmonth") + "/" + request.getParameter("admyear"));
            student.setDateofBirth(request.getParameter("bday") + "/" + request.getParameter("bmonth") + "/" + request.getParameter("byear"));

            studentValidator.validateStudentRegPageFirst(student, result);

            if (usersService.userDetailsCheck(student.getEmailId(), "emailid").size() > 0) {
                result.rejectValue("emailId", "emailId.exitsAlready");
            }

// SIMIlarly  DO IT FOR PARENTS EMAILD IN SECOND PAGE ALSO 

            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
//                studentService.specialStudentAtrributesMapping(modelMap,request);
                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 1;
            } else {
                if (file1.isEmpty()) {
                    studentService.formAddOptionvalues(modelMap);
//                    studentService.specialStudentAtrributesMapping(modelMap,request);
                    studentService.specialStudentAtrributesMapping(modelMap, request, student);
                    modelMap.addAttribute("fileerror", "File is Empty");
                    modelMap.addAttribute("isimageuploaded", null);
                    page = 1;
                } else {

                    request.getSession().setAttribute("file1_sess", file1);

                    student_session = (Student) request.getSession().getAttribute("student_sess");
                    studentService.combineStudentRegPage1withOldPageObjects(student, student_session);
                    modelMap.addAttribute("isimageuploaded", file1.getName());

                    request.getSession().setAttribute("student_sess", student_session);


                    studentService.specialStudentAtrributesMapping(modelMap, request, student_session);
                    modelMap.addAttribute("student", student_session);

                    page = 1;
                }
            }

        } else if (page == 2 && next != null && prev == null) { // Going from Page-1 to Page-2

            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultipartFile file1 = multipartRequest.getFile("file1");

            student.setAdmissionDate(request.getParameter("admday") + "/" + request.getParameter("admmonth") + "/" + request.getParameter("admyear"));
            student.setDateofBirth(request.getParameter("bday") + "/" + request.getParameter("bmonth") + "/" + request.getParameter("byear"));


            studentValidator.validateStudentRegPageFirst(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
                //studentService.specialStudentAtrributesMapping(modelMap,request);

                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 1;
            } else {

                MultipartFile oldfile = (MultipartFile) request.getSession().getAttribute("file1_sess");

                if (file1.isEmpty() && oldfile == null) {
                    studentService.formAddOptionvalues(modelMap);
                    //   studentService.specialStudentAtrributesMapping(modelMap, request);
                    studentService.specialStudentAtrributesMapping(modelMap, request, student);

                    modelMap.addAttribute("fileerror", "File is Empty");
                    page = 1;
                } else {
                    if (!file1.isEmpty()) {
                        request.getSession().setAttribute("file1_sess", file1);
                    }


                    student_session = (Student) request.getSession().getAttribute("student_sess");
                    // Now I need to add student_sess attribute values (if any)to student
                    studentService.combineStudentRegPage1withOldPageObjects(student, student_session);
                    studentService.specialStudentAtrributesMapping(modelMap, request, student_session);

                    request.getSession().setAttribute("student_sess", student_session);
                    modelMap.addAttribute("student", student_session);
                    page = 2;
                }
            }
        } else if (page == 3 && next != null && prev == null) { // Going from Page-2 to Page-3

            student.setCurrentAddress(request.getParameter("stc_line1") + ";" + request.getParameter("stc_line2") + ";" + request.getParameter("stc_line3"));
            student.setPermanentAddress(request.getParameter("stp_line1") + ";" + request.getParameter("stp_line2") + ";" + request.getParameter("stp_line3"));
            student.setParentsCorrespondenceAddress(request.getParameter("pc_line1") + ";" + request.getParameter("pc_line2") + ";" + request.getParameter("pc_line3"));


            studentValidator.validateStudentRegPageSecond(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 2;
            } else {

                student_session = (Student) request.getSession().getAttribute("student_sess");
                studentService.combineStudentRegPage2withOldPageObjects(student, student_session);
                studentService.specialStudentAtrributesMapping(modelMap, request, student_session);
                //Now student is with Complete details till Page 2
                request.getSession().setAttribute("student_sess", student_session);
                modelMap.addAttribute("student", student_session);
                page = 3;
            }


        } else if (page == 4 && next != null && prev == null) {// Page-4 from Page -3

            student.setAcedamicYearStudiedQE(request.getParameter("qefromyear") + "-" + request.getParameter("qetoyear"));
            student.setClassVIAcademicYear(request.getParameter("VIfromyear") + "-" + request.getParameter("VItoyear"));
            student.setClassVIIAcademicYear(request.getParameter("VIIfromyear") + "-" + request.getParameter("VIItoyear"));
            student.setClassVIIIAcademicYear(request.getParameter("VIIIfromyear") + "-" + request.getParameter("VIIItoyear"));
            student.setClassIXAcademicYear(request.getParameter("IXfromyear") + "-" + request.getParameter("IXtoyear"));
            student.setClassXAcademicYear(request.getParameter("Xfromyear") + "-" + request.getParameter("Xtoyear"));
            student.setClassXIAcademicYear(request.getParameter("XIfromyear") + "-" + request.getParameter("XItoyear"));
            student.setClassXIIAcademicYear(request.getParameter("XIIfromyear") + "-" + request.getParameter("XIItoyear"));


            studentValidator.validateStudentRegPageThird(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 3;
            } else {

                student_session = (Student) request.getSession().getAttribute("student_sess");
                // Now set the Student details to Stduent_session
                studentService.combineStudentRegPage3withOldPageObjects(student, student_session);
                studentService.specialStudentAtrributesMapping(modelMap, request, student_session);
                request.getSession().setAttribute("student_sess", student_session);
                modelMap.addAttribute("student", student_session);
                page = 4;

            }

        } else if (page == 1 && prev != null && next == null) { //When going back to page 1 from CurrPage=2
            student = (Student) request.getSession().getAttribute("student_sess");

//            studentService.backSpecialStudentAtrributesMapping(modelMap,student);

            studentService.specialStudentAtrributesMapping(modelMap, request, student);

            modelMap.addAttribute("isimageuploaded", "Image is there already");
            modelMap.addAttribute("student", student);

        } else if (page == 2 && prev != null && next == null) // When Going back to page-2 from CurrPage=3
        {
            student = (Student) request.getSession().getAttribute("student_sess");


            //studentService.backSpecialStudentAtrributesMapping(modelMap,student);
            studentService.specialStudentAtrributesMapping(modelMap, request, student);


            modelMap.addAttribute("student", student);

        } else if (page == 3 && prev != null && next == null) // When Going back to page-3 from CurrPage=4
        {
            student = (Student) request.getSession().getAttribute("student_sess");

            //studentService.backSpecialStudentAtrributesMapping(modelMap,student);
            studentService.specialStudentAtrributesMapping(modelMap, request, student);
            modelMap.addAttribute("student", student);
        } else if (page == 5 && confirm != null) {
            // Checking Capatch Response
            boolean isResponseCorrect = false;
            String captchaId = request.getSession().getId();
            String response = request.getParameter("j_captcha_response");

            student = (Student) request.getSession().getAttribute("student_sess");
                // Now set the Student details to Stduent_session
            modelMap.addAttribute("student", student);



            try {
                if (response != null) {

                    isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                    log.error("Captcha is valid..Great!");
                }

            } catch (CaptchaServiceException e) {
                log.error("Problem Jcaptcha settings ", e);
            }

            if (!isResponseCorrect) { //Capatcha is not correct
                modelMap.addAttribute("captchaerror", "Capacth is Invalid");
                page=4;

            } else {
                //Setting Username & Passwords
                student.setPassword(RandomStringUtils.randomAlphanumeric(10));
                student.setUsername(student.getEmailId());

                if ((usersService.userDetailsCheck(student.getUsername(), "username").size() < 1)
                        && (usersService.userDetailsCheck(student.getEmailId(), "emailid").size() < 1)
                        && (usersService.userDetailsCheck(student.getParentsEmailid(),"emailid").size()<1))
                {//checking the usernames of both

                    //Checking Username & emailid details
                    // College Registarion Number ----> for Old student
                    //Setting Username & Password for Parents
                    student.setParentsUsername(student.getParentsEmailid());
                    student.setParentsPassword(RandomStringUtils.randomAlphanumeric(10));

                    // Saving Student
                    studentService.saveStudent(student);

                    Users user = new Users();
                    user.setUsername(student.getUsername());
                    user.setEnabled(true);
                    user.setPassword(student.getPassword());
                    user.setUsertype("STUDENT");
                    user.setEmailid(student.getEmailId());
                    //Saving into Common Users Table
                    usersService.AddNewUser(user);

                    // Saving Student's Parents Login Details


                    Users user_parent = new Users();
                    user_parent.setUsername(student.getParentsUsername());
                    user_parent.setEnabled(true);
                    user_parent.setPassword(student.getParentsPassword());
                    user_parent.setUsertype("PARENTS");
                    user_parent.setEmailid(student.getParentsEmailid());
                    //Saving into Common Users Table
                    usersService.AddNewUser(user_parent);

                    List<Student> studentDetails = studentService.findStudentByUsername(student.getUsername());

                    ResourceBundle bundle = ResourceBundle.getBundle("messages");
                    String rootwebapp = bundle.getString("webapp.root");
                    String actrootwebapp = bundle.getString("actwebapp.root");

                    MultipartFile file1 = (MultipartFile) request.getSession().getAttribute("file1_sess");

                    String filename = file1.getOriginalFilename().toString();

                    int dotPosi = filename.lastIndexOf(".");
                    String extension = filename.substring(dotPosi);
                    String NewFilename = Long.toString(studentDetails.get(0).getId()) + extension;

                    String profPhotoContextPath = "/profile_photos/student/" + NewFilename;
                    String profPhotoAbsolutePathName = rootwebapp + profPhotoContextPath;

                    //String profPhotoAbsolutePathName = actrootwebapp + profPhotoContextPath;
                    file1.transferTo(new File(profPhotoAbsolutePathName));
                    student.setId(studentDetails.get(0).getId());
                    student.setProfilePhotoFileName(NewFilename);
                    //Updating the Student table with Profile File name
                    studentService.updateStudent(student);
                }
            }
        }
            modelMap.addAttribute("pageNum", page);
            modelMap.addAttribute("pageMax", pages.length);
            modelMap.addAttribute("pageView", pages[page - 1]);
            /* IMPLEMENT YOUR LOGIC */
            return new ModelAndView("AdminStdProfile", modelMap);
        }



    @RequestMapping("/AdminStdntProfSearch.htm")
    public ModelAndView adminStudentSearch(ModelMap model,@ModelAttribute("student1") Student student1) {
        return new ModelAndView("AdminStdntProfSearch", model);
    }


    @RequestMapping("/AdminStdntProfSearchResults.htm")
    public ModelAndView adminStudentSearchResults(ModelMap model, @ModelAttribute("student") Student student, @ModelAttribute("student1") Student student1) {

        model.addAttribute("student", new Student());

        List<Student> studentSearch = studentService.searchStudent(student1);
        model.addAttribute("studentSearch", studentSearch);

        return new ModelAndView("AdminStdntProfSearchResults", model);
    }



    @RequestMapping("/AdminStudentProfileUpdate.htm")
    public ModelAndView adminStudentProfileUpdation(@ModelAttribute("student") Student student,
            BindingResult result,
            @RequestParam(value = "nextPage", required = false) Integer page,
            @RequestParam(value = "next", required = false) Object next,
            @RequestParam(value = "prev", required = false) Object prev,
            @RequestParam(value = "photoUpload", required = false) Object photoUpload,
            @RequestParam(value = "curPage", required = false) Integer curPage,
            @RequestParam(value = "confirm", required = false) Object confirm,
            HttpServletRequest request,
            ModelMap modelMap
            ) throws IOException{


        Student student_session = new Student();

        studentService.formAddOptionvalues(modelMap);

        if (curPage != null && (next != null || confirm != null)) {
            page = curPage + 1;
        }

        if (curPage != null && prev != null) {
            page = curPage - 1;
        }

        if (page == null || page < 1 || page > pages.length) {
            page = 1;
        }


        String userProfilePhotoExists=null;

        if (page == 1 && photoUpload == null && prev == null && next == null) { //Going to Page-1

            long stdntPrimKey= Long.parseLong(request.getParameter("stdntPrimKey"));

            if (stdntPrimKey != 0) {

            student= studentService.findStudentByPrimaryKey(stdntPrimKey).get(0);

            List<Users> userdetails = usersService.userDetailsCheck(student.getUsername(),"username");
            long usersprimkeyid = userdetails.get(0).getId();

            List <Users> parentsdetails = usersService.userDetailsCheck(student.getParentsEmailid(),"username");
            long parentsprimkeyid = parentsdetails.get(0).getId();

            modelMap.addAttribute("student", student);
            request.getSession().setAttribute("stdntPrimKey",stdntPrimKey);
            request.getSession().setAttribute("usersprimkeyid",usersprimkeyid);
            request.getSession().setAttribute("parentsprimkeyid",parentsprimkeyid);


           ResourceBundle bundle = ResourceBundle.getBundle("messages");
           String rootwebapp = bundle.getString("webapp.root");
           String actrootwebapp = bundle.getString("actwebapp.root");

           String NewFilename = student.getProfilePhotoFileName();
           String profPhotoContextPath = "/profile_photos/student/" + NewFilename;
           String profPhotoAbsolutePathName = rootwebapp + profPhotoContextPath;           
           //String profPhotoAbsolutePathName = actrootwebapp + profPhotoContextPath;
           //file1.transferTo(new File(profPhotoAbsolutePathName));
           File profilefile = new File(profPhotoAbsolutePathName);
           
                if (profilefile.exists()) {
                    userProfilePhotoExists = "1";
                    request.getSession().setAttribute("userProfilePhotoExists", userProfilePhotoExists);
                    modelMap.addAttribute("userProfilePhotoExists", userProfilePhotoExists);
                } else {

                    request.getSession().setAttribute("userProfilePhotoExists", null);
                    modelMap.addAttribute("userProfilePhotoExists", null);
                }

           //Now this problem is to be solved
             //      And next we need to start Attendence part
           
        }
            studentService.specialStudentAtrributesMapping(modelMap, request, student);

            modelMap.addAttribute("isimageuploaded", null);
            request.getSession().setAttribute("student_sess", student);

        }
        else if ( (page == 1 && photoUpload != null && next == null && prev == null) )
        {
            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultipartFile file1 = multipartRequest.getFile("file1");


            student.setAdmissionDate(request.getParameter("admday") + "/" + request.getParameter("admmonth") + "/" + request.getParameter("admyear"));
            student.setDateofBirth(request.getParameter("bday") + "/" + request.getParameter("bmonth") + "/" + request.getParameter("byear"));

            studentValidator.validateStudentRegPageFirst(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
//                studentService.specialStudentAtrributesMapping(modelMap,request);
                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 1;
            } else {
                if (file1.isEmpty()) {
                    studentService.formAddOptionvalues(modelMap);
//                    studentService.specialStudentAtrributesMapping(modelMap,request);
                    studentService.specialStudentAtrributesMapping(modelMap, request, student);
                    student_session = (Student) request.getSession().getAttribute("student_sess");
                    modelMap.addAttribute("student", student_session);
                    modelMap.addAttribute("fileerror", "File is Empty");
                    modelMap.addAttribute("isimageuploaded", null);
                    page = 1;
                } else {

                    request.getSession().setAttribute("file1_sess", file1);

                    student_session = (Student) request.getSession().getAttribute("student_sess");
                    studentService.combineStudentRegPage1withOldPageObjects(student, student_session);
                    modelMap.addAttribute("isimageuploaded", file1.getName());

                    request.getSession().setAttribute("student_sess", student_session);


                    studentService.specialStudentAtrributesMapping(modelMap, request, student_session);
                    modelMap.addAttribute("student", student_session);

                    userProfilePhotoExists = null;
                    request.getSession().setAttribute("userProfilePhotoExists", userProfilePhotoExists);
                    modelMap.addAttribute("userProfilePhotoExists", userProfilePhotoExists);



                    page = 1;
                }
            }

        }
        else if (page == 2 && next != null && prev == null && 
                (request.getSession().getAttribute("userProfilePhotoExists")!=null && 
                ((MultipartHttpServletRequest) request).getFile("file1").isEmpty())) {

            student.setAdmissionDate(request.getParameter("admday") + "/" + request.getParameter("admmonth") + "/" + request.getParameter("admyear"));
            student.setDateofBirth(request.getParameter("bday") + "/" + request.getParameter("bmonth") + "/" + request.getParameter("byear"));


            studentValidator.validateStudentRegPageFirst(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
                //studentService.specialStudentAtrributesMapping(modelMap,request);
                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 1;
            } else {
                    student_session = (Student) request.getSession().getAttribute("student_sess");
                    // Now I need to add student_sess attribute values (if any)to student
                    studentService.combineStudentRegPage1withOldPageObjects(student, student_session);
                    studentService.specialStudentAtrributesMapping(modelMap, request, student_session);

                    request.getSession().setAttribute("student_sess", student_session);
                    modelMap.addAttribute("student", student_session);
                    page = 2;
                }
            }

        else if ((page == 2 && next != null && prev == null &&
                (request.getSession().getAttribute("userProfilePhotoExists")==null ||
                !((MultipartHttpServletRequest) request).getFile("file1").isEmpty()))
                ) { // IF USER WANTS TO UPDATE PROFILE PHOTO // Going from Page-1 to Page-2

            MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
            MultipartFile file1 = multipartRequest.getFile("file1");

            student.setAdmissionDate(request.getParameter("admday") + "/" + request.getParameter("admmonth") + "/" + request.getParameter("admyear"));
            student.setDateofBirth(request.getParameter("bday") + "/" + request.getParameter("bmonth") + "/" + request.getParameter("byear"));


            studentValidator.validateStudentRegPageFirst(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
                //studentService.specialStudentAtrributesMapping(modelMap,request);

                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 1;
            } else {

                MultipartFile oldfile = (MultipartFile) request.getSession().getAttribute("file1_sess");

                if (file1.isEmpty() && oldfile == null) {
                    studentService.formAddOptionvalues(modelMap);
                    //   studentService.specialStudentAtrributesMapping(modelMap, request);
                    studentService.specialStudentAtrributesMapping(modelMap, request, student);

                    modelMap.addAttribute("fileerror", "File is Empty");
                    page = 1;
                } else {
                    if (!file1.isEmpty()) {
                        userProfilePhotoExists = null;
                    request.getSession().setAttribute("userProfilePhotoExists", userProfilePhotoExists);
                    modelMap.addAttribute("userProfilePhotoExists", userProfilePhotoExists);

                        request.getSession().setAttribute("file1_sess", file1);
                    }


                    student_session = (Student) request.getSession().getAttribute("student_sess");
                    // Now I need to add student_sess attribute values (if any)to student
                    studentService.combineStudentRegPage1withOldPageObjects(student, student_session);
                    studentService.specialStudentAtrributesMapping(modelMap, request, student_session);

                    request.getSession().setAttribute("student_sess", student_session);
                    modelMap.addAttribute("student", student_session);

                    page = 2;
                }
            }
        } else if (page == 3 && next != null && prev == null) { // Going from Page-2 to Page-3

            student.setCurrentAddress(request.getParameter("stc_line1") + ";" + request.getParameter("stc_line2") + ";" + request.getParameter("stc_line3"));
            student.setPermanentAddress(request.getParameter("stp_line1") + ";" + request.getParameter("stp_line2") + ";" + request.getParameter("stp_line3"));
            student.setParentsCorrespondenceAddress(request.getParameter("pc_line1") + ";" + request.getParameter("pc_line2") + ";" + request.getParameter("pc_line3"));


            studentValidator.validateStudentRegPageSecond(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 2;
            } else {

                student_session = (Student) request.getSession().getAttribute("student_sess");
                studentService.combineStudentRegPage2withOldPageObjects(student, student_session);
                studentService.specialStudentAtrributesMapping(modelMap, request, student_session);
                //Now student is with Complete details till Page 2
                request.getSession().setAttribute("student_sess", student_session);
                modelMap.addAttribute("student", student_session);
                page = 3;
            }


        } else if (page == 4 && next != null && prev == null) {// Page-4 from Page -3

            student.setAcedamicYearStudiedQE(request.getParameter("qefromyear") + "-" + request.getParameter("qetoyear"));
            student.setClassVIAcademicYear(request.getParameter("VIfromyear") + "-" + request.getParameter("VItoyear"));
            student.setClassVIIAcademicYear(request.getParameter("VIIfromyear") + "-" + request.getParameter("VIItoyear"));
            student.setClassVIIIAcademicYear(request.getParameter("VIIIfromyear") + "-" + request.getParameter("VIIItoyear"));
            student.setClassIXAcademicYear(request.getParameter("IXfromyear") + "-" + request.getParameter("IXtoyear"));
            student.setClassXAcademicYear(request.getParameter("Xfromyear") + "-" + request.getParameter("Xtoyear"));
            student.setClassXIAcademicYear(request.getParameter("XIfromyear") + "-" + request.getParameter("XItoyear"));
            student.setClassXIIAcademicYear(request.getParameter("XIIfromyear") + "-" + request.getParameter("XIItoyear"));


            studentValidator.validateStudentRegPageThird(student, result);
            if (result.hasErrors()) {
                studentService.formAddOptionvalues(modelMap);
                studentService.specialStudentAtrributesMapping(modelMap, request, student);
                page = 3;
            } else {

                student_session = (Student) request.getSession().getAttribute("student_sess");
                // Now set the Student details to Stduent_session
                studentService.combineStudentRegPage3withOldPageObjects(student, student_session);
                studentService.specialStudentAtrributesMapping(modelMap, request, student_session);
                request.getSession().setAttribute("student_sess", student_session);
                modelMap.addAttribute("student", student_session);
                page = 4;

            }

        } else if (page == 1 && prev != null && next == null) { //When going back to page 1 from CurrPage=2
            student = (Student) request.getSession().getAttribute("student_sess");

//            studentService.backSpecialStudentAtrributesMapping(modelMap,student);


            studentService.specialStudentAtrributesMapping(modelMap, request, student);

            if(request.getSession().getAttribute("userProfilePhotoExists")==null)
            {
            modelMap.addAttribute("isimageuploaded", "Image is there already");
            modelMap.addAttribute("userProfilePhotoExists", null);
            }
            else
            {
                modelMap.addAttribute("isimageuploaded", null);
                modelMap.addAttribute("userProfilePhotoExists", request.getSession().getAttribute("userProfilePhotoExists"));
            }
            modelMap.addAttribute("student", student);

        } else if (page == 2 && prev != null && next == null) // When Going back to page-2 from CurrPage=3
        {
            student = (Student) request.getSession().getAttribute("student_sess");


            //studentService.backSpecialStudentAtrributesMapping(modelMap,student);
            studentService.specialStudentAtrributesMapping(modelMap, request, student);


            modelMap.addAttribute("student", student);

        } else if (page == 3 && prev != null && next == null) // When Going back to page-3 from CurrPage=4
        {
            student = (Student) request.getSession().getAttribute("student_sess");

            //studentService.backSpecialStudentAtrributesMapping(modelMap,student);
            studentService.specialStudentAtrributesMapping(modelMap, request, student);
            modelMap.addAttribute("student", student);
        } else if (page == 5 && confirm != null) {
            // Checking Capatch Response
            boolean isResponseCorrect = false;
            String captchaId = request.getSession().getId();
            String response = request.getParameter("j_captcha_response");

            student = (Student) request.getSession().getAttribute("student_sess");
                // Now set the Student details to Stduent_session
            modelMap.addAttribute("student", student);



            try {
                if (response != null) {

                    isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                    log.error("Captcha is valid..Great!");
                }

            } catch (CaptchaServiceException e) {
                log.error("Problem Jcaptcha settings ", e);
            }

            if (!isResponseCorrect) { //Capatcha is not correct
                modelMap.addAttribute("captchaerror", "Capacth is Invalid");
                page=4;

            } else {
                //student.setPassword(RandomStringUtils.randomAlphanumeric(10));
                student.setUsername(student.getEmailId());
                student.setParentsUsername(student.getParentsEmailid());
                student.setId(Long.parseLong(request.getSession().getAttribute("stdntPrimKey").toString()));

                studentService.updateStudent(student);

                Users user = new Users();
                user.setUsername(student.getUsername());
                user.setEnabled(true);
                user.setPassword(student.getPassword());
                user.setUsertype("STUDENT");
                user.setEmailid(student.getEmailId());
                user.setId(Long.parseLong(request.getSession().getAttribute("usersprimkeyid").toString()));

                //Saving into Common Users Table
                usersService.UpdateUser(user);

                // Saving Student's Parents Login Details
                Users user_parent = new Users();
                user_parent.setUsername(student.getParentsUsername());
                user_parent.setEnabled(true);
                user_parent.setPassword(student.getParentsPassword());
                user_parent.setUsertype("PARENTS");
                user_parent.setEmailid(student.getParentsEmailid());
                user_parent.setId(Long.parseLong(request.getSession().getAttribute("parentsprimkeyid").toString()));

                //Saving into Common Users Table
                usersService.UpdateUser(user_parent);


                if (request.getSession().getAttribute("userProfilePhotoExists") == null) {
                    List<Student> studentDetails = studentService.findStudentByUsername(student.getUsername());


                    ResourceBundle bundle = ResourceBundle.getBundle("messages");
                    String rootwebapp = bundle.getString("webapp.root");
                    String actrootwebapp = bundle.getString("actwebapp.root");

                    MultipartFile file1 = (MultipartFile) request.getSession().getAttribute("file1_sess");

                    String filename = file1.getOriginalFilename().toString();

                    int dotPosi = filename.lastIndexOf(".");
                    String extension = filename.substring(dotPosi);
                    String NewFilename = Long.toString(studentDetails.get(0).getId()) + extension;

                    String profPhotoContextPath = "/profile_photos/student/" + NewFilename;
                    String profPhotoAbsolutePathName = rootwebapp + profPhotoContextPath;

                    //String profPhotoAbsolutePathName = actrootwebapp + profPhotoContextPath;
                    file1.transferTo(new File(profPhotoAbsolutePathName));
                    student.setId(studentDetails.get(0).getId());
                    student.setProfilePhotoFileName(NewFilename);
                    //Updating the Student table with Profile File name
                    studentService.updateStudent(student);
                }


                //
            }
        }
            modelMap.addAttribute("pageNum", page);
            modelMap.addAttribute("pageMax", pages.length);
            modelMap.addAttribute("pageView", pages[page - 1]);

            modelMap.addAttribute("stdntPrimKey", request.getSession().getAttribute("stdntPrimKey"));
            modelMap.addAttribute("usersprimkeyid",request.getSession().getAttribute("usersprimkeyid"));



            /* IMPLEMENT YOUR LOGIC */
            return new ModelAndView("AdminStdProfile", modelMap);
        }






}



