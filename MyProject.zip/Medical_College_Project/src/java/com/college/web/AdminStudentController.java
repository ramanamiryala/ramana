package com.college.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;


import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
//import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.annotation.RequestParam;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.PageContext;

import com.college.domain.Student;
import com.college.domain.Users;

import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.ArrayList;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;

import com.college.service.StudentService;
import com.college.security.UsersService;
import com.college.validator.StudentValidator;

import org.apache.log4j.Logger;
import org.apache.commons.lang.RandomStringUtils;

@Controller
public class AdminStudentController {

    private StudentService studentService;
    private StudentValidator studentValidator;
    private GenericManageableCaptchaService captchaService;
    private UsersService usersService;
    private Logger log = Logger.getLogger(AdminStudentController.class);

    @Autowired
    public AdminStudentController(GenericManageableCaptchaService captchaService, StudentService studentService,
            StudentValidator studentValidator, UsersService usersService) {
        this.studentService = studentService;
        this.studentValidator = studentValidator;
        this.captchaService = captchaService;
        this.usersService = usersService;
    }

    @RequestMapping(value = "/AdminStdntReg.htm")
    public ModelAndView userForm(ModelMap modelMap) {
        Student student = new Student();
        modelMap.addAttribute("student", student);


        studentService.formAddOptionvalues (modelMap);
        
        String formerror = "";
        modelMap.addAttribute("formerror",formerror);

        return new ModelAndView("AdminStdntReg", modelMap);
    }

    private static final String destinationDir = "C:/Temp/";

    @RequestMapping(value = "/AdminStdntRegDone.htm")
    public ModelAndView regSuccess(
            @ModelAttribute("student") Student student, BindingResult result, ModelMap modelMap,
            HttpServletRequest request,
            @RequestParam("file1") MultipartFile file1) throws Exception {


       student.setDateofBirth(request.getParameter("bday")+"/"+request.getParameter("bmonth")+ "/" +request.getParameter("byear"));

       student.setCurrentAddress(request.getParameter("stc_line1")+request.getParameter("stc_line2")+request.getParameter("stc_line3"));
       student.setPermanentAddress(request.getParameter("stp_line1")+request.getParameter("stp_line2")+request.getParameter("stp_line3"));
       student.setParentsCorrespondenceAddress(request.getParameter("pc_line1")+request.getParameter("pc_line2")+request.getParameter("pc_line3"));

       student.setPassword(RandomStringUtils.randomAlphanumeric(10));
       student.setUsername(student.getEmailId());

       
        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");


        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                log.error("Captcha is valid..Great!");
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

//        studentValidator.validateRegistration(student, result);
  //      if (result.hasErrors()) {
    //        return new ModelAndView("AdminStdntReg");
      //  }
       
        if (file1.isEmpty()) {
           
            studentService.formAddOptionvalues (modelMap);
                    
            modelMap.addAttribute("formerror","File is Empty");
            return new ModelAndView("AdminStdntReg", modelMap);
        } else {
            if (!isResponseCorrect) { //Capatcha is not correct
                
                studentService.formAddOptionvalues (modelMap);
                modelMap.addAttribute("formerror","Capacth is Invalid");
                return new ModelAndView("AdminStdntReg", modelMap);
            } else {

                if (!studentService.studentLoginCheck(student)) {

                    Users user = new Users();

                    user.setUsername(student.getUsername());
                    user.setEnabled(true);
                    user.setPassword(student.getPassword());
                    user.setUsertype("STUDENT");
                    user.setEmailid(student.getEmailId());
                    
                    
                    //student.setCollegeRegistrationNumber(student.getEmailId());



                    ResourceBundle bundle = ResourceBundle.getBundle("messages");
                    String rootwebapp = bundle.getString("webapp.root");

                    String filename = file1.getOriginalFilename().toString();

                    int dotPosi = filename.lastIndexOf(".");
                    String extension = filename.substring(dotPosi);
                    String NewFilename = ;


                    String profPhotoContextPath ="/profile_photos/"+NewFilename+ extension;
                    String profPhotoAbsolutePathName=rootwebapp +profPhotoContextPath;

                    File destination1 = new File(profPhotoAbsolutePathName);

                    file1.transferTo(destination1);


                    student.setProfilePhotoFileName(profPhotoAbsolutePathName);
                    usersService.AddNewUser(user);
                    studentService.saveStudent(student);

                    return new ModelAndView("AdminStdntRegDone");

                } else {

                    studentService.formAddOptionvalues (modelMap);
                modelMap.addAttribute("formerror","User with given details already exists. <br> Please change username & password <br>");
                return new ModelAndView("AdminStdntReg", modelMap);
                 
                }
            }

        }

    }

    @RequestMapping("/AdminStdntProfSearch.htm")
    public ModelAndView studentSearch(ModelMap model, @ModelAttribute("student") Student student, @ModelAttribute("student1") Student student1) {

        model.addAttribute("student", new Student());

        List<Student> studentSearch = studentService.searchStudent(student1);
        model.addAttribute("studentSearch", studentSearch);




        return new ModelAndView("AdminStdntProfSearch", model);

    }

    @RequestMapping("/AdminStdntProfUpdate.htm")
    public ModelAndView update(
            ModelMap model,
            @ModelAttribute("student") Student student,
            @RequestParam("selection") int selection) {
        if (selection != 0) {
            student.setId(selection);

            studentService.retrieveStudent(student);

            Users user = new Users();
            user.setUsername(student.getUsername());
            user.setPassword(student.getPassword());


            List<Users> userdetails = usersService.userLoginCheck(user);

            long userid=userdetails.get(0).getId();





            return new ModelAndView("AdminStdntProfUpdate", "userid",userid);
        } else {
            return new ModelAndView("AdminStdntProfSearch", model);
        }

    }

    @RequestMapping(value = "/AdminStdntProfUpdateDone.htm")
    public ModelAndView UpdateSuccess(
            @ModelAttribute("student") Student student, BindingResult result, ModelMap model,
            HttpServletRequest request,
            @RequestParam("userid") int userid,//user's Primary Key
            @RequestParam("file1") MultipartFile file1) throws Exception {

        // Checking Capatch Response
        boolean isResponseCorrect = false;
        String captchaId = request.getSession().getId();
        String response = request.getParameter("j_captcha_response");


        try {
            if (response != null) {
                isResponseCorrect = captchaService.validateResponseForID(captchaId, response);
                log.error("Captcha is valid..Great!");
            }

        } catch (CaptchaServiceException e) {
            log.error("Problem Jcaptcha settings ", e);
        }

        studentValidator.validateRegistration(student, result);
        if (result.hasErrors()) {
            return new ModelAndView("AdminStdntProfUpdate");
        }


        if (file1.isEmpty()) {
            return new ModelAndView("AdminStdntProfUpdate", "captchaerror", "Empty File");
        } else {
            if (!isResponseCorrect) {
                return new ModelAndView("AdminStdntProfUpdate", "captchaerror", "Invalid Captcha");
            } else {

                Users user = new Users();
                user.setUsername(student.getUsername());
                user.setEnabled(true);
                user.setPassword(student.getPassword());
                user.setEmailid(student.getEmailId());
                user.setId(userid); // Userid is the Primarykey in Users table
                user.setUsertype("STUDENT");

                // Updation is to be by id(Primary key) matching
                
            
                

                usersService.UpdateUser(user);

                studentService.updateStudent(student);

                String filename = file1.getOriginalFilename().toString();

                int dotPosi = filename.lastIndexOf(".");
                String extension = filename.substring(dotPosi);

                File destination1 = new File(destinationDir + student.getUsername()+ extension);

                file1.transferTo(destination1);
                return new ModelAndView("AdminStdntProfUpdateDone");


            }
        }

    }
}



