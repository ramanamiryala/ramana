/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.college.email;

public class EmailDetails {

  //  message.setFrom("ramana.miryala@gmail.com");
            //    message.setTo("ramana.miryala@gmail.com");
             //   message.setCC

             //   message.setSubject("Library Details");
   //message.addInline("myLogo", new FileSystemResource( new File("F:/Haritha_Tech_Project/SystemWithOutSecurity/web/WEB-INF/images/harithalogo.jpg")));
  //              message.addAttachment("myDocument.pdf", new FileSystemResource(new File("F:/Haritha_Tech_Project/SystemWithOutSecurity/web/WEB-INF/doc/springsecurity.pdf")));
// String text = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, "EmailMessageTemplate.vm", newmodel);

 String From;
 String To;
 String CC;
 String BCC;
 String Subject;
 String VMTemplate;
 String[] AddInline;
 String[] Attachment;

    public String[] getAddInline() {
        return AddInline;
    }

    public void setAddInline(String[] AddInline) {
        this.AddInline = AddInline;
    }

    public String[] getAttachment() {
        return Attachment;
    }

    public void setAttachment(String[] Attachment) {
        this.Attachment = Attachment;
    }

    public String getBCC() {
        return BCC;
    }

    public void setBCC(String BCC) {
        this.BCC = BCC;
    }

    public String getCC() {
        return CC;
    }

    public void setCC(String CC) {
        this.CC = CC;
    }

    public String getFrom() {
        return From;
    }

    public void setFrom(String From) {
        this.From = From;
    }

    public String getSubject() {
        return Subject;
    }

    public void setSubject(String Subject) {
        this.Subject = Subject;
    }

    public String getTo() {
        return To;
    }

    public void setTo(String To) {
        this.To = To;
    }

    public String getVMTemplate() {
        return VMTemplate;
    }

    public void setVMTemplate(String VMTemplate) {
        this.VMTemplate = VMTemplate;
    }




}
