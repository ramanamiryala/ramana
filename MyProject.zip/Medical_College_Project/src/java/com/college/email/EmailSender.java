package com.college.email;

import org.springframework.ui.ModelMap;

public interface EmailSender {

    public void sendEmail(final ModelMap model, final EmailDetails emailDetails);

}
