/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.college.multipleforms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.BindException;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.view.RedirectView;
import org.springframework.web.bind.support.SessionStatus;

import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.annotation.RequestParam;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.PageContext;

import com.college.domain.Student;
import com.college.domain.Users;

import org.springframework.web.multipart.MultipartFile;
import java.io.File;
import java.io.FileInputStream;
import java.util.List;
import java.util.ArrayList;
import java.util.Properties;
import java.util.ResourceBundle;
import org.springframework.web.multipart.commons.CommonsFileUploadSupport;
import org.apache.commons.fileupload.FileUpload;
import net.sf.oval.constraint.EmailCheck;


import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import com.octo.captcha.service.multitype.GenericManageableCaptchaService;
import com.octo.captcha.service.CaptchaServiceException;

import com.college.service.StudentService;
import com.college.security.UsersService;
import com.college.validator.StudentValidator;

import org.apache.log4j.Logger;
import org.apache.commons.lang.RandomStringUtils;
import org.springframework.core.io.ClassPathResource;

import org.springframework.web.servlet.mvc.AbstractWizardFormController;
import javax.servlet.ServletContext;




//@Controller
public class AdminStudentRegistrationController extends AbstractWizardFormController {

//    private StudentService studentService;
//    private StudentValidator studentValidator;
//    private GenericManageableCaptchaService captchaService;
//    private UsersService usersService;


//  //  @Autowired
//    public AdminStudentRegistrationController(GenericManageableCaptchaService captchaService, StudentService studentService,
//            StudentValidator studentValidator, UsersService usersService) {
//        this.studentService = studentService;
//        this.studentValidator = studentValidator;
//        this.captchaService = captchaService;
//        this.usersService = usersService;
//        setCommandName("student");
//    }
//

        public AdminStudentRegistrationController() {
            setCommandClass(Student.class);
        setCommandName("student");
    }


   @Override
    protected ModelAndView processCancel(HttpServletRequest request,HttpServletResponse response,Object command, BindException errors)
            throws Exception{
        return new ModelAndView (new RedirectView("Form1"));
    }


        @Override
    protected ModelAndView processFinish(HttpServletRequest request,HttpServletResponse response,Object command, BindException errors)
            throws Exception{
Student student = (Student) command;
        return null;
    }






}
