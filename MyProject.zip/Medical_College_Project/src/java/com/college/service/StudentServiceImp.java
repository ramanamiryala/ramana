package com.college.service;

import java.util.List;
import java.util.ArrayList;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;
import com.college.domain.Student;
import org.springframework.ui.ModelMap;

public class StudentServiceImp implements StudentService {

    private HibernateTemplate hibernateTemplate;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.hibernateTemplate = new HibernateTemplate(sessionFactory);
    }



    @Override
    public void formAddOptionvalues (ModelMap modelMap)
    {
        List<String> sex = new ArrayList();
        sex.add("");
        sex.add("FEMALE");
        sex.add("MALE");
        modelMap.addAttribute("sex",sex);

        List<String> religion = new ArrayList();
        religion.add("");
        religion.add("Hindu");
        religion.add("Muslim");
        religion.add("Christian");
        religion.add("Others");
        modelMap.addAttribute("religion",religion);

        int i;
        List<Object> day = new ArrayList();

        for(i=0;i<32;i++)
        {
            if(i==0)
                day.add((Object)(""));
            else
                day.add((Object)i);
        }

        modelMap.addAttribute("day",day);

        List<Object> month = new ArrayList();
        for(i=0;i<13;i++)
        {
            if(i==0)
                month.add((Object)(""));
            else
                month.add((Object)i);
        }

        modelMap.addAttribute("month",month);

       String[] months = { "", "JAN" , "FEB" , "MAR", "APR" , "MAY", "JUN", "JUL" , "AUG", "SEP", "OCT" , "NOV" , "DEC"};
        modelMap.addAttribute("months",months);

        List<Object> year = new ArrayList();
        for(i=1899;i<2051;i++)
        {
            if(i==1899)
                year.add((Object)(""));
            else
                year.add((Object)i);
        }

        modelMap.addAttribute("year",year);

        String[] states ={"","Andaman and Nicobar Islands","Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chandigarh","Chhattisgarh","Dadra and Nagar Haveli","Daman and Diu","Delhi","Goa","Gujarat","Haryana","Himachal Pradesh","Jammu and Kashmir","Jharkhand","Karnataka","Kerala","Lakshadweep","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Orissa","Puducherry","Punjab","Rajasthan","Sikkim","Tamil Nadu","Tripura","Uttar Pradesh","Uttarakhand","West Bengal","Other"};
        modelMap.addAttribute("states",states);


        String[] countries ={"","Australia","Bahrain","Bangladesh","Belgium","Canada","Doha","Dubai","France","Germany","Hong Kong","INDIA","Indonesia","Ireland","Italy","Japan","Kenya","Kuwait","Lebanon","Libya","Malaysia", "Maldives","Mauritius","Mexico","Nepal","Netherlands","New Zealand","Norway","Oman","Pakistan","Qatar","Quilon","Russia","Saudi Arabia","Singapore","South Africa","South Korea","Spain","Sri Lanka","Sweden", "Switzerland","Thailand","UAE","UK","US","Yemen","Zimbabwe","Other"};
        modelMap.addAttribute("countries",countries);


        String[] courses ={"","BDS","B.Sc.(MLT)","B.Sc.(Nursing)","DM/M.Ch (Super Speciality)","MBBS","MD/MS (Med)", "MDS", "M.Sc. (Medical)","M.Sc. (Nursing)","PhD"};
        modelMap.addAttribute("courses",courses);

    }
    @Override
    public void retrieveStudent(Student student) {

        List<Student> studentDetails;
        if (student.getUsername() != null) {
            studentDetails = (List<Student>) hibernateTemplate.find("from Student where username = ? ", student.getUsername());
            if (studentDetails.size() != 0) {

                student.setFirstName(studentDetails.get(0).getFirstName());
                student.setLastName(studentDetails.get(0).getLastName());
                student.setSex(studentDetails.get(0).getSex());
                student.setParentsName(studentDetails.get(0).getParentsName());
                student.setCourseJoined(studentDetails.get(0).getCourseJoined());
                student.setDateofBirth(studentDetails.get(0).getDateofBirth());
                student.setMotherTounge(studentDetails.get(0).getMotherTounge());
                student.setNationality(studentDetails.get(0).getNationality());
                student.setReligion(studentDetails.get(0).getReligion());
                student.setMobileNumber(studentDetails.get(0).getMobileNumber());
                student.setEmailId(studentDetails.get(0).getEmailId());
                student.setProfilePhotoFileName(studentDetails.get(0).getProfilePhotoFileName());

            } else {
                System.out.println("This student is not added in the Stduent Database");
            }


        } else {
            System.out.println("No Student Details given ");
            return;
        }


    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Student> searchStudent(Student student1) {

        Object row[] = new Object[2];
        row[0] = (Object) ('%' + student1.getUsername() + '%');
        row[1] = (Object) ('%' + student1.getCollegeRegistrationNumber() + '%');

        return hibernateTemplate.find("from Student where username like ? AND collegeRegistrationNumber like ? ", row);
    }

    @Override
    public boolean studentLoginCheck(Student student) {

        List<Student> studentDetails;
        studentDetails = (List<Student>) hibernateTemplate.find("from Student where username = ? ", student.getUsername());

        if (studentDetails.size() != 0) {

            student = studentDetails.get(0);

            return true;
        } else {
            return false;
        }
    }

    @Override
    public void updateStudent(Student student) {
        System.out.println("Hello--->");
        //By R.no: we r getting the student Detials -->
        //List<Student> dbStdDetails=hibernateTemplate.find("from Student where st_Rno = ?", student.getRno());
        //student.setId(dbStdDetails.get(0).getId());
        //as We r getting Student data by Id so we dont require above

        hibernateTemplate.update(student);
    }

    @Override
    public void saveStudent(Student student) {
        System.out.println("Hello--->");
        hibernateTemplate.save(student);
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Student> listStudent(Student student) {
        return hibernateTemplate.find("from Student where collegeRegistrationNumber = ? ", student.getCollegeRegistrationNumber());
    }
}
