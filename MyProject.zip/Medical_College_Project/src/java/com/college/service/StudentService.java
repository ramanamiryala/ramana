package com.college.service;

import com.college.domain.Student;
import org.springframework.ui.ModelMap;

import java.util.List;

public interface StudentService {
    public void retrieveStudent(Student student);
    public void saveStudent(Student student);
    public boolean studentLoginCheck(Student student);
    public List<Student> listStudent(Student student);
    //public boolean studentRegLoginCheck(Student student);
    public void updateStudent(Student student);
    public List<Student> searchStudent(Student student1);
    public void formAddOptionvalues (ModelMap modelMap);
    public List<Student> findStudentByUsername(String username);


}
