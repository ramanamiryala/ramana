/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.college.security;

//import com.college.service.StudentService;

import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.HibernateTemplate;
import java.util.ArrayList;
import com.college.domain.Users;
import org.apache.commons.lang.RandomStringUtils;

public class UsersServiceImp implements UsersService {

    private HibernateTemplate hibernateTemplate;

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.hibernateTemplate = new HibernateTemplate(sessionFactory);
    }

    public List<Users> userLoginCheck(Users user) {
        List<Users> userDetails;
        //List<Marks> studentDetails;
        Object column[] = new Object[2];
        column[0] = (Object) user.getUsername();
        column[1] = (Object) user.getPassword();
        userDetails = (List<Users>) hibernateTemplate.find("from Users where username = ? AND password = ? ", column);
        return userDetails;
    }

    public List<Users> userDetailsCheck(String userattribute, String userattributename) {
        List<Users> userDetails;
//        Users user = new Users();
        userDetails = (List<Users>) hibernateTemplate.find("from Users where " + userattributename + " = ? ", userattribute);
        return userDetails;
    }

    public boolean userEmailCheck(String emailid) {
        Users user = new Users();
        user.setEmailid(emailid);
        List<Users> userDetails;

        userDetails = (List<Users>) hibernateTemplate.find("from Users where emailid = ? ", emailid);


        if (userDetails.size() < 1) {
            return false;
        } else {
            if (userDetails.get(0).isEnabled()) {
                return true;
            } else {
                return false;
            }
        }
    }

    public boolean userNameCheck(String username) {
        Users user = new Users();
        user.setUsername(username);
        List<Users> userDetails;

        userDetails = (List<Users>) hibernateTemplate.find("from Users where username = ? ", username);

        if (userDetails.size() < 1) {
            return false;
        } else {
            if (userDetails.get(0).isEnabled()) {
                return true;
            } else {
                return false;
            }
        }
    }

    public String userPasswordReset(String username, String emailid) {
        String forgotmessage = "";

        Users user = new Users();

        String password = RandomStringUtils.randomAlphanumeric(10);

        List<Users> userDetails;

        if (emailid.equals("") && username.equals("")) {
            forgotmessage = "Please Enter <b>usrename</b> or <b>email id </b> or <b> both</b>";
        } else if (!emailid.equals("") && username.equals("")) {
            if (userEmailCheck(emailid)) {

                userDetails = (List<Users>) hibernateTemplate.find("from Users where emailid = ? ", emailid);
                user = userDetails.get(0);
                user.setPassword(password);

                

                hibernateTemplate.update(user);


            } else {
                forgotmessage = "your <b>Email id</b> is not Valid";
            }

        } else if (emailid.equals("") && !username.equals("")) { // emailis is Empty & username is not Empty

            if (userNameCheck(username)) {

                userDetails = (List<Users>) hibernateTemplate.find("from Users where username = ? ", username);
                user = userDetails.get(0);
                user.setPassword(password);

                hibernateTemplate.update(user);

            } else {
                forgotmessage = "Your <b>username</b> is not Valid";
            }
        } else { //if both values are entered
            if (userNameCheck(username) && userEmailCheck(emailid)) {


                Object row[] = new Object[2];
                row[0] = (Object) username;
                row[1] = (Object) emailid;


                userDetails = (List<Users>) hibernateTemplate.find("from Users where username = ? AND emailid = ?", row);
                user = userDetails.get(0);
                user.setPassword(password);

                hibernateTemplate.update(user);


            } else {
                forgotmessage = "Your <b> username </b> & <b> Email id </b> are not valid";
            }
        }

        return forgotmessage;
    }

    public void AddNewUser(Users user)
    {
      hibernateTemplate.save(user);
    }

    public void UpdateUser(Users user)
    {
        // Updating is by Id always which is PRIMARY KEY
      hibernateTemplate.update(user);
    }


        



}
